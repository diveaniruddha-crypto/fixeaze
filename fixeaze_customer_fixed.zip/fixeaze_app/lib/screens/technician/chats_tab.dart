import 'package:flutter/material.dart';

import '../../config.dart';
import '../../widgets/common.dart';
import '../chat_screen.dart';

/// Chats are only available for bookings this technician has accepted.
class ChatsTab extends StatefulWidget {
  const ChatsTab({super.key});

  @override
  State<ChatsTab> createState() => _ChatsTabState();
}

class _ChatsTabState extends State<ChatsTab> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  void _refresh() => setState(() => _future = _load());

  Future<List<Map<String, dynamic>>> _load() async {
    final uid = supabase.auth.currentUser!.id;
    final rows = await supabase
        .from('bookings')
        .select('id, status, scheduled_at, customer_id, services(name)')
        .eq('technician_id', uid)
        .inFilter('status', ['accepted', 'in_progress', 'completed'])
        .order('scheduled_at', ascending: false);
    final jobs = List<Map<String, dynamic>>.from(rows);

    final ids = jobs.map((j) => j['customer_id']).whereType<String>().toSet().toList();
    final names = <String, String>{};
    if (ids.isNotEmpty) {
      final c = await supabase.from('profiles').select('id, name').inFilter('id', ids);
      for (final r in c) {
        names[r['id'] as String] = (r['name'] ?? 'Customer').toString();
      }
    }
    for (final j in jobs) {
      j['customer_name'] = names[j['customer_id']] ?? 'Customer';
    }
    // Active chats first.
    bool active(Map<String, dynamic> j) =>
        j['status'] == 'accepted' || j['status'] == 'in_progress';
    jobs.sort((a, b) {
      if (active(a) != active(b)) return active(a) ? -1 : 1;
      return 0;
    });
    return jobs;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) return ErrorState(error: snap.error!, onRetry: _refresh);
        final jobs = snap.data!;
        if (jobs.isEmpty) {
          return const EmptyState(
            icon: Icons.chat_bubble_outline,
            text: 'No chats yet.\nA chat opens as soon as you accept a booking.',
          );
        }
        return RefreshIndicator(
          onRefresh: () async {
            _refresh();
            await _future;
          },
          child: ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: jobs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final j = jobs[i];
              final name = j['customer_name'].toString();
              final status = (j['status'] ?? '').toString();
              final active = status == 'accepted' || status == 'in_progress';
              final service = (j['services'] is Map ? j['services']['name'] : null) ?? 'Service';
              return Card(
                margin: EdgeInsets.zero,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                child: ListTile(
                  leading: CircleAvatar(
                    child: Text(name.isEmpty ? '?' : name[0].toUpperCase()),
                  ),
                  title: Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text('$service • ${fmtDate(j['scheduled_at'])}'),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Icon(Icons.chat_bubble_outline,
                          color: active ? Colors.teal : Colors.black38),
                      Text(active ? 'Open' : 'Closed',
                          style: TextStyle(
                              fontSize: 11,
                              color: active ? Colors.teal : Colors.black45)),
                    ],
                  ),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChatScreen(
                        bookingId: j['id'] as String,
                        title: 'Chat with $name',
                        canSend: active,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
