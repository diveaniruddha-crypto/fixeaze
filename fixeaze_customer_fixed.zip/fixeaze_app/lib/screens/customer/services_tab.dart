import 'package:flutter/material.dart';

import '../../config.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import 'book_screen.dart';

class ServicesTab extends StatefulWidget {
  final String greetingName;
  final VoidCallback onBooked;
  const ServicesTab({super.key, required this.greetingName, required this.onBooked});

  @override
  State<ServicesTab> createState() => _ServicesTabState();
}

class _ServicesTabState extends State<ServicesTab> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows =
        await supabase.from('services').select().eq('active', true).order('name');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> _openBooking(Map<String, dynamic> service, String type) async {
    final booked = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => BookScreen(service: service, initialType: type),
      ),
    );
    if (booked == true) widget.onBooked();
  }

  Future<void> _pickService(List<Map<String, dynamic>> services, String type) async {
    if (services.isEmpty) return;
    final picked = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Text(
                type == 'inspection'
                    ? 'What needs an estimate and inspection?'
                    : 'Which service do you need?',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            ...services.map((s) {
              final name = (s['name'] ?? '').toString();
              return ListTile(
                leading: Icon(serviceIcon(name), color: kTeal),
                title: Text(name),
                subtitle: Text(type == 'inspection'
                    ? 'Inspection visit ${money(s['inspection_fee'])}'
                    : (s['base_price'] != null
                        ? 'From ${money(s['base_price'])} per hour'
                        : 'Priced per hour')),
                onTap: () => Navigator.pop(ctx, s),
              );
            }),
          ],
        ),
      ),
    );
    if (picked != null) _openBooking(picked, type);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return ErrorState(
            error: snap.error!,
            onRetry: () => setState(() => _future = _load()),
          );
        }
        final services = snap.data!;
        return RefreshIndicator(
          onRefresh: () async {
            setState(() => _future = _load());
            await _future;
          },
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
                  child: Text(
                    widget.greetingName.isEmpty
                        ? 'What do you need fixed?'
                        : 'Hi ${widget.greetingName}, what do you need fixed?',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: _ActionCard(
                          icon: Icons.schedule,
                          title: 'Book hourly',
                          subtitle: 'Pay by the hour',
                          onTap: () => _pickService(services, 'hourly'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _ActionCard(
                          icon: Icons.search,
                          title: 'Estimate & inspection',
                          subtitle: 'We check, then quote',
                          onTap: () => _pickService(services, 'inspection'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                  child: Text('All services',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                ),
              ),
              if (services.isEmpty)
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: EmptyState(
                      icon: Icons.handyman, text: 'No services available yet.'),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  sliver: SliverGrid(
                    gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 240,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 1.05,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, i) => _ServiceCard(
                        service: services[i],
                        onTap: () => _openBooking(services[i], 'hourly'),
                      ),
                      childCount: services.length,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: kTeal,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: kAmber, size: 28),
              const SizedBox(height: 10),
              Text(title,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 2),
              Text(subtitle,
                  style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

class _ServiceCard extends StatelessWidget {
  final Map<String, dynamic> service;
  final VoidCallback onTap;
  const _ServiceCard({required this.service, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final name = (service['name'] ?? '').toString();
    final iconUrl = service['icon_url'] as String?;
    return Card(
      elevation: 1,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 26,
                backgroundColor: kTeal.withOpacity(0.1),
                backgroundImage: iconUrl != null ? NetworkImage(iconUrl) : null,
                child: iconUrl == null
                    ? Icon(serviceIcon(name), color: kTeal, size: 28)
                    : null,
              ),
              const Spacer(),
              Text(name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 2),
              Text(
                (service['description'] ?? '').toString(),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
              const SizedBox(height: 6),
              if (service['base_price'] != null)
                Text('From ${money(service['base_price'])}/hr',
                    style: const TextStyle(
                        color: kTeal, fontWeight: FontWeight.w600, fontSize: 13)),
            ],
          ),
        ),
      ),
    );
  }
}
