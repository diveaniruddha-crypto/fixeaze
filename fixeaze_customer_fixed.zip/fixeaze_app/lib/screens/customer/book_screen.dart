import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../services/cloudinary_service.dart';
import '../../services/pincode_service.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import '../login_screen.dart';

class BookScreen extends StatefulWidget {
  final Map<String, dynamic> service;
  final String initialType; // 'hourly' or 'inspection'
  const BookScreen({super.key, required this.service, this.initialType = 'hourly'});

  @override
  State<BookScreen> createState() => _BookScreenState();
}

class _BookScreenState extends State<BookScreen> {
  final _form = GlobalKey<FormState>();
  final _pincode = TextEditingController();
  final _address = TextEditingController();
  final _notes = TextEditingController();

  late String _type;
  int _hours = 2;
  DateTime? _date;
  TimeOfDay? _time;
  final List<String> _photos = [];
  bool _uploading = false;
  bool _saving = false;

  // pincode + availability
  PinInfo? _pin;
  bool _checking = false;
  String? _pinError;
  int? _count;
  num? _minRate;
  num? _maxRate;
  Timer? _debounce;

  static const _maxPhotos = 4;

  @override
  void initState() {
    super.initState();
    _type = widget.initialType;
    _prefill();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _pincode.dispose();
    _address.dispose();
    _notes.dispose();
    super.dispose();
  }

  /// Fetches the pincode and address saved in the customer's account.
  Future<void> _prefill() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    try {
      final p = await supabase
          .from('profiles')
          .select('address, pincode')
          .eq('id', user.id)
          .maybeSingle();
      if (!mounted || p == null) return;
      final a = (p['address'] ?? '').toString();
      final pin = (p['pincode'] ?? '').toString();
      if (a.isNotEmpty && _address.text.isEmpty) _address.text = a;
      if (pin.isNotEmpty && _pincode.text.isEmpty) {
        _pincode.text = pin;
        _checkPin();
      }
    } catch (_) {
      // not important
    }
  }

  void _onPinChanged(String _) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), _checkPin);
  }

  Future<void> _checkPin() async {
    final pin = _pincode.text.trim();
    if (!PincodeService.isValid(pin)) {
      setState(() {
        _pin = null;
        _count = null;
        _pinError = pin.isEmpty ? null : 'Enter a valid 6-digit pincode';
      });
      return;
    }
    setState(() {
      _checking = true;
      _pinError = null;
    });
    final info = await PincodeService.lookup(pin);
    if (!mounted || pin != _pincode.text.trim()) return;
    if (info == null) {
      setState(() {
        _checking = false;
        _pin = null;
        _count = null;
        _pinError = 'We could not find this pincode';
      });
      return;
    }
    try {
      final rows = await supabase.rpc('technicians_nearby', params: {
        'p_lat': info.lat,
        'p_lng': info.lng,
        'p_service': widget.service['id'],
        'p_km': 10,
      });
      final list = List<Map<String, dynamic>>.from(rows as List);
      final row = list.isEmpty ? <String, dynamic>{} : list.first;
      if (!mounted) return;
      setState(() {
        _pin = info;
        _count = (row['cnt'] as num?)?.toInt() ?? 0;
        _minRate = row['min_rate'] as num?;
        _maxRate = row['max_rate'] as num?;
        _checking = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _pin = info;
        _count = null;
        _checking = false;
        _pinError = 'Could not check technicians right now';
      });
    }
  }

  // ----- estimate -----
  num get _inspectionFee =>
      num.tryParse('${widget.service['inspection_fee'] ?? 199}') ?? 199;

  List<num> _range() {
    if (_type == 'inspection') return [_inspectionFee, _inspectionFee];
    if (_minRate != null && _maxRate != null) {
      return [_hours * _minRate!, _hours * _maxRate!];
    }
    final base = num.tryParse('${widget.service['base_price'] ?? 0}') ?? 0;
    return [_hours * base, _hours * base];
  }

  String _estimateText() {
    final r = _range();
    if (r[1] == 0) return 'Quote after inspection';
    return r[0] == r[1] ? money(r[0]) : '${money(r[0])} - ${money(r[1])}';
  }

  // ----- pickers -----
  Future<void> _pickDate() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: _date ?? now,
      firstDate: now,
      lastDate: now.add(const Duration(days: 90)),
    );
    if (d != null) setState(() => _date = d);
  }

  Future<void> _pickTime() async {
    final t = await showTimePicker(
      context: context,
      initialTime: _time ?? const TimeOfDay(hour: 10, minute: 0),
    );
    if (t != null) setState(() => _time = t);
  }

  Future<void> _addPhoto() async {
    if (_photos.length >= _maxPhotos) return;
    setState(() => _uploading = true);
    try {
      final url = await CloudinaryService.pickAndUpload();
      if (url != null) setState(() => _photos.add(url));
    } catch (e) {
      if (mounted) snack(context, 'Could not upload photo: $e', error: true);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  // ----- submit -----
  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    if (_date == null || _time == null) {
      snack(context, 'Please choose a date and time', error: true);
      return;
    }
    final when =
        DateTime(_date!.year, _date!.month, _date!.day, _time!.hour, _time!.minute);
    if (when.isBefore(DateTime.now())) {
      snack(context, 'Please choose a time in the future', error: true);
      return;
    }

    // Make sure the pincode is resolved to a location.
    _pin ??= await PincodeService.lookup(_pincode.text);
    if (_pin == null) {
      if (mounted) snack(context, 'We could not find this pincode', error: true);
      return;
    }

    // Guests can browse, but must log in before placing a booking.
    if (supabase.auth.currentUser == null) {
      if (!mounted) return;
      snack(context, 'Please log in or sign up to place your booking');
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
      if (supabase.auth.currentUser == null) return;
    }

    setState(() => _saving = true);
    try {
      final r = _range();
      await supabase.from('bookings').insert({
        'customer_id': supabase.auth.currentUser!.id,
        'service_id': widget.service['id'],
        'booking_type': _type,
        'hours': _type == 'hourly' ? _hours : null,
        'address': _address.text.trim(),
        'pincode': _pin!.pincode,
        'lat': _pin!.lat,
        'lng': _pin!.lng,
        'scheduled_at': when.toUtc().toIso8601String(),
        'notes': _notes.text.trim(),
        'photos': _photos,
        'estimated_min': r[0],
        'estimated_max': r[1],
        'status': 'pending',
      });
      if (!mounted) return;
      snack(context, 'Booking sent! A technician will accept it soon.');
      Navigator.pop(context, true);
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Could not create booking: $e', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _availability() {
    if (_checking) {
      return const Padding(
        padding: EdgeInsets.only(top: 8),
        child: Row(children: [
          SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
          SizedBox(width: 8),
          Text('Checking technicians near you...'),
        ]),
      );
    }
    if (_pinError != null) {
      return Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Text(_pinError!, style: const TextStyle(color: Colors.red)),
      );
    }
    if (_count == null || _pin == null) return const SizedBox.shrink();
    final has = _count! > 0;
    final area = _pin!.label.isEmpty ? _pin!.pincode : '${_pin!.pincode} (${_pin!.label})';
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: (has ? Colors.green : Colors.orange).withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(has ? Icons.check_circle : Icons.info,
              color: has ? Colors.green : Colors.orange),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              has
                  ? '$_count technician${_count == 1 ? '' : 's'} available within 10 km of $area'
                  : 'No technicians in your area yet ($area). You can still book and we will assign one as soon as someone is available.',
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final name = (widget.service['name'] ?? '').toString();
    return Scaffold(
      appBar: AppBar(title: Text(name)),
      body: Constrained(
        maxWidth: 600,
        child: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(
                      value: 'hourly', icon: Icon(Icons.schedule), label: Text('Book hourly')),
                  ButtonSegment(
                      value: 'inspection',
                      icon: Icon(Icons.search),
                      label: Text('Estimate & inspection')),
                ],
                selected: {_type},
                onSelectionChanged: (s) => setState(() => _type = s.first),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _pincode,
                keyboardType: TextInputType.number,
                maxLength: 6,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                onChanged: _onPinChanged,
                decoration: const InputDecoration(
                  labelText: 'Pincode',
                  prefixIcon: Icon(Icons.pin_drop),
                  counterText: '',
                ),
                validator: (v) => (v == null || !PincodeService.isValid(v))
                    ? 'Enter a valid 6-digit pincode'
                    : null,
              ),
              _availability(),
              const SizedBox(height: 12),
              if (_type == 'hourly') ...[
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.black26),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.timer_outlined),
                      const SizedBox(width: 10),
                      const Expanded(child: Text('How many hours?')),
                      IconButton(
                        onPressed: _hours > 1 ? () => setState(() => _hours--) : null,
                        icon: const Icon(Icons.remove_circle_outline),
                      ),
                      Text('$_hours hr',
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                      IconButton(
                        onPressed: _hours < 8 ? () => setState(() => _hours++) : null,
                        icon: const Icon(Icons.add_circle_outline),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ],
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: kTeal.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kTeal.withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_type == 'inspection' ? 'Inspection visit fee' : 'Estimated cost',
                        style: const TextStyle(color: Colors.black54, fontSize: 12)),
                    const SizedBox(height: 2),
                    Text(_estimateText(),
                        style: const TextStyle(
                            fontSize: 22, fontWeight: FontWeight.bold, color: kTeal)),
                    const SizedBox(height: 4),
                    Text(
                      _type == 'inspection'
                          ? 'A technician visits, inspects the problem and gives you a repair quote. You decide whether to go ahead.'
                          : 'Based on hourly rates of technicians near you. The final amount is confirmed by the technician.',
                      style: const TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _address,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Full service address',
                  prefixIcon: Icon(Icons.location_on),
                ),
                validator: (v) => (v == null || v.trim().length < 8)
                    ? 'Enter the full address'
                    : null,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickDate,
                      icon: const Icon(Icons.calendar_today, size: 18),
                      label: Text(_date == null
                          ? 'Pick date'
                          : DateFormat('d MMM y').format(_date!)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickTime,
                      icon: const Icon(Icons.access_time, size: 18),
                      label: Text(_time == null ? 'Pick time' : _time!.format(context)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _notes,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'What is happening? Describe the problem',
                  alignLabelWithHint: true,
                ),
                validator: (v) => (v == null || v.trim().length < 10)
                    ? 'Please describe the problem (at least 10 characters)'
                    : null,
              ),
              const SizedBox(height: 16),
              Text('Photos of the issue (${_photos.length}/$_maxPhotos)',
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              PhotoStrip(
                urls: _photos,
                onRemove: (i) => setState(() => _photos.removeAt(i)),
              ),
              if (_photos.isNotEmpty) const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerLeft,
                child: OutlinedButton.icon(
                  onPressed: (_uploading || _photos.length >= _maxPhotos) ? null : _addPhoto,
                  icon: _uploading
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.add_a_photo),
                  label: Text(_uploading ? 'Uploading...' : 'Add photo'),
                ),
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: (_saving || _uploading) ? null : _submit,
                child: _saving
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : Text(supabase.auth.currentUser == null
                        ? 'Log in to confirm booking'
                        : 'Confirm booking'),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}
