import 'package:flutter/material.dart';

import '../../config.dart';
import '../../theme.dart';
import '../../widgets/common.dart';

class TipsTab extends StatefulWidget {
  const TipsTab({super.key});

  @override
  State<TipsTab> createState() => _TipsTabState();
}

class _TipsTabState extends State<TipsTab> {
  late Future<List<Map<String, dynamic>>> _future;
  String _frequency = 'daily';

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await supabase
        .from('maintenance_tips')
        .select()
        .eq('active', true)
        .order('sort')
        .order('product');
    return List<Map<String, dynamic>>.from(rows);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return ErrorState(
              error: snap.error!, onRetry: () => setState(() => _future = _load()));
        }
        final tips = snap.data!.where((t) => t['frequency'] == _frequency).toList();
        final now = DateTime.now();
        final dayOfYear = now.difference(DateTime(now.year, 1, 1)).inDays;
        final featured = tips.isEmpty
            ? null
            : tips[(_frequency == 'daily' ? dayOfYear : now.month) % tips.length];

        return RefreshIndicator(
          onRefresh: () async {
            setState(() => _future = _load());
            await _future;
          },
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text('Maintenance tips',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text('Simple habits that keep your appliances running longer.',
                  style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 12),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(
                      value: 'daily', icon: Icon(Icons.today), label: Text('Daily')),
                  ButtonSegment(
                      value: 'monthly',
                      icon: Icon(Icons.calendar_month),
                      label: Text('Monthly')),
                ],
                selected: {_frequency},
                onSelectionChanged: (s) => setState(() => _frequency = s.first),
              ),
              const SizedBox(height: 16),
              if (featured != null)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: kTeal,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _frequency == 'daily' ? 'TIP OF THE DAY' : 'TIP OF THE MONTH',
                        style: const TextStyle(
                            color: kAmber, fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      Text('${featured['product']}: ${featured['title']}',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      Text((featured['body'] ?? '').toString(),
                          style: const TextStyle(color: Colors.white)),
                    ],
                  ),
                ),
              const SizedBox(height: 16),
              if (tips.isEmpty)
                const EmptyState(icon: Icons.lightbulb_outline, text: 'No tips yet.')
              else
                ...tips.map(
                  (t) => Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    elevation: 1,
                    shape:
                        RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: kTeal.withOpacity(0.1),
                        child: Icon(serviceIcon((t['product'] ?? '').toString()),
                            color: kTeal),
                      ),
                      title: Text('${t['product']}: ${t['title']}',
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text((t['body'] ?? '').toString()),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
