import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../app_state.dart';
import '../config.dart';
import '../services/cloudinary_service.dart';
import '../services/pincode_service.dart';
import '../widgets/common.dart';

/// Used by both customers and technicians.
class ProfileTab extends StatefulWidget {
  final bool isTechnician;
  const ProfileTab({super.key, required this.isTechnician});

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _pincode = TextEditingController();
  final _bio = TextEditingController();
  final _experience = TextEditingController();
  final _rate = TextEditingController();

  String _email = '';
  String? _photo;
  String _savedPincode = '';
  bool _hasLocation = false;
  bool _loading = true;
  bool _saving = false;
  bool _uploading = false;
  Object? _error;

  // technician only
  List<Map<String, dynamic>> _services = [];
  final Set<String> _selected = {};
  TimeOfDay _start = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _end = const TimeOfDay(hour: 18, minute: 0);

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [_name, _phone, _address, _pincode, _bio, _experience, _rate]) {
      c.dispose();
    }
    super.dispose();
  }

  TimeOfDay _parseTime(dynamic v, TimeOfDay fallback) {
    final parts = (v ?? '').toString().split(':');
    if (parts.length < 2) return fallback;
    final h = int.tryParse(parts[0]);
    final m = int.tryParse(parts[1]);
    if (h == null || m == null) return fallback;
    return TimeOfDay(hour: h, minute: m);
  }

  String _sql(TimeOfDay t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}:00';

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final uid = supabase.auth.currentUser!.id;
      final p = await supabase.from('profiles').select().eq('id', uid).single();
      _name.text = (p['name'] ?? '').toString();
      _phone.text = (p['phone'] ?? '').toString();
      _address.text = (p['address'] ?? '').toString();
      _pincode.text = (p['pincode'] ?? '').toString();
      _savedPincode = _pincode.text;
      _hasLocation = p['lat'] != null && p['lng'] != null;
      _email = (p['email'] ?? supabase.auth.currentUser!.email ?? '').toString();
      _photo = p['photo_url'] as String?;

      if (widget.isTechnician) {
        final svc = await supabase
            .from('services')
            .select('id, name')
            .eq('active', true)
            .order('name');
        _services = List<Map<String, dynamic>>.from(svc);

        final mine = await supabase
            .from('technician_services')
            .select('service_id')
            .eq('technician_id', uid);
        _selected
          ..clear()
          ..addAll(mine.map((r) => r['service_id'] as String));

        final t = await supabase
            .from('technician_profiles')
            .select()
            .eq('id', uid)
            .maybeSingle();
        if (t != null) {
          _bio.text = (t['bio'] ?? '').toString();
          _experience.text = '${t['experience_years'] ?? 0}';
          _rate.text = t['hourly_rate'] == null
              ? ''
              : (num.tryParse('${t['hourly_rate']}') ?? 0).round().toString();
          _start = _parseTime(t['shift_start'], _start);
          _end = _parseTime(t['shift_end'], _end);
        }
      }
    } catch (e) {
      _error = e;
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _changePhoto() async {
    setState(() => _uploading = true);
    try {
      final url = await CloudinaryService.pickAndUpload();
      if (url != null) setState(() => _photo = url);
    } catch (e) {
      if (mounted) snack(context, 'Could not upload photo: $e', error: true);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<void> _pickTime(bool isStart) async {
    final t = await showTimePicker(context: context, initialTime: isStart ? _start : _end);
    if (t == null) return;
    setState(() => isStart ? _start = t : _end = t);
  }

  Future<void> _save() async {
    if (_name.text.trim().length < 2) {
      snack(context, 'Please enter your name', error: true);
      return;
    }
    final pin = _pincode.text.trim();
    if (!PincodeService.isValid(pin)) {
      snack(context, 'Pincode is required (6 digits)', error: true);
      return;
    }
    if (widget.isTechnician) {
      final rate = int.tryParse(_rate.text.trim());
      if (rate == null || rate < 50 || rate > 5000) {
        snack(context, 'Hourly rate must be between 50 and 5000', error: true);
        return;
      }
      if (_selected.isEmpty) {
        snack(context, 'Select at least one service', error: true);
        return;
      }
      if ((_end.hour * 60 + _end.minute) <= (_start.hour * 60 + _start.minute)) {
        snack(context, 'Shift end must be after the start', error: true);
        return;
      }
    }

    setState(() => _saving = true);
    try {
      final uid = supabase.auth.currentUser!.id;
      final update = <String, dynamic>{
        'name': _name.text.trim(),
        'phone': _phone.text.trim(),
        'address': _address.text.trim(),
        'photo_url': _photo,
      };
      if (pin != _savedPincode || !_hasLocation) {
        final info = await PincodeService.lookup(pin);
        if (info == null) {
          if (mounted) {
            snack(context, 'We could not find this pincode', error: true);
            setState(() => _saving = false);
          }
          return;
        }
        update['pincode'] = info.pincode;
        update['lat'] = info.lat;
        update['lng'] = info.lng;
      }
      await supabase.from('profiles').update(update).eq('id', uid);
      _savedPincode = pin;
      _hasLocation = true;

      if (widget.isTechnician) {
        await supabase.from('technician_profiles').upsert({
          'id': uid,
          'name': _name.text.trim(),
          'photo_url': _photo,
          'bio': _bio.text.trim(),
          'experience_years': int.tryParse(_experience.text.trim()) ?? 0,
          'hourly_rate': double.parse(_rate.text.trim()),
          'shift_start': _sql(_start),
          'shift_end': _sql(_end),
        });
        await supabase.from('technician_services').delete().eq('technician_id', uid);
        await supabase.from('technician_services').insert(
              _selected.map((s) => {'technician_id': uid, 'service_id': s}).toList(),
            );
      }
      if (mounted) snack(context, 'Profile saved');
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Could not save: $e', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return ErrorState(error: _error!, onRetry: _load);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Center(
          child: Stack(
            children: [
              CircleAvatar(
                radius: 48,
                backgroundColor: Colors.teal.withOpacity(0.15),
                backgroundImage: _photo != null ? NetworkImage(_photo!) : null,
                child: _photo == null
                    ? const Icon(Icons.person, size: 48, color: Colors.teal)
                    : null,
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: InkWell(
                  onTap: _uploading ? null : _changePhoto,
                  child: CircleAvatar(
                    radius: 16,
                    backgroundColor: Theme.of(context).colorScheme.secondary,
                    child: _uploading
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.camera_alt, size: 16, color: Colors.black87),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Center(child: Text(_email, style: const TextStyle(color: Colors.black54))),
        const SizedBox(height: 20),
        TextField(
          controller: _name,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
              labelText: 'Full name', prefixIcon: Icon(Icons.badge)),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
              labelText: 'Phone number', prefixIcon: Icon(Icons.phone)),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _pincode,
          keyboardType: TextInputType.number,
          maxLength: 6,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: InputDecoration(
            labelText: 'Pincode',
            helperText: widget.isTechnician
                ? 'You get jobs within 10 km of this pincode'
                : 'Used to show technicians within 10 km',
            prefixIcon: const Icon(Icons.pin_drop),
            counterText: '',
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _address,
          maxLines: 2,
          decoration: InputDecoration(
            labelText: widget.isTechnician ? 'Home / base address' : 'Default service address',
            prefixIcon: const Icon(Icons.location_on),
          ),
        ),
        if (widget.isTechnician) ...[
          const SizedBox(height: 20),
          const Text('Services you provide',
              style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: _services.map((s) {
              final id = s['id'] as String;
              return FilterChip(
                label: Text((s['name'] ?? '').toString()),
                selected: _selected.contains(id),
                onSelected: (on) =>
                    setState(() => on ? _selected.add(id) : _selected.remove(id)),
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _experience,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                      labelText: 'Experience (years)', prefixIcon: Icon(Icons.timeline)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _rate,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                      labelText: 'Hourly rate (₹)',
                      prefixIcon: Icon(Icons.currency_rupee)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _pickTime(true),
                  icon: const Icon(Icons.wb_sunny_outlined, size: 18),
                  label: Text('Shift start ${_start.format(context)}'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _pickTime(false),
                  icon: const Icon(Icons.nights_stay_outlined, size: 18),
                  label: Text('End ${_end.format(context)}'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _bio,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'About you (shown to customers)',
              alignLabelWithHint: true,
            ),
          ),
        ],
        const SizedBox(height: 20),
        FilledButton(
          onPressed: (_saving || _uploading) ? null : _save,
          child: _saving
              ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Text('Save changes'),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: signOutAll,
          icon: const Icon(Icons.logout),
          label: const Text('Sign out'),
        ),
        const SizedBox(height: 24),
      ],
    );
  }
}
