import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';

/// Thin wrappers around the job-flow database functions (sql/v2_part11_job_flow.sql).
/// Every step of a job goes through the database, which checks who is allowed to do it.
class JobApi {
  static Future<dynamic> _call(String fn, Map<String, dynamic> params) =>
      supabase.rpc(fn, params: params);

  // Technician
  static Future<void> arrive(String id, String selfieUrl) =>
      _call('job_arrive', {'p_booking': id, 'p_selfie': selfieUrl});

  static Future<bool> verifyStart(String id, String code) async =>
      (await _call('job_verify_start', {'p_booking': id, 'p_code': code})) == true;

  static Future<void> resendStartOtp(String id) =>
      _call('job_resend_start_otp', {'p_booking': id});

  static Future<void> addPhoto(String id, String kind, String url) =>
      _call('job_add_photo', {'p_booking': id, 'p_kind': kind, 'p_url': url});

  static Future<void> removePhoto(String id, String kind, String url) =>
      _call('job_remove_photo', {'p_booking': id, 'p_kind': kind, 'p_url': url});

  static Future<void> addPart(String id, String name, int qty, num price) => _call(
      'job_add_part', {'p_booking': id, 'p_name': name, 'p_qty': qty, 'p_price': price});

  static Future<void> removePart(String partId) =>
      _call('job_remove_part', {'p_part': partId});

  static Future<void> submitParts(String id) => _call('job_submit_parts', {'p_booking': id});

  static Future<void> confirmPayment(String id, bool received) =>
      _call('job_confirm_payment', {'p_booking': id, 'p_received': received});

  // Customer
  static Future<void> partsResponse(String id, bool ok) =>
      _call('job_parts_response', {'p_booking': id, 'p_ok': ok});

  static Future<void> choosePayment(String id, String method) =>
      _call('job_choose_payment', {'p_booking': id, 'p_method': method});

  static Future<bool> finish(String id, String code) async =>
      (await _call('job_finish', {'p_booking': id, 'p_code': code})) == true;

  // Both
  static Future<Map<String, dynamic>> payInfo(String id) async {
    final r = await _call('get_pay_info', {'p_booking': id});
    return Map<String, dynamic>.from(r as Map);
  }

  /// Loads one booking row.
  static Future<Map<String, dynamic>> booking(String id) async {
    final r = await supabase.from('bookings').select('*, services(name)').eq('id', id).single();
    return Map<String, dynamic>.from(r);
  }

  static Future<List<Map<String, dynamic>>> parts(String id) async {
    final r = await supabase.from('job_parts').select().eq('booking_id', id).order('created_at');
    return List<Map<String, dynamic>>.from(r);
  }

  /// START code (customer can read) or END code (technician can read).
  static Future<String?> otp(String id, String kind) async {
    final r = await supabase
        .from('job_otps')
        .select('code')
        .eq('booking_id', id)
        .eq('kind', kind)
        .maybeSingle();
    return r == null ? null : r['code']?.toString();
  }

  /// UPI payment link; the QR code holds exactly this text.
  static String upiLink(Map<String, dynamic> info) {
    final amount = (num.tryParse('${info['amount']}') ?? 0).toStringAsFixed(2);
    return 'upi://pay?pa=${Uri.encodeComponent('${info['upi_id']}')}'
        '&pn=${Uri.encodeComponent('${info['payee_name']}')}'
        '&am=$amount&cu=INR&tn=${Uri.encodeComponent('Fixeaze ${info['ref']}')}';
  }

  static String errText(Object e) {
    if (e is PostgrestException) return e.message;
    return e.toString();
  }

  /// Stages where the customer has to do something.
  static const customerStages = {'arrived', 'parts_review', 'payment_due', 'end_otp'};

  /// Stages where the technician has to look at the screen.
  static const technicianStages = {'payment_check', 'end_otp'};
}
