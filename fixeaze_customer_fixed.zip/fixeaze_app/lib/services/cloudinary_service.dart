import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import '../config.dart';

/// Flow: pick image -> shrink on the device -> upload to Cloudinary ->
/// return a resized Cloudinary URL (this URL is what we save in the database).
class CloudinaryService {
  static final ImagePicker _picker = ImagePicker();

  /// Lets the user pick a photo, uploads it, and returns the final URL.
  /// Returns null if the user cancelled.
  static Future<String?> pickAndUpload() async {
    final XFile? file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1280, // shrink big phone photos before uploading
      maxHeight: 1280,
      imageQuality: 70,
    );
    if (file == null) return null;
    final Uint8List bytes = await file.readAsBytes();
    return upload(bytes, file.name);
  }

  /// Opens the camera (front camera for selfies), uploads, returns the URL.
  /// Returns null if the user cancelled.
  static Future<String?> captureAndUpload({bool front = false}) async {
    final XFile? file = await _picker.pickImage(
      source: ImageSource.camera,
      preferredCameraDevice: front ? CameraDevice.front : CameraDevice.rear,
      maxWidth: 1280,
      maxHeight: 1280,
      imageQuality: 70,
    );
    if (file == null) return null;
    final Uint8List bytes = await file.readAsBytes();
    return upload(bytes, file.name);
  }

  /// Uploads an image OR a video and returns the plain Cloudinary URL.
  static Future<String> uploadAny(Uint8List bytes, String filename) async {
    final uri = Uri.parse(
      'https://api.cloudinary.com/v1_1/${AppConfig.cloudinaryCloudName}/auto/upload',
    );
    final request = http.MultipartRequest('POST', uri)
      ..fields['upload_preset'] = AppConfig.cloudinaryUploadPreset
      ..files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    final response = await http.Response.fromStream(await request.send());
    if (response.statusCode != 200) {
      throw Exception('Upload failed (${response.statusCode}). ${response.body}');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return data['secure_url'] as String;
  }

  static Future<String> upload(Uint8List bytes, String filename) async {
    final uri = Uri.parse(
      'https://api.cloudinary.com/v1_1/${AppConfig.cloudinaryCloudName}/image/upload',
    );
    final request = http.MultipartRequest('POST', uri)
      ..fields['upload_preset'] = AppConfig.cloudinaryUploadPreset
      ..files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));

    final response = await http.Response.fromStream(await request.send());
    if (response.statusCode != 200) {
      throw Exception('Image upload failed (${response.statusCode})');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return optimized(data['secure_url'] as String);
  }

  /// Asks Cloudinary to serve a smaller, auto-compressed version of the image.
  static String optimized(String url, {int width = 800}) {
    if (!url.contains('/upload/')) return url;
    return url.replaceFirst('/upload/', '/upload/w_$width,c_limit,q_auto,f_auto/');
  }
}
