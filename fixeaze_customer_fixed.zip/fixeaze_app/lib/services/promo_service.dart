import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../screens/customer/book_screen.dart';
import 'pincode_service.dart';

/// Loads the banners / advertisements that are live for this user right now.
class PromoService {
  /// Set by a banner / ad that links to an app tab. The home screens listen to this.
  static final ValueNotifier<String?> tabRequest = ValueNotifier<String?>(null);

  static String? _pin;
  static String? _place;
  static String? _forUser;

  /// Clears cached promotion state when the authenticated user changes.
  static void reset() {
    tabRequest.value = null;
    _pin = null;
    _place = null;
    _forUser = null;
  }

  static Future<void> _loadPlace() async {
    final uid = supabase.auth.currentUser?.id;
    if (_forUser == uid && (uid == null || _pin != null)) return;
    _forUser = uid;
    _pin = null;
    _place = null;
    if (uid == null) return; // guests only see promos that are not targeted at a place
    try {
      final p = await supabase.from('profiles').select('pincode').eq('id', uid).maybeSingle();
      final pin = (p?['pincode'] ?? '').toString().trim();
      if (pin.isEmpty) return;
      _pin = pin;
      final info = await PincodeService.lookup(pin);
      if (info != null) _place = '${info.label} ${info.city}';
    } catch (_) {}
  }

  static Future<List<Map<String, dynamic>>> fetch(String kind, String audience) async {
    try {
      await _loadPlace();
      final r = await supabase.rpc('get_promos', params: {
        'p_kind': kind,
        'p_audience': audience,
        'p_pincode': _pin,
        'p_place': _place,
      });
      return (r as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      return <Map<String, dynamic>>[]; // SQL not run yet or offline: show nothing
    }
  }

  /// Follows the link of a banner / ad: a service page, an app tab or a web link.
  static Future<void> open(BuildContext context, Map<String, dynamic> promo) async {
    final type = (promo['link_type'] ?? 'none').toString();
    final value = (promo['link_value'] ?? '').toString().trim();
    if (type == 'none' || value.isEmpty) return;

    if (type == 'url') {
      final uri = Uri.tryParse(value);
      if (uri != null && (uri.scheme == 'https' || uri.scheme == 'http')) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } else if (type == 'tab') {
      tabRequest.value = null; // so the same tab can be requested twice
      tabRequest.value = value;
    } else if (type == 'service') {
      try {
        final s = await supabase.from('services').select().eq('id', value).maybeSingle();
        if (s == null || !context.mounted) return;
        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) =>
                BookScreen(service: Map<String, dynamic>.from(s), initialType: 'hourly'),
          ),
        );
      } catch (_) {}
    }
  }
}
