import 'dart:math';

import 'package:flutter/material.dart';

/// The sign-up code is made inside the app and shown in a popup
/// (nothing is sent by email, SMS or WhatsApp).
class AppOtp {
  static String generate() => (100000 + Random.secure().nextInt(900000)).toString();

  static Future<void> show(BuildContext context, String code) {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Your Fixeaze OTP'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Type this code on the next screen to continue.'),
            const SizedBox(height: 14),
            Text(code,
                style: const TextStyle(
                    fontSize: 38, fontWeight: FontWeight.bold, letterSpacing: 8)),
          ],
        ),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK')),
        ],
      ),
    );
  }
}
