class Validators {
  static const List<List<int>> _d = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
    [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
    [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
    [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
    [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
    [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
    [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
    [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
    [9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
  ];

  static const List<List<int>> _p = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
    [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
    [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
    [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
    [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
    [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
    [7, 0, 4, 6, 9, 1, 3, 2, 5, 8],
  ];

  /// Checks that a 12-digit Aadhaar number is well formed (format + checksum).
  /// This only catches typing mistakes. It does NOT prove the card is real.
  static bool aadhaar(String input) {
    final s = input.replaceAll(RegExp(r'\s'), '');
    if (!RegExp(r'^[2-9][0-9]{11}$').hasMatch(s)) return false;
    var c = 0;
    final digits = s.split('').map(int.parse).toList().reversed.toList();
    for (var i = 0; i < digits.length; i++) {
      c = _d[c][_p[i % 8][digits[i]]];
    }
    return c == 0;
  }

  static bool bankAccount(String s) => RegExp(r'^[0-9]{9,18}$').hasMatch(s.trim());

  static bool ifsc(String s) =>
      RegExp(r'^[A-Z]{4}0[A-Z0-9]{6}$').hasMatch(s.trim().toUpperCase());

  static bool upi(String s) =>
      RegExp(r'^[a-zA-Z0-9.\-_]{2,}@[a-zA-Z]{2,}$').hasMatch(s.trim());

  static bool email(String s) =>
      RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(s.trim());

  /// Lower-case, single spaces, so "Ravi  Kumar" matches "ravi kumar".
  static String normName(String s) =>
      s.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');
}
