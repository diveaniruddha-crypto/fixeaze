import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../services/cloudinary_service.dart';
import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

AdminStore get _s => AdminStore.I;

const _customerTabs = {
  'services': 'Services (home)',
  'tips': 'Tips',
  'bookings': 'My bookings',
  'profile': 'Profile',
};
const _technicianTabs = {
  'jobs': 'Open jobs (home)',
  'myjobs': 'My jobs',
  'chats': 'Chats',
  'calendar': 'Calendar',
  'payments': 'Payments',
};

String _audienceLabel(String a) =>
    a == 'customer' ? 'Customers' : (a == 'technician' ? 'Technicians' : 'Everyone');

// ============================================================== BANNERS & ADS

class PromosPage extends StatefulWidget {
  const PromosPage({super.key});
  @override
  State<PromosPage> createState() => _PromosPageState();
}

class _PromosPageState extends State<PromosPage> {
  String _kind = 'all';

  String _status(Rec p) {
    if (p['active'] == false) return 'Off';
    final today = dkey(DateTime.now());
    if (today.compareTo('${p['date_from']}') < 0) return 'Scheduled';
    if (today.compareTo('${p['date_to']}') > 0) return 'Ended';
    return 'Live';
  }

  Widget _thumb(Rec p) {
    if (p['media_type'] == 'video') {
      return Container(
        width: 64,
        height: 40,
        color: Colors.black87,
        child: const Icon(Icons.play_circle, color: Colors.white),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: Image.network('${p['media_url']}',
          width: 64,
          height: 40,
          fit: BoxFit.cover,
          errorBuilder: (c, e, s) => const SizedBox(width: 64, height: 40, child: Icon(Icons.broken_image))),
    );
  }

  String _place(Rec p) {
    final parts = <String>[];
    if ('${p['city'] ?? ''}'.trim().isNotEmpty) parts.add('${p['city']}');
    if ('${p['pincode'] ?? ''}'.trim().isNotEmpty) parts.add('PIN ${p['pincode']}');
    return parts.isEmpty ? 'All places' : parts.join(', ');
  }

  String _link(Rec p) {
    final t = '${p['link_type']}';
    final v = '${p['link_value'] ?? ''}';
    if (t == 'service') return 'Service: ${_s.svcName(v)}';
    if (t == 'tab') return 'Page: ${_customerTabs[v] ?? _technicianTabs[v] ?? v}';
    if (t == 'url') return v;
    return 'No link';
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final list = s.promos.where((p) => _kind == 'all' || p['kind'] == _kind).toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (s.errors['promos'] != null)
          NoticeBanner(
              'Run sql/v2_part12_promos.sql in Supabase first. (${s.errors['promos']})',
              color: kBad),
        Wrap(spacing: 10, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          FilledButton.icon(
            style: FilledButton.styleFrom(minimumSize: const Size(0, 40)),
            onPressed: () => showDialog<void>(
                context: context, builder: (_) => const _PromoDialog(null)),
            icon: const Icon(Icons.add),
            label: const Text('New banner / advertisement'),
          ),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'all', label: Text('All')),
              ButtonSegment(value: 'banner', label: Text('Banners')),
              ButtonSegment(value: 'ad', label: Text('Ads')),
            ],
            selected: {_kind},
            onSelectionChanged: (v) => setState(() => _kind = v.first),
          ),
          CsvButton(
            name: 'banners_and_ads',
            headers: () => ['Type', 'Title', 'Shows to', 'Place', 'From', 'To', 'Link', 'Status', 'Media'],
            rows: () => [
              for (final p in s.promos)
                [p['kind'] == 'ad' ? 'Advertisement' : 'Banner', p['title'], _audienceLabel('${p['audience']}'),
                 _place(p), p['date_from'], p['date_to'], _link(p), _status(p), p['media_url']],
            ],
          ),
        ]),
        const SizedBox(height: 6),
        const Muted(
            'Banner: small slider on the home page (best size 1200 x 375, image). '
            'Advertisement: full screen when the app opens, with a Skip button (image or video).'),
        const SizedBox(height: 12),
        AdminTable(
          columns: const ['', 'Title', 'Shows to', 'Dates', 'Link', 'Status', ''],
          empty: 'No banners or advertisements yet.',
          rows: [
            for (final p in list)
              <Widget>[
                _thumb(p),
                TwoLine('${p['title']}', p['kind'] == 'ad' ? 'Advertisement' : 'Banner'),
                TwoLine(_audienceLabel('${p['audience']}'), _place(p)),
                Text('${fday(p['date_from'])} - ${fday(p['date_to'])}'),
                SizedBox(width: 170, child: Text(_link(p), overflow: TextOverflow.ellipsis, maxLines: 2)),
                () {
                  final st = _status(p);
                  return Pill(
                      st,
                      st == 'Live'
                          ? kOk
                          : (st == 'Scheduled' ? kInfo : Colors.grey.shade700));
                }(),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
                    onPressed: () => showDialog<void>(
                        context: context, builder: (_) => _PromoDialog(p)),
                    child: const Text('Edit'),
                  ),
                  const SizedBox(width: 6),
                  IconButton(
                    tooltip: 'Delete',
                    onPressed: () async {
                      final ok = await confirmBox(context, 'Delete "${p['title']}"?', yes: 'Delete');
                      if (!ok) return;
                      final err = await s.promoDelete('${p['id']}', '${p['title']}');
                      if (context.mounted) report(context, err, 'Deleted');
                    },
                    icon: const Icon(Icons.delete_outline),
                  ),
                ]),
              ],
          ],
        ),
      ],
    );
  }
}

class _PromoDialog extends StatefulWidget {
  final Rec? promo;
  const _PromoDialog(this.promo);
  @override
  State<_PromoDialog> createState() => _PromoDialogState();
}

class _PromoDialogState extends State<_PromoDialog> {
  late String _kind;
  late String _audience;
  late String _linkType;
  late String _linkValue; // service id / tab id (url lives in _url)
  late DateTime _from;
  late DateTime _to;
  late bool _active;
  String _mediaUrl = '';
  String _mediaType = 'image';
  bool _uploading = false;
  bool _busy = false;
  late final TextEditingController _title;
  late final TextEditingController _url;
  late final TextEditingController _city;
  late final TextEditingController _pin;

  @override
  void initState() {
    super.initState();
    final p = widget.promo;
    final today = DateTime.now();
    DateTime d(dynamic v, DateTime fb) => DateTime.tryParse('${v ?? ''}') ?? fb;
    _kind = p == null ? 'banner' : '${p['kind']}';
    _audience = p == null ? 'customer' : '${p['audience']}';
    _linkType = p == null ? 'none' : '${p['link_type']}';
    _linkValue = p == null || _linkType == 'url' ? '' : '${p['link_value'] ?? ''}';
    _from = p == null ? DateTime(today.year, today.month, today.day) : d(p['date_from'], today);
    _to = p == null ? DateTime(today.year, today.month, today.day).add(const Duration(days: 7)) : d(p['date_to'], today);
    _active = p == null ? true : p['active'] != false;
    _mediaUrl = p == null ? '' : '${p['media_url']}';
    _mediaType = p == null ? 'image' : '${p['media_type']}';
    _title = TextEditingController(text: p == null ? '' : '${p['title']}');
    _url = TextEditingController(text: p != null && _linkType == 'url' ? '${p['link_value'] ?? ''}' : '');
    _city = TextEditingController(text: p == null ? '' : '${p['city'] ?? ''}');
    _pin = TextEditingController(text: p == null ? '' : '${p['pincode'] ?? ''}');
  }

  @override
  void dispose() {
    _title.dispose();
    _url.dispose();
    _city.dispose();
    _pin.dispose();
    super.dispose();
  }

  List<String> get _linkTypes => _audience == 'customer'
      ? ['none', 'service', 'tab', 'url']
      : (_audience == 'technician' ? ['none', 'tab', 'url'] : ['none', 'service', 'url']);

  static const _linkNames = {
    'none': 'No link',
    'service': 'A service (e.g. Plumbing)',
    'tab': 'A page of the app',
    'url': 'Any web link',
  };

  Future<void> _pick(bool video) async {
    try {
      final picker = ImagePicker();
      final XFile? f = video
          ? await picker.pickVideo(source: ImageSource.gallery)
          : await picker.pickImage(source: ImageSource.gallery, maxWidth: 1920, imageQuality: 85);
      if (f == null) return;
      final bytes = await f.readAsBytes();
      if (video && bytes.length > 60 * 1024 * 1024) {
        if (mounted) toast(context, 'Video is over 60 MB. Please use a shorter or smaller video.', error: true);
        return;
      }
      setState(() => _uploading = true);
      final url = await CloudinaryService.uploadAny(bytes, f.name);
      if (!mounted) return;
      setState(() {
        _mediaUrl = url;
        _mediaType = video ? 'video' : 'image';
      });
    } catch (e) {
      if (mounted) toast(context, 'Upload failed: $e', error: true);
    }
    if (mounted) setState(() => _uploading = false);
  }

  Future<void> _date(bool from) async {
    final d = await showDatePicker(
      context: context,
      initialDate: from ? _from : _to,
      firstDate: DateTime(2024),
      lastDate: DateTime(2035),
    );
    if (d == null) return;
    setState(() {
      if (from) {
        _from = d;
        if (_to.isBefore(_from)) _to = _from;
      } else {
        _to = d;
        if (_to.isBefore(_from)) _from = _to;
      }
    });
  }

  Future<void> _save() async {
    final title = _title.text.trim();
    if (title.isEmpty) return toast(context, 'Give it a title', error: true);
    if (_mediaUrl.isEmpty) return toast(context, 'Upload an image or video first', error: true);
    String? value;
    if (_linkType == 'url') {
      value = _url.text.trim();
      if (!(value.startsWith('https://') || value.startsWith('http://'))) {
        return toast(context, 'Web link must start with https://', error: true);
      }
    } else if (_linkType == 'service' || _linkType == 'tab') {
      value = _linkValue;
      if (value.isEmpty) return toast(context, 'Choose where the link should go', error: true);
    }
    setState(() => _busy = true);
    final err = await _s.promoSave(widget.promo == null ? null : '${widget.promo!['id']}', {
      'kind': _kind,
      'title': title,
      'media_url': _mediaUrl,
      'media_type': _kind == 'banner' ? 'image' : _mediaType,
      'link_type': _linkType,
      'link_value': value,
      'audience': _audience,
      'date_from': dkey(_from),
      'date_to': dkey(_to),
      'city': _city.text.trim().isEmpty ? null : _city.text.trim(),
      'pincode': _pin.text.trim().isEmpty ? null : _pin.text.replaceAll(' ', ''),
      'active': _active,
    });
    if (!mounted) return;
    setState(() => _busy = false);
    report(context, err, 'Saved');
    if (err == null) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final tabs = _audience == 'technician' ? _technicianTabs : _customerTabs;
    final services = _s.services;
    return AlertDialog(
      title: Text(widget.promo == null ? 'New banner / advertisement' : 'Edit'),
      content: SizedBox(
        width: 460,
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'banner', label: Text('Banner'), icon: Icon(Icons.view_carousel)),
                ButtonSegment(value: 'ad', label: Text('Full-screen ad'), icon: Icon(Icons.fullscreen)),
              ],
              selected: {_kind},
              onSelectionChanged: (v) => setState(() {
                _kind = v.first;
                if (_kind == 'banner') _mediaType = 'image';
              }),
            ),
            const SizedBox(height: 12),
            TextField(
                controller: _title,
                decoration: const InputDecoration(labelText: 'Title (only you see this)', hintText: '10% off on plumbing')),
            const SizedBox(height: 12),
            if (_mediaUrl.isNotEmpty)
              Container(
                height: 120,
                width: double.infinity,
                color: Colors.black12,
                child: _mediaType == 'video'
                    ? const Center(child: Icon(Icons.videocam, size: 40))
                    : Image.network(_mediaUrl, fit: BoxFit.contain),
              ),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              OutlinedButton.icon(
                onPressed: _uploading ? null : () => _pick(false),
                icon: const Icon(Icons.image),
                label: Text(_mediaUrl.isEmpty ? 'Upload image' : 'Change image'),
              ),
              if (_kind == 'ad')
                OutlinedButton.icon(
                  onPressed: _uploading ? null : () => _pick(true),
                  icon: const Icon(Icons.videocam),
                  label: const Text('Upload video'),
                ),
              if (_uploading)
                const Padding(
                    padding: EdgeInsets.all(8),
                    child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))),
            ]),
            const SizedBox(height: 4),
            Muted(_kind == 'banner'
                ? 'Banner image, wide shape works best (1200 x 375).'
                : 'Ad image should be portrait (1080 x 1920) or a short video under 60 MB.'),
            const Divider(height: 28),
            DropdownButtonFormField<String>(
              value: _audience,
              decoration: const InputDecoration(labelText: 'Show to'),
              items: const [
                DropdownMenuItem(value: 'customer', child: Text('Customers')),
                DropdownMenuItem(value: 'technician', child: Text('Technicians')),
                DropdownMenuItem(value: 'both', child: Text('Customers and technicians')),
              ],
              onChanged: (v) => setState(() {
                _audience = v ?? 'customer';
                if (!_linkTypes.contains(_linkType)) _linkType = 'none';
                _linkValue = '';
              }),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _date(true),
                  icon: const Icon(Icons.event),
                  label: Text('From ${fday(dkey(_from))}'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _date(false),
                  icon: const Icon(Icons.event),
                  label: Text('To ${fday(dkey(_to))}'),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            TextField(
                controller: _city,
                decoration: const InputDecoration(
                    labelText: 'City (optional)', hintText: 'Leave empty to show in every city')),
            const SizedBox(height: 10),
            TextField(
                controller: _pin,
                decoration: const InputDecoration(
                    labelText: 'Pincode (optional)',
                    hintText: 'One pincode, or several separated by commas')),
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Muted('Visitors who are not logged in only see promos with no city and no pincode.'),
            ),
            const Divider(height: 28),
            DropdownButtonFormField<String>(
              value: _linkTypes.contains(_linkType) ? _linkType : 'none',
              decoration: const InputDecoration(labelText: 'When someone taps it, open'),
              items: [
                for (final t in _linkTypes) DropdownMenuItem(value: t, child: Text(_linkNames[t]!)),
              ],
              onChanged: (v) => setState(() {
                _linkType = v ?? 'none';
                _linkValue = '';
              }),
            ),
            if (_linkType == 'service') ...[
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: services.any((x) => '${x['id']}' == _linkValue) ? _linkValue : null,
                decoration: const InputDecoration(labelText: 'Which service'),
                items: [
                  for (final x in services)
                    DropdownMenuItem(value: '${x['id']}', child: Text('${x['name']}')),
                ],
                onChanged: (v) => setState(() => _linkValue = v ?? ''),
              ),
            ],
            if (_linkType == 'tab') ...[
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: tabs.containsKey(_linkValue) ? _linkValue : null,
                decoration: const InputDecoration(labelText: 'Which page'),
                items: [
                  for (final e in tabs.entries) DropdownMenuItem(value: e.key, child: Text(e.value)),
                ],
                onChanged: (v) => setState(() => _linkValue = v ?? ''),
              ),
            ],
            if (_linkType == 'url') ...[
              const SizedBox(height: 10),
              TextField(
                  controller: _url,
                  keyboardType: TextInputType.url,
                  decoration: const InputDecoration(labelText: 'Web link', hintText: 'https://')),
            ],
            const SizedBox(height: 6),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Switched on'),
              value: _active,
              onChanged: (v) => setState(() => _active = v),
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: (_busy || _uploading) ? null : _save,
          child: _busy
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('Save'),
        ),
      ],
    );
  }
}
