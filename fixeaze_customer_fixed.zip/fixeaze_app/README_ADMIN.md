# Fixeaze Admin (Flutter)

Same Flutter project as the customer / technician app, but a **second entry point**: `lib/main_admin.dart`.
The customer app is untouched (it still builds from `lib/main.dart`).

## 1. Database (once)
Supabase > SQL Editor, new query each time:
1. `sql/v2_part9_admin_access.sql`
2. `sql/v2_part10_admin_tracking.sql`

## 2. Make admin accounts (you and your 2 partners)
Each person signs up once in the normal app (as a customer), then run for each email:

    update public.profiles set role = 'admin', approved = true
    where email = 'partner@example.com';

## 3. Host the admin site (separate link)
1. GitHub > New repository, e.g. `fixeaze-admin`.
2. Upload two things: `fixeaze_app.zip` (same zip as the customer app) and the workflow file
   `admin_site/build.yml`, saved in the repo as `.github/workflows/build.yml`.
   (On a phone: Add file > Create new file, type `.github/workflows/build.yml` as the name, paste the contents.)
3. Settings > Pages > Source: **GitHub Actions**.
4. Wait for the green tick under Actions. Link: `https://<github-name>.github.io/fixeaze-admin/`

Custom domain later: Settings > Pages > Custom domain (e.g. `admin.yourdomain.com`).
If you use a custom domain, change `--base-href "/${{ github.event.repository.name }}/"` in the workflow to `--base-href "/"`.

## 4. Link the two sites
Supabase > Authentication > URL Configuration: Site URL = customer app link; add the admin link under Redirect URLs.

## What is inside
Overview, Approvals (Aadhaar + selfie + bank), SOS (live alert banner), Payments, Bookings, People, Services, Team
(green online dot, hours per day, action log). Every section has a CSV download that follows the date filters.
Difference from the HTML version: SOS shows coordinates + "Open map" (Google Maps) instead of an embedded map, and there is no Print button (use the CSV).

## Job flow, bank details and commission (SQL part 11)
Run `sql/v2_part11_job_flow.sql` once (after parts 1-10). Then in the admin open **Bank & commission**:
add the Fixeaze UPI ID (the payment QR is made from it) and set the commission %.
Cash jobs: the technician keeps the cash, the commission is deducted from their next QR-job payment,
and you can also mark it received by hand in the same page.

## Banners and advertisements (SQL part 12)
Run `sql/v2_part12_promos.sql` once. Then admin > **Banners & ads** > New.
Banner = slider on the home page. Advertisement = full screen with Skip button (image or video).
Choose who sees it, dates, optional city / pincode, and where a tap goes (a service, an app page, or any web link).
