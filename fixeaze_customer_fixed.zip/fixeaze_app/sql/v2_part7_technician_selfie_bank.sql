-- Selfie + bank account details for technicians.
-- Stored in technician_kyc, which is already private (own row or admin only).
alter table public.technician_kyc add column if not exists selfie_image_path text;
alter table public.technician_kyc add column if not exists bank_holder_name text;
alter table public.technician_kyc add column if not exists bank_name text;
alter table public.technician_kyc add column if not exists bank_account_no text;
alter table public.technician_kyc add column if not exists bank_ifsc text;
alter table public.technician_kyc add column if not exists upi_id text;
