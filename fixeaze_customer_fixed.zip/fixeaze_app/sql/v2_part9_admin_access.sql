-- Lets an admin account (profiles.role = 'admin') use the Admin Dashboard.
-- Run once. Safe to run twice. Normal users are NOT affected: every rule checks is_admin().

drop policy if exists "admin all profiles" on public.profiles;
create policy "admin all profiles" on public.profiles for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admin all services" on public.services;
create policy "admin all services" on public.services for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admin read reviews" on public.reviews;
create policy "admin read reviews" on public.reviews for select to authenticated
  using (public.is_admin());

drop policy if exists "admin all bookings" on public.bookings;
create policy "admin all bookings" on public.bookings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

grant select, update on public.profiles to authenticated;
grant select, insert, update on public.services to authenticated;
grant select on public.reviews to authenticated;
grant select, update on public.bookings to authenticated;
