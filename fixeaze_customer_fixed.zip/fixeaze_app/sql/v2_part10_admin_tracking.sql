-- Admin team tracking: who is online, how long each admin works per day, and an action log.
-- Run once (safe to run twice). Needs v2_part9 first.

create table if not exists public.admin_presence (
  admin_id uuid primary key references public.profiles(id) on delete cascade,
  last_seen timestamptz not null default now(),
  page text,
  is_active boolean not null default false
);

create table if not exists public.admin_activity (
  admin_id uuid not null references public.profiles(id) on delete cascade,
  day date not null,
  seconds_online int not null default 0,
  seconds_active int not null default 0,
  first_seen timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  primary key (admin_id, day)
);

create table if not exists public.admin_actions (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid not null references public.profiles(id) on delete cascade,
  action text not null,
  detail text,
  created_at timestamptz not null default now()
);
create index if not exists admin_actions_time_idx on public.admin_actions (created_at desc);

alter table public.admin_presence enable row level security;
alter table public.admin_activity enable row level security;
alter table public.admin_actions enable row level security;

drop policy if exists "admins read presence" on public.admin_presence;
create policy "admins read presence" on public.admin_presence for select to authenticated using (public.is_admin());
drop policy if exists "admins read activity" on public.admin_activity;
create policy "admins read activity" on public.admin_activity for select to authenticated using (public.is_admin());
drop policy if exists "admins read actions" on public.admin_actions;
create policy "admins read actions" on public.admin_actions for select to authenticated using (public.is_admin());

grant select on public.admin_presence, public.admin_activity, public.admin_actions to authenticated;

-- Called by the dashboard every 30 seconds. Only counts time if the previous ping was recent.
create or replace function public.admin_ping(p_active boolean, p_page text)
returns void language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  prev timestamptz;
  delta int := 0;
  today date := (now() at time zone 'Asia/Kolkata')::date;
begin
  if not public.is_admin() then raise exception 'Not an admin'; end if;

  select last_seen into prev from public.admin_presence where admin_id = uid;
  if prev is not null and now() - prev <= interval '120 seconds' then
    delta := least(extract(epoch from (now() - prev))::int, 90);
  end if;

  insert into public.admin_presence (admin_id, last_seen, page, is_active)
  values (uid, now(), p_page, coalesce(p_active, false))
  on conflict (admin_id) do update
    set last_seen = now(), page = excluded.page, is_active = excluded.is_active;

  insert into public.admin_activity (admin_id, day, seconds_online, seconds_active, first_seen, last_seen)
  values (uid, today, delta, case when p_active then delta else 0 end, now(), now())
  on conflict (admin_id, day) do update
    set seconds_online = public.admin_activity.seconds_online + delta,
        seconds_active = public.admin_activity.seconds_active + case when p_active then delta else 0 end,
        last_seen = now();
end $$;

create or replace function public.admin_offline()
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then return; end if;
  update public.admin_presence set last_seen = now() - interval '10 minutes', is_active = false
  where admin_id = auth.uid();
end $$;

create or replace function public.admin_log(p_action text, p_detail text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then return; end if;
  insert into public.admin_actions (admin_id, action, detail)
  values (auth.uid(), left(p_action, 120), left(p_detail, 500));
end $$;

revoke execute on function public.admin_ping(boolean, text) from public, anon;
revoke execute on function public.admin_offline() from public, anon;
revoke execute on function public.admin_log(text, text) from public, anon;
grant execute on function public.admin_ping(boolean, text) to authenticated;
grant execute on function public.admin_offline() to authenticated;
grant execute on function public.admin_log(text, text) to authenticated;
