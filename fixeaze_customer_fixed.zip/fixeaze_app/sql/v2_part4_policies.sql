alter table public.technician_services enable row level security;
alter table public.technician_kyc enable row level security;
alter table public.messages enable row level security;
alter table public.maintenance_tips enable row level security;

drop policy if exists "tech profiles read" on public.technician_profiles;
create policy "tech profiles read" on public.technician_profiles for select to authenticated
  using (id = auth.uid() or public.is_admin() or public.is_approved_profile(id));

drop policy if exists "tech profiles insert" on public.technician_profiles;
create policy "tech profiles insert" on public.technician_profiles for insert to authenticated
  with check ((id = auth.uid() and public.is_technician_role()) or public.is_admin());

drop policy if exists "tech profiles update" on public.technician_profiles;
create policy "tech profiles update" on public.technician_profiles for update to authenticated
  using ((id = auth.uid() and public.is_technician_role()) or public.is_admin())
  with check ((id = auth.uid() and public.is_technician_role()) or public.is_admin());

drop policy if exists "tech services read" on public.technician_services;
create policy "tech services read" on public.technician_services for select to authenticated
  using (true);

drop policy if exists "tech services insert" on public.technician_services;
create policy "tech services insert" on public.technician_services for insert to authenticated
  with check ((technician_id = auth.uid() and public.is_technician_role()) or public.is_admin());

drop policy if exists "tech services delete" on public.technician_services;
create policy "tech services delete" on public.technician_services for delete to authenticated
  using ((technician_id = auth.uid() and public.is_technician_role()) or public.is_admin());

drop policy if exists "kyc read" on public.technician_kyc;
create policy "kyc read" on public.technician_kyc for select to authenticated
  using (id = auth.uid() or public.is_admin());

drop policy if exists "kyc insert" on public.technician_kyc;
create policy "kyc insert" on public.technician_kyc for insert to authenticated
  with check ((id = auth.uid() and public.is_technician_role()) or public.is_admin());

drop policy if exists "kyc update" on public.technician_kyc;
create policy "kyc update" on public.technician_kyc for update to authenticated
  using ((id = auth.uid() and not public.is_approved_profile(id)) or public.is_admin())
  with check ((id = auth.uid() and not public.is_approved_profile(id)) or public.is_admin());

drop policy if exists "bookings read" on public.bookings;
create policy "bookings read" on public.bookings for select to authenticated
  using (public.is_admin()
    or customer_id = auth.uid()
    or technician_id = auth.uid()
    or (status = 'pending' and technician_id is null and public.can_take_job(service_id, lat, lng)));

drop policy if exists "bookings update" on public.bookings;
create policy "bookings update" on public.bookings for update to authenticated
  using (public.is_admin()
    or customer_id = auth.uid()
    or technician_id = auth.uid()
    or (status = 'pending' and technician_id is null and public.can_take_job(service_id, lat, lng)))
  with check (true);

drop policy if exists "messages read" on public.messages;
create policy "messages read" on public.messages for select to authenticated
  using (public.is_booking_party(booking_id) or public.is_admin());

drop policy if exists "messages send" on public.messages;
create policy "messages send" on public.messages for insert to authenticated
  with check (sender_id = auth.uid() and public.can_chat(booking_id));

drop policy if exists "tips read" on public.maintenance_tips;
create policy "tips read" on public.maintenance_tips for select to anon, authenticated
  using (active = true or public.is_admin());

drop policy if exists "tips admin" on public.maintenance_tips;
create policy "tips admin" on public.maintenance_tips for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

grant select, insert, delete on public.technician_services to authenticated;
grant select, insert, update on public.technician_kyc to authenticated;
grant select, insert on public.messages to authenticated;
grant select on public.maintenance_tips to anon;
grant select, insert, update, delete on public.maintenance_tips to authenticated;

grant execute on function public.technicians_nearby(double precision, double precision, uuid, double precision) to anon, authenticated;
grant execute on function public.can_take_job(uuid, double precision, double precision) to authenticated;
grant execute on function public.can_chat(uuid) to authenticated;
grant execute on function public.is_booking_party(uuid) to authenticated;
grant execute on function public.is_technician_role() to authenticated;
grant execute on function public.is_approved_profile(uuid) to authenticated;
