-- Fixeaze part 13: "Forgot password" without email.
-- A customer or technician types full name + mobile + email. If all three match their account,
-- they may set a new password. Admin accounts can NOT be reset this way.
-- Wrong guesses are limited to 5 per email per hour.
-- Run once in Supabase > SQL Editor > New query. Safe to run twice.

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.reset_attempts (
  id bigserial primary key,
  email text not null,
  at timestamptz not null default now()
);
alter table public.reset_attempts enable row level security; -- no policies: nobody can read it

create or replace function public._reset_match(p_name text, p_phone text, p_email text)
returns uuid language plpgsql security definer set search_path = public, auth, extensions as $$
declare uid uuid;
begin
  select u.id into uid
  from auth.users u
  join public.profiles p on p.id = u.id
  where lower(u.email) = lower(trim(p_email))
    and lower(regexp_replace(trim(p.name), '\s+', ' ', 'g'))
        = lower(regexp_replace(trim(p_name), '\s+', ' ', 'g'))
    and length(regexp_replace(coalesce(p_phone, ''), '\D', '', 'g')) >= 10
    and right(regexp_replace(coalesce(p.phone, ''), '\D', '', 'g'), 10)
        = right(regexp_replace(coalesce(p_phone, ''), '\D', '', 'g'), 10)
    and p.role <> 'admin';
  return uid;
end $$;
revoke all on function public._reset_match(text, text, text) from public, anon, authenticated;

create or replace function public._reset_limit(p_email text)
returns void language plpgsql security definer set search_path = public as $$
begin
  delete from public.reset_attempts where at < now() - interval '1 day';
  if (select count(*) from public.reset_attempts
      where email = lower(trim(p_email)) and at > now() - interval '1 hour') >= 5 then
    raise exception 'Too many wrong tries. Please try again after one hour.';
  end if;
end $$;
revoke all on function public._reset_limit(text) from public, anon, authenticated;

-- Step 1: do the details match? (true / false)
create or replace function public.reset_check(p_name text, p_phone text, p_email text)
returns boolean language plpgsql security definer set search_path = public, auth, extensions as $$
declare uid uuid;
begin
  perform public._reset_limit(p_email);
  uid := public._reset_match(p_name, p_phone, p_email);
  if uid is null then
    insert into public.reset_attempts (email) values (lower(trim(p_email)));
    return false;
  end if;
  return true;
end $$;

-- Step 2: check again and set the new password
create or replace function public.reset_password(p_name text, p_phone text, p_email text, p_new text)
returns boolean language plpgsql security definer set search_path = public, auth, extensions as $$
declare uid uuid;
begin
  perform public._reset_limit(p_email);
  if p_new is null or length(p_new) < 6 then raise exception 'Password must be at least 6 characters'; end if;
  uid := public._reset_match(p_name, p_phone, p_email);
  if uid is null then
    insert into public.reset_attempts (email) values (lower(trim(p_email)));
    return false;
  end if;

  update auth.users
     set encrypted_password = extensions.crypt(p_new, extensions.gen_salt('bf', 10)),
         updated_at = now()
   where id = uid;

  begin
    delete from auth.sessions where user_id = uid; -- log out other devices
  exception when others then null;
  end;
  delete from public.reset_attempts where email = lower(trim(p_email));
  return true;
end $$;

revoke all on function public.reset_check(text, text, text) from public;
revoke all on function public.reset_password(text, text, text, text) from public;
grant execute on function public.reset_check(text, text, text) to anon, authenticated;
grant execute on function public.reset_password(text, text, text, text) to anon, authenticated;
