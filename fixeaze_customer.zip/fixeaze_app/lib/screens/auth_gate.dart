import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../app_state.dart';
import '../config.dart';
import '../services/promo_service.dart';
import '../services/session_guard.dart';
import '../services/session_policy.dart';
import '../widgets/common.dart';
import 'complete_profile_screen.dart';
import 'customer/customer_home.dart';
import 'institution/institution_home.dart';
import 'login_screen.dart';
import 'technician/technician_home.dart';

/// Decides which screen to show: login (with "Skip for now"), guest browsing,
/// customer app, technician app, "waiting for approval", or the admin notice.
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> with WidgetsBindingObserver {
  Duration _limit = const Duration(hours: 3);
  StreamSubscription<AuthState>? _sub;
  Future<Map<String, dynamic>?>? _profile;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _reload();
    _sub = supabase.auth.onAuthStateChange.listen((_) {
      PromoService.reset();
      if (mounted) setState(_reload);
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && supabase.auth.currentUser != null) {
      SessionPolicy.expired(_limit).then((gone) {
        if (gone) _expiredOut();
      });
    }
  }

  Future<void> _expiredOut() async {
    SessionPolicy.stop();
    await signOutAll();
    if (!mounted) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Please log in again'),
          content: const Text('For your safety you were logged out after being away for a while.'),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
        ),
      );
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sub?.cancel();
    super.dispose();
  }

  void _reload() {
    final user = supabase.auth.currentUser;
    if (user == null) {
      SessionGuard.stop();
      SessionPolicy.stop();
      _profile = null;
      return;
    }
    _profile = _fetch(user.id).then((p) async {
      if (p != null && p['role'] != 'admin') {
        _limit = SessionPolicy.limitFor('${p['role']}', p['_institution'] != null);
        final fresh = await SessionPolicy.consumeFresh();
        if (fresh) SessionGuard.freshLogin = true;
        if (fresh || SessionGuard.freshLogin) {
          await SessionPolicy.touch();
        } else if (await SessionPolicy.expired(_limit)) {
          _expiredOut();
          return p;
        }
        SessionPolicy.start();
        SessionGuard.begin(_kicked);
      } else {
        SessionGuard.stop();
      }
      return p;
    });
  }

  Future<void> _kicked() async {
    await signOutAll();
    if (!mounted) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Logged out'),
          content: const Text(
              'Your account was opened on another device, so you were logged out here. '
              'Only one device can be logged in at a time.'),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
        ),
      );
    });
  }

  Future<Map<String, dynamic>?> _fetch(String id) async {
    final p = await supabase.from('profiles').select().eq('id', id).maybeSingle();
    if (p == null) return null;
    // institution owners are normal accounts that also own an institution
    try {
      final inst = await supabase.from('institutions').select().eq('owner_id', id).maybeSingle();
      if (inst != null) return {...p, '_institution': inst};
    } catch (_) {
      // institutions not set up yet -> behave as before
    }
    return p;
  }

  @override
  Widget build(BuildContext context) {
    if (_profile == null) {
      return ValueListenableBuilder<bool>(
        valueListenable: AppState.guest,
        builder: (context, guest, _) => guest
            ? const CustomerHome(profile: null)
            : const LoginScreen(showSkip: true),
      );
    }

    return FutureBuilder<Map<String, dynamic>?>(
      future: _profile,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snap.hasError || snap.data == null) {
          return Scaffold(
            appBar: AppBar(title: const AppBarTitle()),
            body: ErrorState(
              error: snap.error ?? 'Your profile was not found.',
              onRetry: () => setState(_reload),
            ),
            floatingActionButton: FloatingActionButton.extended(
              onPressed: signOutAll,
              icon: const Icon(Icons.logout),
              label: const Text('Sign out'),
            ),
          );
        }

        final profile = snap.data!;
        if (profile['_institution'] != null && profile['role'] != 'admin') {
          return InstitutionHome(
              profile: profile, institution: Map<String, dynamic>.from(profile['_institution'] as Map));
        }
        switch (profile['role']) {
          case 'technician':
            if (profile['approved'] == true) {
              return TechnicianHome(profile: profile);
            }
            return PendingApprovalScreen(onCheck: () => setState(_reload));
          case 'admin':
            return const AdminNoticeScreen();
          default:
            if ('${profile['phone'] ?? ''}'.trim().isEmpty) {
              return CompleteProfileScreen(profile: profile, onDone: () => setState(_reload));
            }
            return CustomerHome(profile: profile);
        }
      },
    );
  }
}

class PendingApprovalScreen extends StatelessWidget {
  final VoidCallback onCheck;
  const PendingApprovalScreen({super.key, required this.onCheck});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const AppBarTitle()),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Constrained(
            maxWidth: 420,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.hourglass_top, size: 64, color: Colors.orange),
                const SizedBox(height: 16),
                const Text('Application under review',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text(
                  'Thanks for applying to Fixeaze! Our team is checking your Aadhaar '
                  'details against your name. You can accept jobs as soon as you are approved.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: onCheck,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Check status'),
                  ),
                ),
                const SizedBox(height: 8),
                TextButton(onPressed: signOutAll, child: const Text('Sign out')),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class AdminNoticeScreen extends StatelessWidget {
  const AdminNoticeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const AppBarTitle()),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.admin_panel_settings, size: 64, color: Colors.teal),
              const SizedBox(height: 16),
              const Text('This is an admin account',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Please use the Fixeaze Admin site to manage the business.',
                  textAlign: TextAlign.center),
              const SizedBox(height: 24),
              OutlinedButton(onPressed: signOutAll, child: const Text('Sign out')),
            ],
          ),
        ),
      ),
    );
  }
}
