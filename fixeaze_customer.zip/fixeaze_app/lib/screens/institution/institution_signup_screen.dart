import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../services/app_otp.dart';
import '../../services/session_policy.dart';
import '../../services/session_guard.dart';
import '../../services/pincode_service.dart';
import '../../services/validators.dart';
import '../../widgets/common.dart';

/// Register an institution (company / team) and its owner login.
class InstitutionSignupScreen extends StatefulWidget {
  const InstitutionSignupScreen({super.key});
  @override
  State<InstitutionSignupScreen> createState() => _InstitutionSignupScreenState();
}

class _InstitutionSignupScreenState extends State<InstitutionSignupScreen> {
  final _form = GlobalKey<FormState>();
  final _inst = TextEditingController();
  final _addr = TextEditingController();
  final _pin = TextEditingController();
  final _gst = TextEditingController();
  final _owner = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _holder = TextEditingController();
  final _bank = TextEditingController();
  final _acc = TextEditingController();
  final _ifsc = TextEditingController();
  final _upi = TextEditingController();
  final _otp = TextEditingController();
  bool _agree = false;
  bool _busy = false;
  bool _showPass = false;
  int _step = 0; // 0 form, 1 otp
  String _code = '';

  @override
  void dispose() {
    for (final c in [_inst, _addr, _pin, _gst, _owner, _phone, _email, _pass, _holder, _bank, _acc, _ifsc, _upi, _otp]) {
      c.dispose();
    }
    super.dispose();
  }

  String? _req(String? v, [String what = 'This']) => (v == null || v.trim().isEmpty) ? '$what is required' : null;

  Future<void> _next() async {
    if (!_form.currentState!.validate()) return;
    if (_upi.text.trim().isEmpty && _acc.text.trim().isEmpty) {
      snack(context, 'Give bank account details or a UPI id so we can pay the institution.', error: true);
      return;
    }
    if (!_agree) {
      snack(context, 'Please accept the terms to continue.', error: true);
      return;
    }
    final dup = await AccountCheck.problem(supabase, _email.text, _phone.text);
    if (dup != null) {
      if (mounted) snack(context, dup, error: true);
      return;
    }
    _code = AppOtp.generate();
    _otp.clear();
    setState(() => _step = 1);
    await AppOtp.show(context, _code);
  }

  Future<void> _submit() async {
    if (_otp.text.trim() != _code) {
      snack(context, 'Wrong OTP. Please check the code in the popup.', error: true);
      return;
    }
    setState(() => _busy = true);
    try {
      final pin = await PincodeService.lookup(_pin.text);
      SessionGuard.freshLogin = true;
      final res = await supabase.auth.signUp(
        email: _email.text.trim(),
        password: _pass.text,
        data: {
          'role': 'customer',
          'name': _owner.text.trim(),
          'phone': _phone.text.trim(),
          'pincode': _pin.text.trim(),
          if (pin != null) 'lat': pin.lat,
          if (pin != null) 'lng': pin.lng,
        },
      );
      if (res.user != null && (res.user!.identities ?? []).isEmpty) {
        throw 'This email is already registered. Please log in instead.';
      }
      if (res.session == null) {
        throw 'Sign-up needs "Confirm email" switched OFF in Supabase (Authentication > Sign In / Providers > Email).';
      }
      await supabase.rpc('institution_register', params: {
        'p_name': _inst.text.trim(),
        'p_address': _addr.text.trim(),
        'p_pincode': _pin.text.trim(),
        'p_gst': _gst.text.trim().toUpperCase(),
        'p_holder': _holder.text.trim(),
        'p_bank': _bank.text.trim(),
        'p_account': _acc.text.trim(),
        'p_ifsc': _ifsc.text.trim().toUpperCase(),
        'p_upi': _upi.text.trim(),
      });
      // make the app re-read the account so it opens the institution screen
      await supabase.auth.refreshSession();
      if (!mounted) return;
      snack(context, 'Institution registered! Our team will review it shortly.');
      Navigator.of(context).popUntil((r) => r.isFirst);
    } on AuthException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, '$e', error: true);
    }
    if (mounted) setState(() => _busy = false);
  }

  Widget _f(TextEditingController c, String label,
          {String? Function(String?)? v, TextInputType? type, bool obscure = false, int? maxLen, Widget? suffix, TextCapitalization cap = TextCapitalization.none}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          controller: c,
          keyboardType: type,
          obscureText: obscure,
          maxLength: maxLen,
          textCapitalization: cap,
          validator: v,
          decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), suffixIcon: suffix, counterText: ''),
        ),
      );

  Widget _h(String t) => Padding(
        padding: const EdgeInsets.only(top: 8, bottom: 10),
        child: Text(t, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Register your institution')),
      body: SafeArea(
        child: Constrained(
          maxWidth: 560,
          child: _step == 1 ? _otpView() : _formView(),
        ),
      ),
    );
  }

  Widget _otpView() => ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Enter the OTP shown in the popup', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        TextField(
          controller: _otp,
          keyboardType: TextInputType.number,
          maxLength: 6,
          decoration: const InputDecoration(labelText: '6-digit OTP', border: OutlineInputBorder()),
        ),
        FilledButton(
          onPressed: _busy ? null : _submit,
          child: _busy
              ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('Create institution account'),
        ),
        TextButton(onPressed: _busy ? null : () => AppOtp.show(context, _code), child: const Text('Show the OTP again')),
        TextButton(onPressed: _busy ? null : () => setState(() => _step = 0), child: const Text('Back')),
      ]);

  Widget _formView() => Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(20), children: [
          _h('Institution'),
          _f(_inst, 'Institution / company name', v: (v) => _req(v, 'Name'), cap: TextCapitalization.words),
          _f(_addr, 'Address', v: (v) => _req(v, 'Address')),
          _f(_pin, 'Pincode', type: TextInputType.number, maxLen: 6,
              v: (v) => PincodeService.isValid(v ?? '') ? null : 'Enter a valid 6-digit pincode'),
          _f(_gst, 'GST number (optional)', cap: TextCapitalization.characters),
          _h('Owner login'),
          _f(_owner, 'Owner full name', v: (v) => _req(v, 'Name'), cap: TextCapitalization.words),
          _f(_phone, 'Owner mobile number', type: TextInputType.phone, maxLen: 10,
              v: (v) => RegExp(r'^[6-9][0-9]{9}$').hasMatch((v ?? '').trim()) ? null : 'Enter a valid 10-digit number'),
          _f(_email, 'Owner email (used to log in)', type: TextInputType.emailAddress,
              v: (v) => Validators.email(v ?? '') ? null : 'Enter a valid email'),
          _f(_pass, 'Password (min 6 characters)', obscure: !_showPass,
              v: (v) => (v ?? '').length < 6 ? 'At least 6 characters' : null,
              suffix: IconButton(
                  icon: Icon(_showPass ? Icons.visibility_off : Icons.visibility),
                  onPressed: () => setState(() => _showPass = !_showPass))),
          _h('Where should we pay the institution?'),
          _f(_holder, 'Account holder name', cap: TextCapitalization.words),
          _f(_bank, 'Bank name'),
          _f(_acc, 'Account number', type: TextInputType.number,
              v: (v) => (v ?? '').trim().isEmpty || Validators.bankAccount(v!) ? null : 'Enter 9-18 digits'),
          _f(_ifsc, 'IFSC code', cap: TextCapitalization.characters,
              v: (v) => (v ?? '').trim().isEmpty || Validators.ifsc(v!) ? null : 'Invalid IFSC'),
          _f(_upi, 'UPI id (optional if bank given)',
              v: (v) => (v ?? '').trim().isEmpty || Validators.upi(v!) ? null : 'Invalid UPI id'),
          CheckboxListTile(
            value: _agree,
            onChanged: (v) => setState(() => _agree = v ?? false),
            contentPadding: EdgeInsets.zero,
            controlAffinity: ListTileControlAffinity.leading,
            title: const Text('I confirm these details are correct. Payments for all my employees\' jobs will be made to this institution.'),
          ),
          const SizedBox(height: 8),
          FilledButton(onPressed: _next, child: const Text('Continue')),
        ]),
      );
}
