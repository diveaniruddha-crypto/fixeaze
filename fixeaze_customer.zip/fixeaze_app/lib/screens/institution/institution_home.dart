import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app_state.dart';
import '../../config.dart';
import '../../services/validators.dart';
import '../../widgets/common.dart';
import '../help_screen.dart';
import '../support_chat_screen.dart';
import 'employee_form_screen.dart';

typedef _Rec = Map<String, dynamic>;

num _n(dynamic v) => num.tryParse('$v') ?? 0;

/// Short readable id shown for bookings and employees.
String _short(dynamic id) => '#${'$id'.replaceAll('-', '').substring(0, 8).toUpperCase()}';

DateTime? _t(dynamic v) => v == null ? null : DateTime.tryParse('$v')?.toLocal();

/// Hours worked on a job: real start/finish when known, else the booked hours.
double _hours(_Rec b) {
  final a = _t(b['started_at']);
  final f = _t(b['finished_at']);
  if (a != null && f != null && f.isAfter(a)) return f.difference(a).inMinutes / 60;
  return _n(b['hours']).toDouble();
}

class _Data {
  final List<_Rec> employees; // profile + technician_profiles merged
  final List<_Rec> jobs;
  final List<_Rec> payments;
  final List<_Rec> payouts;
  final List<_Rec> notes;
  _Data(this.employees, this.jobs, this.payments, this.payouts, this.notes);
}

/// The institution owner's login: employees, hours, earnings and payouts.
class InstitutionHome extends StatefulWidget {
  final _Rec profile;
  final _Rec institution;
  const InstitutionHome({super.key, required this.profile, required this.institution});

  @override
  State<InstitutionHome> createState() => _InstitutionHomeState();
}

class _InstitutionHomeState extends State<InstitutionHome> {
  int _tab = 0;
  late Future<_Data> _future;
  String? _empFilter; // employee id used to filter jobs

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _future = _load();
    // a new institution starts on the Employees tab so the owner can add the team straight away
    if ('${widget.institution['status']}' == 'pending') _tab = 1;
  }

  void _refresh() => setState(() => _future = _load());

  Future<_Data> _load() async {
    final tps = List<_Rec>.from(await supabase
        .from('technician_profiles')
        .select()
        .eq('institution_id', widget.institution['id']));
    final ids = tps.map((e) => '${e['id']}').toList();
    var profs = <_Rec>[];
    var jobs = <_Rec>[];
    var pays = <_Rec>[];
    if (ids.isNotEmpty) {
      profs = List<_Rec>.from(await supabase.from('profiles').select().inFilter('id', ids));
      jobs = List<_Rec>.from(await supabase
          .from('bookings')
          .select('*, services(name)')
          .inFilter('technician_id', ids)
          .order('scheduled_at', ascending: false)
          .limit(1000));
      pays = List<_Rec>.from(await supabase
          .from('technician_payments')
          .select()
          .inFilter('technician_id', ids)
          .order('created_at', ascending: false));
    }
    final payouts = List<_Rec>.from(await supabase
        .from('technician_payouts')
        .select()
        .eq('technician_id', _uid)
        .order('created_at', ascending: false));
    final notes = List<_Rec>.from(await supabase
        .from('technician_notifications')
        .select()
        .eq('technician_id', _uid)
        .order('created_at', ascending: false)
        .limit(30));
    final emps = <_Rec>[
      for (final tp in tps)
        {
          ...tp,
          'profile': profs.firstWhere((p) => '${p['id']}' == '${tp['id']}', orElse: () => <String, dynamic>{}),
        }
    ];
    return _Data(emps, jobs, pays, payouts, notes);
  }

  @override
  Widget build(BuildContext context) {
    final inst = widget.institution;
    final status = '${inst['status']}';
    if (status == 'suspended') return _waiting(status);

    final titles = ['Overview', 'Employees', 'Jobs', 'Payments', 'Account'];
    return Scaffold(
      appBar: AppBar(
        title: Text('${inst['name']}'),
        actions: [
          IconButton(
              tooltip: 'Message Fixeaze Support',
              icon: const Icon(Icons.chat_bubble_outline),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SupportChatScreen()))),
          IconButton(
              tooltip: 'Help',
              icon: const Icon(Icons.help_outline),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HelpScreen()))),
          IconButton(tooltip: 'Refresh', icon: const Icon(Icons.refresh), onPressed: _refresh),
          IconButton(tooltip: 'Log out', icon: const Icon(Icons.logout), onPressed: signOutAll),
        ],
      ),
      floatingActionButton: _tab == 1
          ? FloatingActionButton.extended(
              onPressed: _addEmployee, icon: const Icon(Icons.person_add), label: const Text('Add employee'))
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: [
          for (final e in [
            [Icons.dashboard_outlined, titles[0]],
            [Icons.groups_outlined, titles[1]],
            [Icons.work_outline, titles[2]],
            [Icons.account_balance_wallet_outlined, titles[3]],
            [Icons.business_outlined, titles[4]],
          ])
            NavigationDestination(icon: Icon(e[0] as IconData), label: e[1] as String),
        ],
      ),
      body: FutureBuilder<_Data>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) return ErrorState(error: snap.error!, onRetry: _refresh);
          final d = snap.data!;
          final pending = '${inst['status']}' == 'pending';
          return Constrained(
            child: Column(children: [
              if (pending)
                Container(
                  width: double.infinity,
                  color: Colors.orange.shade100,
                  padding: const EdgeInsets.all(12),
                  child: const Text(
                      'Your institution is waiting for Fixeaze approval. You can add your employees now. '
                      'They can take jobs once you are approved.'),
                ),
              Expanded(child: RefreshIndicator(
              onRefresh: () async {
                _refresh();
                await _future;
              },
              child: switch (_tab) {
                0 => _overview(d),
                1 => _employeesTab(d),
                2 => _jobsTab(d),
                3 => _paymentsTab(d),
                _ => _accountTab(d),
              },
            )),
            ]),
          );
        },
      ),
    );
  }

  Widget _waiting(String status) {
    final suspended = status == 'suspended';
    return Scaffold(
      appBar: AppBar(title: Text('${widget.institution['name']}')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Constrained(
            maxWidth: 420,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(suspended ? Icons.block : Icons.hourglass_top, size: 64, color: suspended ? Colors.red : Colors.orange),
              const SizedBox(height: 16),
              Text(suspended ? 'Institution suspended' : 'Institution under review',
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(
                suspended
                    ? 'Your institution account has been suspended. Please contact Fixeaze support.'
                    : 'Thanks for registering! Our team is reviewing your institution. You can add employees as soon as you are approved.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () async {
                    await supabase.auth.refreshSession();
                  },
                  icon: const Icon(Icons.refresh),
                  label: const Text('Check status'),
                ),
              ),
              TextButton(onPressed: signOutAll, child: const Text('Sign out')),
            ]),
          ),
        ),
      ),
    );
  }

  // ------------------------------------------------------------ overview

  Widget _stat(String label, String value, {String sub = ''}) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            if (sub.isNotEmpty) Text(sub, style: const TextStyle(fontSize: 12, color: Colors.black54)),
          ]),
        ),
      );

  Widget _grid(List<Widget> tiles) => LayoutBuilder(builder: (context, c) {
        final cols = c.maxWidth > 700 ? 4 : 2;
        const gap = 10.0;
        final w = (c.maxWidth - gap * (cols - 1)) / cols;
        return Wrap(spacing: gap, runSpacing: gap, children: [for (final t in tiles) SizedBox(width: w, child: t)]);
      });

  List<_Rec> _done(_Data d) => d.jobs.where((j) => j['status'] == 'completed').toList();

  num _sum(Iterable<_Rec> l) => l.fold<num>(0, (a, p) => a + _n(p['amount']));

  Widget _overview(_Data d) {
    final done = _done(d);
    final hours = done.fold<double>(0, (a, j) => a + _hours(j));
    final unpaid = d.payments.where((p) => p['status'] == 'pending' || p['status'] == 'processing');
    final paid = d.payments.where((p) => p['status'] == 'paid');
    final dates = {for (final p in unpaid) if (p['pay_on'] != null) '${p['pay_on']}'.substring(0, 10)}.toList()..sort();
    final active = d.jobs.where((j) => j['status'] == 'in_progress' || j['status'] == 'accepted').length;
    return ListView(padding: const EdgeInsets.all(16), children: [
      _grid([
        _stat('Employees', '${d.employees.length}', sub: '${d.employees.where((e) => e['paused'] == true).length} paused'),
        _stat('Jobs done', '${done.length}', sub: '$active running / upcoming'),
        _stat('Hours worked', hours.toStringAsFixed(1)),
        _stat('Total earned', money(_sum(d.payments)), sub: 'after Fixeaze commission'),
        _stat('To be paid', money(_sum(unpaid)),
            sub: dates.isEmpty ? 'no date set yet' : 'on ${dates.first}'),
        _stat('Already paid', money(_sum(paid))),
      ]),
      if (d.notes.isNotEmpty) ...[
        const SizedBox(height: 18),
        const Text('Updates from Fixeaze', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        for (final n in d.notes.take(5))
          Card(child: ListTile(title: Text('${n['title'] ?? ''}'), subtitle: Text('${n['body'] ?? ''}'))),
      ],
    ]);
  }

  // ------------------------------------------------------------ employees

  String _ename(_Rec e) {
    final p = e['profile'] as _Rec? ?? {};
    final n = '${p['name'] ?? ''}'.trim();
    return n.isEmpty ? 'Employee' : n;
  }

  Widget _employeesTab(_Data d) {
    if (d.employees.isEmpty) {
      return ListView(children: const [
        SizedBox(height: 80),
        Icon(Icons.groups_outlined, size: 56, color: Colors.black38),
        SizedBox(height: 12),
        Center(child: Text('No employees yet. Tap "Add employee" to create their login.')),
      ]);
    }
    return ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 90), children: [
      for (final e in d.employees)
        () {
          final id = '${e['id']}';
          final jobs = d.jobs.where((j) => '${j['technician_id']}' == id && j['status'] == 'completed').toList();
          final hrs = jobs.fold<double>(0, (a, j) => a + _hours(j));
          final earned = _sum(d.payments.where((p) => '${p['technician_id']}' == id));
          final p = e['profile'] as _Rec? ?? {};
          final paused = e['paused'] == true;
          return Card(
            child: ListTile(
              leading: CircleAvatar(child: Text(_ename(e)[0].toUpperCase())),
              title: Text(_ename(e)),
              subtitle: Text('ID ${_short(id)} · ${p['phone'] ?? ''}\n${jobs.length} jobs · ${hrs.toStringAsFixed(1)} h · ${money(earned)} earned'
                  '${paused ? '\nPaused (not receiving jobs)' : ''}'),
              isThreeLine: true,
              trailing: PopupMenuButton<String>(
                onSelected: (v) => _employeeAction(v, e),
                itemBuilder: (_) => [
                  PopupMenuItem(value: 'jobs', child: const Text('View jobs')),
                  PopupMenuItem(value: 'pause', child: Text(paused ? 'Resume' : 'Pause')),
                  const PopupMenuItem(value: 'password', child: Text('Reset password')),
                ],
              ),
            ),
          );
        }(),
    ]);
  }

  Future<void> _employeeAction(String a, _Rec e) async {
    final id = '${e['id']}';
    try {
      if (a == 'jobs') {
        setState(() {
          _empFilter = id;
          _tab = 2;
        });
      } else if (a == 'pause') {
        await supabase.rpc('institution_employee_pause', params: {'p_employee': id, 'p_paused': e['paused'] != true});
        _refresh();
      } else if (a == 'password') {
        final c = TextEditingController();
        final ok = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text('New password for ${_ename(e)}'),
            content: TextField(controller: c, decoration: const InputDecoration(labelText: 'New password (min 6)')),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
            ],
          ),
        );
        if (ok == true) {
          if (c.text.length < 6) throw 'Password must be at least 6 characters';
          await supabase.rpc('institution_employee_password', params: {'p_employee': id, 'p_password': c.text});
          if (mounted) snack(context, 'Password changed. Tell ${_ename(e)} the new password.');
        }
      }
    } catch (err) {
      if (mounted) snack(context, '$err', error: true);
    }
  }

  Future<void> _addEmployee() async {
    final created = await Navigator.push<Map<String, String>>(
      context,
      MaterialPageRoute(builder: (_) => EmployeeFormScreen(defaultPin: '${widget.institution['pincode'] ?? ''}')),
    );
    if (created != null) {
      _refresh();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Employee created'),
          content: SelectableText('Share these login details with ${created['name']}:\n\n'
              'Email: ${created['email']}\nPassword: ${created['password']}\n\n'
              'They log in from the normal Fixeaze login screen.'),
          actions: [
            TextButton(
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: 'Fixeaze login\nEmail: ${created['email']}\nPassword: ${created['password']}'));
                  snack(ctx, 'Copied');
                },
                child: const Text('Copy')),
            FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Done')),
          ],
        ),
      );
    }
  }

  // ------------------------------------------------------------ jobs

  Widget _jobsTab(_Data d) {
    final jobs = d.jobs.where((j) => _empFilter == null || '${j['technician_id']}' == _empFilter).toList();
    String nameOf(dynamic id) {
      final e = d.employees.where((e) => '${e['id']}' == '$id');
      return e.isEmpty ? 'Employee' : _ename(e.first);
    }

    return ListView(padding: const EdgeInsets.all(16), children: [
      DropdownButtonFormField<String?>(
        value: _empFilter,
        decoration: const InputDecoration(labelText: 'Employee', border: OutlineInputBorder()),
        items: [
          const DropdownMenuItem(value: null, child: Text('All employees')),
          for (final e in d.employees) DropdownMenuItem(value: '${e['id']}', child: Text(_ename(e))),
        ],
        onChanged: (v) => setState(() => _empFilter = v),
      ),
      const SizedBox(height: 10),
      if (jobs.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('No jobs yet.'))),
      for (final j in jobs)
        Card(
          child: ListTile(
            title: Text('${(j['services'] as Map?)?['name'] ?? 'Job'} · ${nameOf(j['technician_id'])}'),
            subtitle: Text('Booking ${_short(j['id'])} · ${fmtDate(j['scheduled_at'])}\n'
                '${j['status']} · ${_hours(j).toStringAsFixed(1)} h'
                '${j['price'] != null ? ' · ${money(j['price'])}' : ''}'),
            isThreeLine: true,
          ),
        ),
    ]);
  }

  // ------------------------------------------------------------ payments

  Widget _paymentsTab(_Data d) {
    String nameOf(dynamic id) {
      final e = d.employees.where((e) => '${e['id']}' == '$id');
      return e.isEmpty ? 'Employee' : _ename(e.first);
    }

    Color col(String s) => s == 'paid' ? Colors.green : (s == 'failed' ? Colors.red : Colors.orange);
    final unpaid = _sum(d.payments.where((p) => p['status'] == 'pending' || p['status'] == 'processing'));
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        color: Colors.teal.shade50,
        child: ListTile(
          leading: const Icon(Icons.account_balance),
          title: Text('Payments go to ${widget.institution['name']}'),
          subtitle: Text('${widget.institution['bank_name'] ?? ''} ${widget.institution['bank_account_no'] ?? ''} '
              '${widget.institution['upi_id'] ?? ''}\nWaiting to be paid: ${money(unpaid)}'),
          isThreeLine: true,
        ),
      ),
      if (d.payouts.isNotEmpty) ...[
        const SizedBox(height: 8),
        const Text('Payouts received', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        for (final p in d.payouts)
          Card(
            child: ListTile(
              leading: const Icon(Icons.check_circle, color: Colors.green),
              title: Text(money(p['amount'])),
              subtitle: Text('${p['jobs']} jobs · ${fmtDate(p['created_at'])}'
                  '${(p['reference'] ?? '').toString().isEmpty ? '' : '\nRef: ${p['reference']}'}'),
            ),
          ),
      ],
      const SizedBox(height: 8),
      const Text('Earnings per job', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      if (d.payments.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('No earnings yet.'))),
      for (final p in d.payments)
        Card(
          child: ListTile(
            title: Text('${money(p['amount'])} · ${nameOf(p['technician_id'])}'),
            subtitle: Text('Job total ${money(p['gross'])} · commission ${money(p['commission'])}'
                '${p['pay_on'] != null && p['status'] != 'paid' ? '\nPay date: ${'${p['pay_on']}'.substring(0, 10)}' : ''}'),
            trailing: Chip(
              label: Text('${p['status']}', style: const TextStyle(color: Colors.white, fontSize: 12)),
              backgroundColor: col('${p['status']}'),
            ),
          ),
        ),
    ]);
  }

  // ------------------------------------------------------------ account

  Widget _accountTab(_Data d) {
    final i = widget.institution;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${i['name']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('${i['address'] ?? ''} ${i['pincode'] ?? ''}'),
            if ('${i['gst'] ?? ''}'.isNotEmpty) Text('GST: ${i['gst']}'),
            const Divider(height: 24),
            const Text('Payment details', style: TextStyle(fontWeight: FontWeight.bold)),
            Text('Account holder: ${i['bank_holder_name'] ?? '-'}'),
            Text('Bank: ${i['bank_name'] ?? '-'}'),
            Text('Account no: ${i['bank_account_no'] ?? '-'}'),
            Text('IFSC: ${i['bank_ifsc'] ?? '-'}'),
            Text('UPI: ${i['upi_id'] ?? '-'}'),
            const SizedBox(height: 12),
            OutlinedButton.icon(onPressed: _editAccount, icon: const Icon(Icons.edit), label: const Text('Edit details')),
          ]),
        ),
      ),
      const SizedBox(height: 10),
      Text('Owner: ${widget.profile['name'] ?? ''} · ${widget.profile['phone'] ?? ''}'),
    ]);
  }

  Future<void> _editAccount() async {
    final i = widget.institution;
    final ctrls = {
      'name': TextEditingController(text: '${i['name'] ?? ''}'),
      'address': TextEditingController(text: '${i['address'] ?? ''}'),
      'holder': TextEditingController(text: '${i['bank_holder_name'] ?? ''}'),
      'bank': TextEditingController(text: '${i['bank_name'] ?? ''}'),
      'account': TextEditingController(text: '${i['bank_account_no'] ?? ''}'),
      'ifsc': TextEditingController(text: '${i['bank_ifsc'] ?? ''}'),
      'upi': TextEditingController(text: '${i['upi_id'] ?? ''}'),
    };
    const labels = {
      'name': 'Institution name',
      'address': 'Address',
      'holder': 'Account holder',
      'bank': 'Bank name',
      'account': 'Account number',
      'ifsc': 'IFSC',
      'upi': 'UPI id',
    };
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit institution'),
        content: SizedBox(
          width: 420,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              for (final k in ctrls.keys)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: TextField(controller: ctrls[k], decoration: InputDecoration(labelText: labels[k], border: const OutlineInputBorder())),
                ),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final acc = ctrls['account']!.text.trim();
      final ifsc = ctrls['ifsc']!.text.trim().toUpperCase();
      final upi = ctrls['upi']!.text.trim();
      if (acc.isNotEmpty && !Validators.bankAccount(acc)) throw 'Account number must be 9-18 digits';
      if (ifsc.isNotEmpty && !Validators.ifsc(ifsc)) throw 'Invalid IFSC';
      if (upi.isNotEmpty && !Validators.upi(upi)) throw 'Invalid UPI id';
      await supabase.rpc('institution_update', params: {
        'p_name': ctrls['name']!.text.trim(),
        'p_address': ctrls['address']!.text.trim(),
        'p_holder': ctrls['holder']!.text.trim(),
        'p_bank': ctrls['bank']!.text.trim(),
        'p_account': acc,
        'p_ifsc': ifsc,
        'p_upi': upi,
      });
      await supabase.auth.refreshSession(); // AuthGate re-reads the institution
      if (mounted) snack(context, 'Saved');
    } catch (e) {
      if (mounted) snack(context, '$e', error: true);
    }
  }
}
