import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../config.dart';
import '../services/file_save.dart';
import '../services/invoice_model.dart';
import '../services/invoice_pdf.dart' deferred as pdfmod;
import '../widgets/common.dart';

/// Shows an invoice (customer) or payment invoice (technician) with a PDF download.
class InvoiceScreen extends StatefulWidget {
  final String? bookingId; // customer invoice
  final String? paymentId; // technician payment invoice
  const InvoiceScreen.customer({super.key, required this.bookingId}) : paymentId = null;
  const InvoiceScreen.technician({super.key, required this.paymentId}) : bookingId = null;

  @override
  State<InvoiceScreen> createState() => _InvoiceScreenState();
}

class _InvoiceScreenState extends State<InvoiceScreen> {
  late final Future<InvoiceData> _future = widget.bookingId != null ? _customer() : _technician();
  bool _busy = false;

  num _n(dynamic v) => v is num ? v : (num.tryParse('${v ?? ''}') ?? 0);
  DateTime _d(dynamic v) => DateTime.tryParse('${v ?? ''}')?.toLocal() ?? DateTime.now();
  String _no(Map b) => ('${b['booking_no'] ?? ''}').isNotEmpty ? '${b['booking_no']}' : '${b['id']}'.substring(0, 8).toUpperCase();
  String _when(dynamic v) => DateFormat('d MMM yyyy, h:mm a').format(_d(v));

  Future<InvoiceData> _customer() async {
    final uid = supabase.auth.currentUser!.id;
    final b = await supabase.from('bookings').select('*, services(name)').eq('id', widget.bookingId!).single();
    final me = await supabase.from('profiles').select('name, phone, email').eq('id', uid).maybeSingle();
    Map<String, dynamic>? tech;
    if (b['technician_id'] != null) {
      tech = await supabase.from('technician_profiles').select('name').eq('id', b['technician_id']).maybeSingle();
    }
    var parts = <Map<String, dynamic>>[];
    try {
      parts = List<Map<String, dynamic>>.from(await supabase.from('job_parts').select().eq('booking_id', b['id']));
    } catch (_) {}
    final partsSum = parts.fold<num>(0, (s, p) => s + _n(p['qty']) * _n(p['price']));
    final labour = b['price'] != null ? _n(b['price']) : (b['gross_total'] != null ? _n(b['gross_total']) - partsSum : 0);
    final total = b['gross_total'] != null ? _n(b['gross_total']) : labour + partsSum;
    final svc = ((b['services'] as Map?)?['name'] ?? 'Service').toString();
    final hours = b['hours'];
    return InvoiceData(
      title: 'INVOICE',
      number: 'INV-${_no(b)}',
      date: _d(b['finished_at'] ?? b['scheduled_at']),
      parties: [
        ['Billed to', '${me?['name'] ?? 'Customer'}'],
        if ('${me?['phone'] ?? ''}'.isNotEmpty) ['Phone', '${me!['phone']}'],
        ['Service address', '${b['address'] ?? '-'}'],
      ],
      details: [
        ['Booking ID', _no(b)],
        ['Service date', _when(b['scheduled_at'])],
        ['Technician', '${tech?['name'] ?? '-'}'],
        if ('${b['payment_method'] ?? ''}'.isNotEmpty) ['Payment method', '${b['payment_method']}'.toUpperCase()],
      ],
      tableHead: const ['Description', 'Amount'],
      tableRows: [
        ['$svc${hours != null ? ' ($hours hr)' : ''} - service charge', inr(labour)],
        for (final p in parts) ['${p['name']}  x ${p['qty']}', inr(_n(p['qty']) * _n(p['price']))],
      ],
      totals: [
        if (parts.isNotEmpty) InvoiceLine('Parts', partsSum),
        if (_n(b['discount_amount']) > 0) InvoiceLine('Offer ${b['offer_code'] ?? ''}', -_n(b['discount_amount'])),
        InvoiceLine('Total paid', total, bold: true),
      ],
    );
  }

  Future<InvoiceData> _technician() async {
    final uid = supabase.auth.currentUser!.id;
    final p = await supabase
        .from('technician_payments')
        .select('*, bookings(*, services(name))')
        .eq('id', widget.paymentId!)
        .single();
    final b = Map<String, dynamic>.from((p['bookings'] as Map?) ?? {'id': p['id']});
    final me = await supabase.from('profiles').select('name, phone, email').eq('id', uid).maybeSingle();
    final disc = _n(b['discount_amount']);
    final gross = (b['gross_total'] != null ? _n(b['gross_total']) : _n(p['amount'])) + disc;
    final comm = b['commission_amount'] != null ? _n(b['commission_amount']) : _n(p['commission']);
    final pct = b['commission_pct'];
    final svc = ((b['services'] as Map?)?['name'] ?? 'Service').toString();
    final status = '${p['status'] ?? 'pending'}';
    return InvoiceData(
      title: 'PAYMENT INVOICE',
      number: 'PAY-${_no(b)}',
      date: _d(p['paid_at'] ?? p['created_at']),
      parties: [
        ['Paid to', '${me?['name'] ?? 'Technician'}'],
        if ('${me?['phone'] ?? ''}'.isNotEmpty) ['Phone', '${me!['phone']}'],
      ],
      details: [
        ['Booking ID', _no(b)],
        ['Service', svc],
        if (b['scheduled_at'] != null) ['Job date', _when(b['scheduled_at'])],
        ['Payment status', status.toUpperCase()],
        if (p['paid_at'] != null) ['Paid on', _when(p['paid_at'])],
        if ('${p['reference'] ?? ''}'.isNotEmpty) ['Reference', '${p['reference']}'],
      ],
      tableHead: const ['Description', 'Amount'],
      tableRows: [
        [disc > 0 ? 'Job total (customer used an offer, Fixeaze covers it)' : 'Job total collected from customer', inr(gross)],
        if (comm > 0) ['Fixeaze commission${pct != null ? ' ($pct%)' : ''}', '- ${inr(comm)}'],
      ],
      totals: [InvoiceLine(status == 'paid' ? 'Net amount paid' : 'Net payout', _n(p['amount']), bold: true)],
      footer: 'Payment statement from Fixeaze. Questions? support@fixeaze.com',
    );
  }

  Future<void> _download(InvoiceData d) async {
    setState(() => _busy = true);
    try {
      await pdfmod.loadLibrary(); // the PDF library is only downloaded when needed
      final bytes = await pdfmod.buildInvoicePdf(d);
      final ok = await saveBytes('${d.number}.pdf', bytes, 'application/pdf');
      if (mounted && ok) snack(context, 'Invoice saved');
    } catch (e) {
      if (mounted) snack(context, 'Could not create the PDF: $e', error: true);
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.bookingId != null ? 'Invoice' : 'Payment invoice')),
      body: FutureBuilder<InvoiceData>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snap.hasError) return ErrorState(error: snap.error!, onRetry: () => setState(() {}));
          final d = snap.data!;
          return Column(children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Center(
                  child: Constrained(
                    maxWidth: 560,
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset('assets/logo.png', width: 48, height: 48)),
                            const SizedBox(width: 12),
                            const Expanded(
                                child: Text('Fixeaze',
                                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.teal))),
                            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                              Text(d.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                              Text(d.number, style: const TextStyle(fontSize: 12)),
                              Text(DateFormat('d MMM yyyy').format(d.date), style: const TextStyle(fontSize: 12, color: Colors.black54)),
                            ]),
                          ]),
                          const Divider(height: 28, thickness: 1.5),
                          for (final r in [...d.parties, ...d.details])
                            Padding(
                              padding: const EdgeInsets.only(bottom: 4),
                              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                SizedBox(width: 110, child: Text('${r[0]}', style: const TextStyle(color: Colors.black54))),
                                Expanded(child: Text(r[1], style: const TextStyle(fontWeight: FontWeight.w600))),
                              ]),
                            ),
                          const SizedBox(height: 12),
                          Container(
                            color: Colors.teal,
                            padding: const EdgeInsets.all(8),
                            child: Row(children: [
                              Expanded(child: Text(d.tableHead.first, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                              Text(d.tableHead.last, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                            ]),
                          ),
                          for (final r in d.tableRows)
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
                              child: Row(children: [
                                Expanded(child: Text(r.first)),
                                Text(r.last),
                              ]),
                            ),
                          const Divider(),
                          for (final t in d.totals)
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              child: Row(children: [
                                Expanded(child: Text(t.label, style: TextStyle(fontWeight: t.bold ? FontWeight.bold : null, fontSize: t.bold ? 16 : null))),
                                Text(inr(t.amount), style: TextStyle(fontWeight: t.bold ? FontWeight.bold : null, fontSize: t.bold ? 16 : null)),
                              ]),
                            ),
                          const SizedBox(height: 14),
                          Text(d.footer, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                        ]),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _busy ? null : () => _download(d),
                    icon: _busy
                        ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Icon(Icons.download),
                    label: const Text('Download PDF'),
                  ),
                ),
              ),
            ),
          ]);
        },
      ),
    );
  }
}
