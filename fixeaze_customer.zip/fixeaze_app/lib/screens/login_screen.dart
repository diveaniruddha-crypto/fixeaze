import 'dart:async';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../app_state.dart';
import '../config.dart';
import '../services/app_otp.dart';
import '../services/session_guard.dart';
import '../services/session_policy.dart';
import '../services/pincode_service.dart';
import 'forgot_password_screen.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'technician_type_screen.dart';

class LoginScreen extends StatefulWidget {
  /// Shows the "Skip for now" button (used on the very first screen).
  final bool showSkip;
  const LoginScreen({super.key, this.showSkip = false});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _pincode = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _otp = TextEditingController();

  bool _otpStage = false;
  bool _signUp = false;
  bool _tech = false; // false = customer login, true = technician login
  bool _busy = false;
  bool _hidePassword = true;

  @override
  void initState() {
    super.initState();
    SessionPolicy.lastId().then((v) {
      if (mounted && v.isNotEmpty && _email.text.isEmpty && !_signUp) setState(() => _email.text = v);
    });
  }

  Future<void> _google() async {
    setState(() => _busy = true);
    try {
      await SessionPolicy.markFresh();
      await supabase.auth.signInWithOAuth(
        OAuthProvider.google,
        redirectTo: '${Uri.base.origin}${Uri.base.path}',
      );
    } on AuthException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Google sign-in is not set up yet: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _otp.dispose();
    _name.dispose();
    _phone.dispose();
    _pincode.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      if (_signUp) {
        final pin = await PincodeService.lookup(_pincode.text);
        if (pin == null) {
          if (mounted) {
            snack(context, 'We could not find this pincode. Check it and try again.',
                error: true);
          }
          return;
        }
        final dup = await AccountCheck.problem(supabase, _email.text, _phone.text);
        if (dup != null) {
          if (mounted) snack(context, dup, error: true);
          return;
        }
        _pin = pin;
        _code = AppOtp.generate();
        _otp.clear();
        if (mounted) {
          setState(() => _otpStage = true);
          await AppOtp.show(context, _code);
        }
        return;
      } else {
        var email = _email.text.trim();
        if (!email.contains('@')) {
          final r = await supabase.rpc('email_for_login', params: {'p_id': email});
          if (r == null || '$r'.isEmpty) {
            if (mounted) snack(context, 'No account found with this mobile number. Check it, or create an account.', error: true);
            return;
          }
          email = '$r';
        }
        // Check which kind of account this is BEFORE signing in.
        try {
          final r = await supabase.rpc('role_for_login', params: {'p_id': _email.text.trim()});
          final role = '${r ?? ''}';
          if (role.isNotEmpty && (_tech ? role != 'technician' : role == 'technician')) {
            if (mounted) {
              snack(context, _tech
                  ? 'No technician account found with these details. Use the Customer tab to log in as a customer.'
                  : 'No customer account found with these details. Use the Technician tab to log in as a technician.',
                  error: true);
            }
            return;
          }
        } catch (_) {}
        SessionGuard.freshLogin = true;
        final cred = await supabase.auth.signInWithPassword(email: email, password: _password.text);
        // Keep customers and technicians on their own tab.
        try {
          final row = await supabase
              .from('profiles')
              .select('role')
              .eq('id', cred.user!.id)
              .maybeSingle();
          final role = '${row?['role'] ?? ''}';
          final wrong = _tech ? role != 'technician' : role == 'technician';
          if (wrong) {
            await supabase.auth.signOut();
            if (mounted) {
              snack(context, _tech
                  ? 'No technician account found with these details. Use the Customer tab to log in as a customer.'
                  : 'No customer account found with these details. Use the Technician tab to log in as a technician.',
                  error: true);
            }
            return;
          }
        } catch (_) {}
        await SessionPolicy.rememberId(_email.text.trim());
        TextInput.finishAutofillContext();
      }
      // When this screen was opened on top of another one (e.g. from booking),
      // go back to it. The app underneath already switched to the signed-in view.
      if (mounted && Navigator.canPop(context)) Navigator.pop(context);
    } on AuthException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Something went wrong: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  PinInfo? _pin;
  String _code = '';

  Future<void> _verifyOtp() async {
    final code = _otp.text.trim();
    if (code.length < 6) {
      snack(context, 'Enter the 6-digit OTP from the popup', error: true);
      return;
    }
    if (code != _code) {
      snack(context, 'Wrong OTP. Please check the code in the popup.', error: true);
      return;
    }
    setState(() => _busy = true);
    try {
      final pin = _pin!;
      SessionGuard.freshLogin = true;
      final res = await supabase.auth.signUp(
        email: _email.text.trim(),
        password: _password.text,
        data: {
          'name': _name.text.trim(),
          'phone': _phone.text.trim(),
          'role': 'customer',
          'pincode': pin.pincode,
          'lat': pin.lat,
          'lng': pin.lng,
        },
      );
      if (res.user != null && (res.user!.identities ?? []).isEmpty) {
        if (mounted) {
          snack(context, 'This email is already registered. Please log in.', error: true);
          setState(() {
            _otpStage = false;
            _signUp = false;
          });
        }
        return;
      }
      if (res.session == null) {
        if (mounted) {
          snack(context,
              'Sign-up needs "Confirm email" switched OFF in Supabase (Authentication > Sign In / Providers > Email).',
              error: true);
        }
        return;
      }
      if (mounted && Navigator.canPop(context)) Navigator.pop(context);
    } on AuthException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Something went wrong: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _otpView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Icon(Icons.pin, size: 56, color: kTeal),
        const SizedBox(height: 12),
        const Text('Enter the OTP shown in the popup',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
        const SizedBox(height: 20),
        TextField(
          controller: _otp,
          keyboardType: TextInputType.number,
          textAlign: TextAlign.center,
          maxLength: 6,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          style: const TextStyle(fontSize: 28, letterSpacing: 8),
          decoration: const InputDecoration(hintText: '------', counterText: ''),
          onSubmitted: (_) => _busy ? null : _verifyOtp(),
        ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: _busy ? null : _verifyOtp,
          child: _busy
              ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Text('Verify and create account'),
        ),
        TextButton(
          onPressed: _busy ? null : () => AppOtp.show(context, _code),
          child: const Text('Show the OTP again'),
        ),
        TextButton(
          onPressed: _busy
              ? null
              : () => setState(() {
                    _otpStage = false;
                    _otp.clear();
                  }),
          child: const Text('Back'),
        ),
      ],
    );
  }

  Widget _whoToggle() {
    Widget seg(String label, IconData icon, bool tech) {
      final on = _tech == tech;
      return Expanded(
        child: Material(
          color: on ? kTeal : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: _busy
                ? null
                : () => setState(() {
                      _tech = tech;
                      _signUp = false;
                    }),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(icon, size: 18, color: on ? Colors.white : kTeal),
                const SizedBox(width: 6),
                Text(label,
                    style: TextStyle(
                        fontWeight: FontWeight.w800, color: on ? Colors.white : kTeal)),
              ]),
            ),
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: const Color(0xFFE7EFE9),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(children: [
        seg('Customer', Icons.person, false),
        seg('Technician', Icons.engineering, true),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: Navigator.canPop(context) ? AppBar(title: const AppBarTitle()) : null,
      body: AutofillGroup(child: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Constrained(
              maxWidth: 420,
              child: _otpStage
                  ? _otpView()
                  : Form(
                key: _form,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.asset('assets/logo.png', width: 88, height: 88),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text('Fixeaze',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 30, fontWeight: FontWeight.bold, color: kTeal)),
                    const SizedBox(height: 4),
                    Text(
                      _tech ? 'Technician login' : (_signUp ? 'Create your customer account' : 'Welcome back'),
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.black54, fontSize: 16),
                    ),
                    const SizedBox(height: 14),
                    _whoToggle(),
                    const SizedBox(height: 14),
                    const SizedBox(height: 4),
                    if (_signUp && !_tech) ...[
                      TextFormField(
                        controller: _name,
                        textCapitalization: TextCapitalization.words,
                        decoration: const InputDecoration(
                            labelText: 'Full name', prefixIcon: Icon(Icons.badge)),
                        validator: (v) =>
                            (v == null || v.trim().length < 2) ? 'Enter your name' : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _phone,
                        keyboardType: TextInputType.phone,
                        decoration: const InputDecoration(
                            labelText: 'Phone number', prefixIcon: Icon(Icons.phone)),
                        validator: (v) => (v == null || v.trim().length < 10)
                            ? 'Enter a valid phone number'
                            : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _pincode,
                        keyboardType: TextInputType.number,
                        maxLength: 6,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        decoration: const InputDecoration(
                          labelText: 'Pincode',
                          helperText: 'We show technicians within 10 km of you',
                          prefixIcon: Icon(Icons.pin_drop),
                          counterText: '',
                        ),
                        validator: (v) => (v == null || !PincodeService.isValid(v))
                            ? 'Enter a valid 6-digit pincode'
                            : null,
                      ),
                      const SizedBox(height: 12),
                    ],
                    TextFormField(
                      controller: _email,
                      keyboardType: _signUp ? TextInputType.emailAddress : TextInputType.emailAddress,
                      autofillHints: [_signUp ? AutofillHints.email : AutofillHints.username],
                      decoration: InputDecoration(
                          labelText: _signUp ? 'Email' : 'Email or mobile number',
                          prefixIcon: Icon(_signUp ? Icons.email : Icons.person)),
                      validator: (v) {
                        final t = (v ?? '').trim();
                        if (_signUp) return t.contains('@') ? null : 'Enter a valid email';
                        return t.length < 5 ? 'Enter your email or mobile number' : null;
                      },
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _password,
                      obscureText: _hidePassword,
                      autofillHints: [_signUp ? AutofillHints.newPassword : AutofillHints.password],
                      decoration: InputDecoration(
                        labelText: 'Password',
                        prefixIcon: const Icon(Icons.lock),
                        suffixIcon: IconButton(
                          icon: Icon(
                              _hidePassword ? Icons.visibility : Icons.visibility_off),
                          onPressed: () =>
                              setState(() => _hidePassword = !_hidePassword),
                        ),
                      ),
                      validator: (v) =>
                          (v == null || v.length < 6) ? 'At least 6 characters' : null,
                      onFieldSubmitted: (_) => _busy ? null : _submit(),
                    ),
                    const SizedBox(height: 20),
                    FilledButton(
                      onPressed: _busy ? null : _submit,
                      child: _busy
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : Text(_signUp ? 'Create account' : 'Log in'),
                    ),
                    const SizedBox(height: 8),
                    if (!_signUp)
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: _busy
                              ? null
                              : () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (_) => const ForgotPasswordScreen()),
                                  ),
                          child: const Text('Forgot password?'),
                        ),
                      ),
                    if (kIsWeb && !_signUp && !_tech) ...[
                      const SizedBox(height: 4),
                      OutlinedButton.icon(
                        onPressed: _busy ? null : _google,
                        icon: Image.asset('assets/google_g.png', width: 22, height: 22),
                        label: const Text('Continue with Google'),
                      ),
                    ],
                    if (!_tech)
                      TextButton(
                        onPressed: _busy ? null : () => setState(() => _signUp = !_signUp),
                        child: Text(_signUp
                            ? 'Already have an account? Log in'
                            : 'New to Fixeaze? Create an account'),
                      )
                    else
                      TextButton.icon(
                        onPressed: _busy
                            ? null
                            : () => Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) => const TechnicianTypeScreen()),
                                ),
                        icon: const Icon(Icons.engineering),
                        label: const Text('New technician? Join Fixeaze'),
                      ),
                    if (widget.showSkip) ...[
                      const Divider(height: 24),
                      OutlinedButton(
                        onPressed: _busy ? null : () => AppState.guest.value = true,
                        child: const Text('Skip for now'),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      )),
    );
  }
}
