import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../config.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import 'book_screen.dart';
import 'catalog_book_screen.dart';

/// One page per service (Plumbing, Electrical...): pick a product, pick the work, book a technician.
class ServicePage extends StatefulWidget {
  final Map<String, dynamic> service;
  final Color tint;
  final String query; // from the home search, to open the matching product
  const ServicePage({super.key, required this.service, required this.tint, this.query = ''});

  @override
  State<ServicePage> createState() => _ServicePageState();
}

class _ServicePageState extends State<ServicePage> {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _products = [];
  final Map<String, List<Map<String, dynamic>>> _items = {};
  Map<String, dynamic>? _product;
  Map<String, dynamic>? _item;
  bool _loadingItems = false;
  final GlobalKey _formKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await supabase
          .from('catalog_products')
          .select()
          .eq('service_id', widget.service['id'])
          .eq('active', true)
          .order('sort')
          .order('name');
      _products = List<Map<String, dynamic>>.from(rows);
      final q = widget.query.trim().toLowerCase();
      if (q.isNotEmpty) {
        final m = _products.where((p) => '${p['name']}'.toLowerCase().contains(q));
        if (m.isNotEmpty) {
          if (mounted) setState(() => _loading = false);
          await _pickProduct(m.first);
          return;
        }
      }
    } catch (e) {
      _error = '$e';
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _pickProduct(Map<String, dynamic> p) async {
    final id = '${p['id']}';
    setState(() {
      _product = p;
      _item = null;
    });
    if (_items.containsKey(id)) return;
    setState(() => _loadingItems = true);
    try {
      final rows = await supabase
          .from('product_services')
          .select()
          .eq('product_id', id)
          .eq('active', true)
          .order('sort')
          .order('name');
      _items[id] = List<Map<String, dynamic>>.from(rows);
    } catch (_) {
      _items[id] = [];
    }
    if (mounted) setState(() => _loadingItems = false);
  }

  Future<void> _book({bool guided = false}) async {
    final Widget screen;
    if (_products.isEmpty) {
      screen = BookScreen(service: widget.service, initialType: 'hourly');
    } else if (!guided && _product != null && _item != null) {
      screen = CatalogBookScreen(service: widget.service, product: _product, item: _item);
    } else {
      screen = CatalogBookScreen(service: widget.service);
    }
    final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => screen));
    if (ok == true && mounted) Navigator.pop(context, true);
  }

  Widget _round(String? url, IconData icon, double r, {Color? bg}) => CircleAvatar(
        radius: r,
        backgroundColor: bg ?? Colors.white,
        backgroundImage: (url != null && url.isNotEmpty) ? NetworkImage(url) : null,
        child: (url == null || url.isEmpty) ? Icon(icon, color: kTeal, size: r) : null,
      );

  Widget _chip(IconData i, String t) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(color: Colors.white.withOpacity(0.75), borderRadius: BorderRadius.circular(20)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(i, size: 14, color: kTeal),
          const SizedBox(width: 5),
          Text(t, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: kInk)),
        ]),
      );

  Widget _heading(String num, String text) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 10),
        child: Row(children: [
          if (num.isNotEmpty) ...[
            CircleAvatar(
                radius: 13,
                backgroundColor: kTeal,
                child: Text(num, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800))),
            const SizedBox(width: 10),
          ],
          Expanded(child: Text(text, style: GoogleFonts.dmSerifDisplay(fontSize: 21, color: kInk))),
        ]),
      );

  String _range(Map<String, dynamic> x) {
    final lo = x['price_min'], hi = x['price_max'];
    if (lo != null && hi != null) return '${money(lo)} - ${money(hi)}';
    return 'Price shown with technicians';
  }

  Widget _header() {
    final name = '${widget.service['name']}';
    final desc = '${widget.service['description'] ?? ''}';
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 8, 20, 22),
      decoration: BoxDecoration(
        color: widget.tint,
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(32)),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back)),
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
              _round((widget.service['image_url'] ?? widget.service['icon_url']) as String?, serviceIcon(name), 38),
              const SizedBox(width: 16),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(name, style: GoogleFonts.dmSerifDisplay(fontSize: 34, height: 1.05, color: kInk)),
                  if (desc.isNotEmpty)
                    Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(desc, style: const TextStyle(color: Colors.black54, fontSize: 13.5))),
                ]),
              ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 12, top: 16),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              _chip(Icons.verified_user, 'Verified pros'),
              _chip(Icons.sell, 'Upfront prices'),
              _chip(Icons.payments, 'Pay after the job'),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _productGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.25,
        children: [
          for (final p in _products)
            InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () => _pickProduct(p),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _product?['id'] == p['id'] ? widget.tint : Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _product?['id'] == p['id'] ? kTeal : kLine, width: _product?['id'] == p['id'] ? 2 : 1),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    _round(p['image_url'] as String?, Icons.devices_other, 20, bg: widget.tint),
                    const Spacer(),
                    if (_product?['id'] == p['id']) const Icon(Icons.check_circle, color: kTeal),
                  ]),
                  const Spacer(),
                  Text('${p['name']}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  if ('${p['description'] ?? ''}'.isNotEmpty)
                    Text('${p['description']}',
                        maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, color: Colors.black54)),
                ]),
              ),
            ),
        ],
      ),
    );
  }

  Widget _itemList() {
    final id = '${_product!['id']}';
    if (_loadingItems) return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator(strokeWidth: 2)));
    final items = _items[id] ?? const <Map<String, dynamic>>[];
    if (items.isEmpty) return const Padding(padding: EdgeInsets.all(20), child: Text('No work types added for this product yet.'));
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(children: [
        for (final it in items)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () {
                setState(() => _item = it);
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  final c = _formKey.currentContext;
                  if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 400), curve: Curves.easeOut);
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _item?['id'] == it['id'] ? widget.tint : Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: _item?['id'] == it['id'] ? kTeal : kLine, width: _item?['id'] == it['id'] ? 2 : 1),
                ),
                child: Row(children: [
                  _round(it['image_url'] as String?, Icons.build_circle_outlined, 22, bg: widget.tint),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${it['name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      if ('${it['description'] ?? ''}'.isNotEmpty)
                        Text('${it['description']}', style: const TextStyle(fontSize: 12.5, color: Colors.black54)),
                      const SizedBox(height: 4),
                      Text(_range(it), style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: kTeal)),
                    ]),
                  ),
                  Icon(_item?['id'] == it['id'] ? Icons.radio_button_checked : Icons.radio_button_off, color: kTeal),
                ]),
              ),
            ),
          ),
      ]),
    );
  }

  Widget _bottomBar() {
    final ready = _product != null && _item != null;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
      decoration: const BoxDecoration(color: kCream, border: Border(top: BorderSide(color: kLine))),
      child: SafeArea(
        top: false,
        child: Row(children: [
          Expanded(
            child: ready
                ? Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                    Text('${_product!['name']} - ${_item!['name']}',
                        maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
                    Text(_range(_item!), style: const TextStyle(fontSize: 12, color: Colors.black54)),
                  ])
                : const Text('Choose a product and the work you need', style: TextStyle(color: Colors.black54, fontSize: 13)),
          ),
          const SizedBox(width: 12),
          FilledButton.icon(
            onPressed: () => _book(guided: !ready),
            icon: const Icon(Icons.engineering),
            label: Text(ready ? 'Book a technician' : 'Browse and book'),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kCream,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? ErrorState(error: _error!, onRetry: _load)
              : ListView(padding: EdgeInsets.zero, children: [
                  _header(),
                  if (_products.isEmpty) ...[
                    const Padding(
                      padding: EdgeInsets.all(24),
                      child: Text('Products for this service are coming soon. You can still book a technician now.'),
                    ),
                  ] else ...[
                    _heading('1', 'What needs fixing?'),
                    _productGrid(),
                    if (_product != null) ...[
                      _heading('2', 'What kind of help?'),
                      _itemList(),
                    ],
                    if (_item != null)
                      Padding(
                        key: _formKey,
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: CatalogBookScreen(
                          key: ValueKey('${_item!['id']}'),
                          service: widget.service,
                          product: _product,
                          item: _item,
                          embedded: true,
                          onBooked: () => Navigator.pop(context, true),
                        ),
                      ),
                  ],
                ]),
      bottomNavigationBar: (_loading || _error != null || _item != null) ? null : _bottomBar(),
    );
  }
}
