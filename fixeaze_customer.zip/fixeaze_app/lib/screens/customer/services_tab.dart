import 'package:flutter/material.dart';
import '../../widgets/fun_loader.dart';

import '../../config.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import 'book_screen.dart';
import 'catalog_book_screen.dart';

class ServicesTab extends StatefulWidget {
  final String greetingName;
  final VoidCallback onBooked;
  const ServicesTab({super.key, required this.greetingName, required this.onBooked});

  @override
  State<ServicesTab> createState() => _ServicesTabState();
}

class _ServicesTabState extends State<ServicesTab> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows =
        await supabase.from('services').select().eq('active', true).order('name');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> _openBooking(Map<String, dynamic> service, String type,
      {Map<String, dynamic>? product, Map<String, dynamic>? item}) async {
    var useCatalog = product != null;
    if (!useCatalog) try {
      final r = await supabase
          .from('catalog_products')
          .select('id')
          .eq('service_id', service['id'])
          .eq('active', true)
          .limit(1);
      useCatalog = (r as List).isNotEmpty;
    } catch (_) {}
    if (!mounted) return;
    final booked = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => useCatalog
            ? CatalogBookScreen(service: service, product: product, item: item)
            : BookScreen(service: service, initialType: type),
      ),
    );
    if (booked == true) widget.onBooked();
  }

  Future<void> _pickService(List<Map<String, dynamic>> services, String type) async {
    if (services.isEmpty) return;
    final picked = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Text(
                type == 'inspection'
                    ? 'What needs an estimate and inspection?'
                    : 'Which service do you need?',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            ...services.map((s) {
              final name = (s['name'] ?? '').toString();
              return ListTile(
                leading: Icon(serviceIcon(name), color: kTeal),
                title: Text(name),
                subtitle: (s['description'] ?? '').toString().isEmpty
                    ? null
                    : Text('${s['description']}', maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () => Navigator.pop(ctx, s),
              );
            }),
          ],
        ),
      ),
    );
    if (picked != null) _openBooking(picked, type);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const FunLoader();
        }
        if (snap.hasError) {
          return ErrorState(
            error: snap.error!,
            onRetry: () => setState(() => _future = _load()),
          );
        }
        final services = snap.data!;
        return RefreshIndicator(
          onRefresh: () async {
            setState(() => _future = _load());
            await _future;
          },
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Container(
                  padding: const EdgeInsets.fromLTRB(20, 22, 20, 26),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF0F766E), Color(0xFF14B8A6)]),
                    borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.greetingName.isEmpty
                            ? 'What needs fixing?'
                            : 'Hi ${widget.greetingName},\nwhat needs fixing?',
                        style: const TextStyle(
                            fontSize: 24, fontWeight: FontWeight.w800, color: Colors.white, height: 1.2),
                      ),
                      const SizedBox(height: 16),
                      Material(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => _pickService(services, 'hourly'),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 15),
                            child: Row(children: [
                              Icon(Icons.search, color: kTeal),
                              SizedBox(width: 10),
                              Expanded(
                                  child: Text('Book a service: electrician, plumber, AC...',
                                      style: TextStyle(color: Colors.black54))),
                            ]),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(20, 20, 16, 4),
                  child: Text('Popular services',
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Color(0xFF134E4A))),
                ),
              ),
              if (services.isEmpty)
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: EmptyState(
                      icon: Icons.handyman, text: 'No services available yet.'),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, i) => _ServiceAccordion(
                        service: services[i],
                        onPick: (product, item) =>
                            _openBooking(services[i], 'hourly', product: product, item: item),
                        onNoProducts: () => _openBooking(services[i], 'hourly'),
                      ),
                      childCount: services.length,
                    ),
                  ),
                ),
              SliverToBoxAdapter(
                child: Container(
                  margin: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                      color: const Color(0xFF134E4A), borderRadius: BorderRadius.circular(18)),
                  child: const Row(children: [
                    Icon(Icons.verified_user, color: kAmber, size: 30),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Verified technicians',
                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                        SizedBox(height: 2),
                        Text('ID checked. See the charge before you book. Pay after the job.',
                            style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ]),
                    ),
                  ]),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: kTeal,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: kAmber, size: 28),
              const SizedBox(height: 10),
              Text(title,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 2),
              Text(subtitle,
                  style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

/// A service card that opens in place: products appear under it, and each product shows its work types.
class _ServiceAccordion extends StatefulWidget {
  final Map<String, dynamic> service;
  final void Function(Map<String, dynamic> product, Map<String, dynamic> item) onPick;
  final VoidCallback onNoProducts;
  const _ServiceAccordion({required this.service, required this.onPick, required this.onNoProducts});

  @override
  State<_ServiceAccordion> createState() => _ServiceAccordionState();
}

class _ServiceAccordionState extends State<_ServiceAccordion> {
  bool _open = false;
  bool _loading = false;
  List<Map<String, dynamic>>? _products;
  String? _openProduct;
  final Map<String, List<Map<String, dynamic>>> _items = {};
  String? _loadingProduct;

  Future<void> _toggle() async {
    if (_open) {
      setState(() => _open = false);
      return;
    }
    setState(() => _open = true);
    if (_products != null) return;
    setState(() => _loading = true);
    try {
      final rows = await supabase
          .from('catalog_products')
          .select()
          .eq('service_id', widget.service['id'])
          .eq('active', true)
          .order('sort')
          .order('name');
      _products = List<Map<String, dynamic>>.from(rows);
    } catch (_) {
      _products = [];
    }
    if (!mounted) return;
    setState(() => _loading = false);
    if (_products!.isEmpty) {
      setState(() => _open = false);
      widget.onNoProducts(); // older service without products: use the simple booking form
    }
  }

  Future<void> _toggleProduct(Map<String, dynamic> p) async {
    final id = '${p['id']}';
    if (_openProduct == id) {
      setState(() => _openProduct = null);
      return;
    }
    setState(() => _openProduct = id);
    if (_items.containsKey(id)) return;
    setState(() => _loadingProduct = id);
    try {
      final rows = await supabase
          .from('product_services')
          .select()
          .eq('product_id', id)
          .eq('active', true)
          .order('sort')
          .order('name');
      _items[id] = List<Map<String, dynamic>>.from(rows);
    } catch (_) {
      _items[id] = [];
    }
    if (mounted) setState(() => _loadingProduct = null);
  }

  Widget _thumb(String? url, IconData icon, double r) {
    return CircleAvatar(
      radius: r,
      backgroundColor: const Color(0xFFCCFBF1),
      backgroundImage: (url != null && url.isNotEmpty) ? NetworkImage(url) : null,
      child: (url == null || url.isEmpty) ? Icon(icon, color: kTeal, size: r) : null,
    );
  }

  @override
  Widget build(BuildContext context) {
    final name = (widget.service['name'] ?? '').toString();
    final desc = (widget.service['description'] ?? '').toString();
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      color: Colors.white,
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        InkWell(
          onTap: _toggle,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              _thumb((widget.service['image_url'] ?? widget.service['icon_url']) as String?, serviceIcon(name), 26),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(name,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF134E4A))),
                  if (desc.isNotEmpty)
                    Text(desc, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12.5, color: Colors.black54)),
                ]),
              ),
              AnimatedRotation(
                turns: _open ? 0.5 : 0,
                duration: const Duration(milliseconds: 200),
                child: const Icon(Icons.keyboard_arrow_down, color: kTeal),
              ),
            ]),
          ),
        ),
        if (_open) ...[
          const Divider(height: 1),
          if (_loading)
            const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator(strokeWidth: 2)))
          else
            for (final p in _products ?? const <Map<String, dynamic>>[]) ...[
              InkWell(
                onTap: () => _toggleProduct(p),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 14, 10),
                  child: Row(children: [
                    _thumb(p['image_url'] as String?, Icons.devices_other, 18),
                    const SizedBox(width: 12),
                    Expanded(child: Text('${p['name']}', style: const TextStyle(fontWeight: FontWeight.w700))),
                    Icon(_openProduct == '${p['id']}' ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                        color: Colors.black45),
                  ]),
                ),
              ),
              if (_openProduct == '${p['id']}')
                Container(
                  color: const Color(0xFFF2F8F7),
                  padding: const EdgeInsets.fromLTRB(32, 4, 14, 8),
                  child: _loadingProduct == '${p['id']}'
                      ? const Padding(
                          padding: EdgeInsets.all(12), child: Center(child: CircularProgressIndicator(strokeWidth: 2)))
                      : Column(children: [
                          if ((_items['${p['id']}'] ?? const []).isEmpty)
                            const Padding(
                                padding: EdgeInsets.all(12), child: Text('No work types added yet.')),
                          for (final it in _items['${p['id']}'] ?? const <Map<String, dynamic>>[])
                            ListTile(
                              dense: true,
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.build_circle_outlined, color: kTeal),
                              title: Text('${it['name']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                              subtitle: it['price_min'] != null && it['price_max'] != null
                                  ? Text('Typically ${money(it['price_min'])} - ${money(it['price_max'])}')
                                  : ((it['description'] ?? '').toString().isEmpty
                                      ? null
                                      : Text('${it['description']}', maxLines: 1, overflow: TextOverflow.ellipsis)),
                              trailing: const Icon(Icons.chevron_right),
                              onTap: () => widget.onPick(p, it),
                            ),
                        ]),
                ),
              const Divider(height: 1),
            ],
        ],
      ]),
    );
  }
}
