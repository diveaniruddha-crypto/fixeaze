import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../widgets/fun_loader.dart';

import '../../config.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import 'book_screen.dart';
import 'catalog_book_screen.dart';
import 'service_page.dart';

class ServicesTab extends StatefulWidget {
  final String greetingName;
  final VoidCallback onBooked;
  const ServicesTab({super.key, required this.greetingName, required this.onBooked});

  @override
  State<ServicesTab> createState() => _ServicesTabState();
}

class _ServicesTabState extends State<ServicesTab> {
  late Future<List<Map<String, dynamic>>> _future;
  String _q = '';
  Map<String, List<String>> _prodNames = {}; // service id -> product names (lowercase), for search

  @override
  void initState() {
    super.initState();
    _future = _load();
    _loadProductNames();
  }

  Future<void> _loadProductNames() async {
    try {
      final rows = await supabase.from('catalog_products').select('service_id, name').eq('active', true);
      final m = <String, List<String>>{};
      for (final r in rows) {
        m.putIfAbsent('${r['service_id']}', () => []).add('${r['name']}'.toLowerCase());
      }
      if (mounted) setState(() => _prodNames = m);
    } catch (_) {}
  }

  bool _nameMatch(Map<String, dynamic> s) => '${s['name']}'.toLowerCase().contains(_q);
  bool _productMatch(Map<String, dynamic> s) =>
      (_prodNames['${s['id']}'] ?? const []).any((n) => n.contains(_q));

  Future<List<Map<String, dynamic>>> _load() async {
    final rows =
        await supabase.from('services').select().eq('active', true).order('name');
    return List<Map<String, dynamic>>.from(rows);
  }

  static const _tints = [Color(0xFFE7EFE9), Color(0xFFF6E9D7), Color(0xFFE3ECF3), Color(0xFFF1E4E4)];

  Future<void> _openService(Map<String, dynamic> service, Color tint) async {
    final booked = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => ServicePage(service: service, tint: tint, query: _q)),
    );
    if (booked == true) widget.onBooked();
  }

  Future<void> _openBooking(Map<String, dynamic> service, String type,
      {Map<String, dynamic>? product, Map<String, dynamic>? item}) async {
    var useCatalog = product != null;
    if (!useCatalog) try {
      final r = await supabase
          .from('catalog_products')
          .select('id')
          .eq('service_id', service['id'])
          .eq('active', true)
          .limit(1);
      useCatalog = (r as List).isNotEmpty;
    } catch (_) {}
    if (!mounted) return;
    final booked = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => useCatalog
            ? CatalogBookScreen(service: service, product: product, item: item)
            : BookScreen(service: service, initialType: type),
      ),
    );
    if (booked == true) widget.onBooked();
  }

  Future<void> _pickService(List<Map<String, dynamic>> services, String type) async {
    if (services.isEmpty) return;
    final picked = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Text(
                type == 'inspection'
                    ? 'What needs an estimate and inspection?'
                    : 'Which service do you need?',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            ...services.map((s) {
              final name = (s['name'] ?? '').toString();
              return ListTile(
                leading: Icon(serviceIcon(name), color: kTeal),
                title: Text(name),
                subtitle: (s['description'] ?? '').toString().isEmpty
                    ? null
                    : Text('${s['description']}', maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () => Navigator.pop(ctx, s),
              );
            }),
          ],
        ),
      ),
    );
    if (picked != null) _openBooking(picked, type);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const FunLoader();
        }
        if (snap.hasError) {
          return ErrorState(
            error: snap.error!,
            onRetry: () => setState(() => _future = _load()),
          );
        }
        final all = snap.data!;
        final services = _q.isEmpty ? all : all.where((s) => _nameMatch(s) || _productMatch(s)).toList();
        return RefreshIndicator(
          onRefresh: () async {
            setState(() => _future = _load());
            await _future;
          },
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(22, 22, 22, 6),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.greetingName.isEmpty ? 'Welcome' : 'Hi ${widget.greetingName}',
                        style: const TextStyle(fontSize: 13, color: Colors.black54),
                      ),
                      const SizedBox(height: 6),
                      Text('A trusted hand for every home fix.',
                          style: GoogleFonts.dmSerifDisplay(fontSize: 32, height: 1.1, color: kInk)),
                      const SizedBox(height: 16),
                      TextField(
                        onChanged: (v) => setState(() => _q = v.trim().toLowerCase()),
                        decoration: const InputDecoration(
                          hintText: 'Search a service or product: plumber, fan, AC...',
                          prefixIcon: Icon(Icons.search, color: kTeal),
                          isDense: true,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(22, 22, 16, 6),
                  child: Text('Our services',
                      style: GoogleFonts.dmSerifDisplay(fontSize: 22, color: kInk)),
                ),
              ),
              if (services.isEmpty)
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: EmptyState(
                      icon: Icons.handyman,
                      text: _q.isEmpty ? 'No services available yet.' : 'Nothing found for "$_q".'),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  sliver: SliverGrid(
                    gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 260,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 0.95,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, i) => _ServiceTile(
                        tint: _tints[i % _tints.length],
                        service: services[i],
                        onTap: () => _openService(services[i], _tints[i % _tints.length]),
                      ),
                      childCount: services.length,
                    ),
                  ),
                ),
              SliverToBoxAdapter(child: const _HowItWorks()),
              SliverToBoxAdapter(
                child: Container(
                  margin: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: kTeal, width: 1),
                  ),
                  child: const Row(children: [
                    Icon(Icons.verified_user_outlined, color: kTeal, size: 28),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Verified technicians', style: TextStyle(fontWeight: FontWeight.w800)),
                        SizedBox(height: 2),
                        Text('ID checked. See the charge before you book. Pay after the job.',
                            style: TextStyle(color: Colors.black54, fontSize: 12.5)),
                      ]),
                    ),
                  ]),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: kTeal,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: kAmber, size: 28),
              const SizedBox(height: 10),
              Text(title,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 2),
              Text(subtitle,
                  style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Side-by-side service box on the home page.
class _ServiceTile extends StatelessWidget {
  final Map<String, dynamic> service;
  final Color tint;
  final VoidCallback onTap;
  const _ServiceTile({required this.service, required this.tint, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final name = (service['name'] ?? '').toString();
    final desc = (service['description'] ?? '').toString();
    final url = (service['image_url'] ?? service['icon_url']) as String?;
    return Material(
      color: tint,
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              CircleAvatar(
                radius: 26,
                backgroundColor: Colors.white,
                backgroundImage: (url != null && url.isNotEmpty) ? NetworkImage(url) : null,
                child: (url == null || url.isEmpty) ? Icon(serviceIcon(name), color: kTeal, size: 26) : null,
              ),
              const Spacer(),
              const CircleAvatar(
                  radius: 14, backgroundColor: Colors.white, child: Icon(Icons.arrow_forward, size: 16, color: kTeal)),
            ]),
            const Spacer(),
            Text(name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.dmSerifDisplay(fontSize: 22, height: 1.05, color: kInk)),
            if (desc.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(desc,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, color: Colors.black54)),
              ),
          ]),
        ),
      ),
    );
  }
}

/// Four steps side by side, each with its own icon.
class _HowItWorks extends StatelessWidget {
  const _HowItWorks();

  @override
  Widget build(BuildContext context) {
    const steps = [
      (Icons.touch_app, 'Choose', 'Product and work'),
      (Icons.photo_camera, 'Show', 'Photos and address'),
      (Icons.person_search, 'Pick', 'Technician and charge'),
      (Icons.verified, 'Fixed', 'Pay after the job'),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(6, 0, 0, 14),
          child: Text('How it works', style: GoogleFonts.dmSerifDisplay(fontSize: 22, color: kInk)),
        ),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          for (var i = 0; i < steps.length; i++)
            Expanded(
              child: Column(children: [
                Stack(clipBehavior: Clip.none, children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(color: kTeal, borderRadius: BorderRadius.circular(16)),
                    child: Icon(steps[i].$1, color: Colors.white, size: 26),
                  ),
                  Positioned(
                    right: -6,
                    top: -6,
                    child: CircleAvatar(
                      radius: 10,
                      backgroundColor: kAmber,
                      child: Text('${i + 1}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: kInk)),
                    ),
                  ),
                ]),
                const SizedBox(height: 10),
                Text(steps[i].$2, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: kInk)),
                const SizedBox(height: 2),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: Text(steps[i].$3,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 11, color: Colors.black54, height: 1.25)),
                ),
              ]),
            ),
        ]),
      ]),
    );
  }
}
