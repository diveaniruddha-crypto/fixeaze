import 'package:flutter/material.dart';
import '../../widgets/fun_loader.dart';

import '../../config.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import 'book_screen.dart';
import 'catalog_book_screen.dart';

class ServicesTab extends StatefulWidget {
  final String greetingName;
  final VoidCallback onBooked;
  const ServicesTab({super.key, required this.greetingName, required this.onBooked});

  @override
  State<ServicesTab> createState() => _ServicesTabState();
}

class _ServicesTabState extends State<ServicesTab> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows =
        await supabase.from('services').select().eq('active', true).order('name');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> _openBooking(Map<String, dynamic> service, String type) async {
    var useCatalog = false;
    try {
      final r = await supabase
          .from('catalog_products')
          .select('id')
          .eq('service_id', service['id'])
          .eq('active', true)
          .limit(1);
      useCatalog = (r as List).isNotEmpty;
    } catch (_) {}
    if (!mounted) return;
    final booked = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => useCatalog
            ? CatalogBookScreen(service: service)
            : BookScreen(service: service, initialType: type),
      ),
    );
    if (booked == true) widget.onBooked();
  }

  Future<void> _pickService(List<Map<String, dynamic>> services, String type) async {
    if (services.isEmpty) return;
    final picked = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Text(
                type == 'inspection'
                    ? 'What needs an estimate and inspection?'
                    : 'Which service do you need?',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            ...services.map((s) {
              final name = (s['name'] ?? '').toString();
              return ListTile(
                leading: Icon(serviceIcon(name), color: kTeal),
                title: Text(name),
                subtitle: (s['description'] ?? '').toString().isEmpty
                    ? null
                    : Text('${s['description']}', maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () => Navigator.pop(ctx, s),
              );
            }),
          ],
        ),
      ),
    );
    if (picked != null) _openBooking(picked, type);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const FunLoader();
        }
        if (snap.hasError) {
          return ErrorState(
            error: snap.error!,
            onRetry: () => setState(() => _future = _load()),
          );
        }
        final services = snap.data!;
        return RefreshIndicator(
          onRefresh: () async {
            setState(() => _future = _load());
            await _future;
          },
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Container(
                  padding: const EdgeInsets.fromLTRB(20, 22, 20, 26),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF0F766E), Color(0xFF14B8A6)]),
                    borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.greetingName.isEmpty
                            ? 'What needs fixing?'
                            : 'Hi ${widget.greetingName},\nwhat needs fixing?',
                        style: const TextStyle(
                            fontSize: 24, fontWeight: FontWeight.w800, color: Colors.white, height: 1.2),
                      ),
                      const SizedBox(height: 16),
                      Material(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => _pickService(services, 'hourly'),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 15),
                            child: Row(children: [
                              Icon(Icons.search, color: kTeal),
                              SizedBox(width: 10),
                              Expanded(
                                  child: Text('Book a service: electrician, plumber, AC...',
                                      style: TextStyle(color: Colors.black54))),
                            ]),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(20, 20, 16, 4),
                  child: Text('Popular services',
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Color(0xFF134E4A))),
                ),
              ),
              if (services.isEmpty)
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: EmptyState(
                      icon: Icons.handyman, text: 'No services available yet.'),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  sliver: SliverGrid(
                    gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 150,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 0.92,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, i) => _ServiceCard(
                        service: services[i],
                        onTap: () => _openBooking(services[i], 'hourly'),
                      ),
                      childCount: services.length,
                    ),
                  ),
                ),
              SliverToBoxAdapter(
                child: Container(
                  margin: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                      color: const Color(0xFF134E4A), borderRadius: BorderRadius.circular(18)),
                  child: const Row(children: [
                    Icon(Icons.verified_user, color: kAmber, size: 30),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Verified technicians',
                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                        SizedBox(height: 2),
                        Text('ID checked. See the charge before you book. Pay after the job.',
                            style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ]),
                    ),
                  ]),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: kTeal,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: kAmber, size: 28),
              const SizedBox(height: 10),
              Text(title,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 2),
              Text(subtitle,
                  style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

class _ServiceCard extends StatelessWidget {
  final Map<String, dynamic> service;
  final VoidCallback onTap;
  const _ServiceCard({required this.service, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final name = (service['name'] ?? '').toString();
    final iconUrl = (service['image_url'] ?? service['icon_url']) as String?;
    return Card(
      margin: EdgeInsets.zero,
      color: Colors.white,
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: const Color(0xFFCCFBF1),
                backgroundImage: iconUrl != null ? NetworkImage(iconUrl) : null,
                child: iconUrl == null ? Icon(serviceIcon(name), color: kTeal, size: 28) : null,
              ),
              const SizedBox(height: 10),
              Text(name,
                  maxLines: 2,
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFF134E4A))),
            ],
          ),
        ),
      ),
    );
  }
}
