import 'package:intl/intl.dart';

/// One printable line on an invoice.
class InvoiceLine {
  final String label;
  final num amount;
  final bool bold;
  const InvoiceLine(this.label, this.amount, {this.bold = false});
}

class InvoiceData {
  final String title; // "TAX INVOICE" style heading
  final String number;
  final DateTime date;
  final List<List<String>> parties; // [label, value] shown at the top
  final List<List<String>> details; // [label, value]
  final List<String> tableHead;
  final List<List<String>> tableRows;
  final List<InvoiceLine> totals;
  final String footer;
  const InvoiceData({
    required this.title,
    required this.number,
    required this.date,
    required this.parties,
    required this.details,
    required this.tableHead,
    required this.tableRows,
    required this.totals,
    this.footer = 'Thank you for choosing Fixeaze. Questions? support@fixeaze.com',
  });
}

String inr(num v) => 'Rs. ${NumberFormat('#,##0.00', 'en_IN').format(v)}';

