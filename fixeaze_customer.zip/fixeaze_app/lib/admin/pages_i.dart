import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

AdminStore get _s => AdminStore.I;

String _d(DateTime d) => '${d.day.toString().padLeft(2, '0')} ${const ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.month - 1]} ${d.year}';

DateTime _day(DateTime d) => DateTime(d.year, d.month, d.day);
DateTime _monday(DateTime d) => _day(d).subtract(Duration(days: d.weekday - 1));

bool _unpaid(Rec p) => p['status'] == 'pending' || p['status'] == 'processing';

// ============================================================== SALARY PAGE

class SalaryPage extends StatefulWidget {
  const SalaryPage({super.key});
  @override
  State<SalaryPage> createState() => _SalaryPageState();
}

class _SalaryPageState extends State<SalaryPage> {
  late DateTime _from;
  late DateTime _to; // exclusive
  String _preset = 'last_week';
  late DateTime _payOn;
  final _q = TextEditingController();
  bool _onlyUnpaid = true;

  @override
  void initState() {
    super.initState();
    _applyPreset('last_week');
    _payOn = _day(DateTime.now()).add(const Duration(days: 2));
    _s.addListener(_changed);
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _s.removeListener(_changed);
    _q.dispose();
    super.dispose();
  }

  void _applyPreset(String k) {
    final today = _day(DateTime.now());
    final thisMon = _monday(today);
    _preset = k;
    switch (k) {
      case 'this_week':
        _from = thisMon;
        _to = today.add(const Duration(days: 1));
        break;
      case 'last_7':
        _from = today.subtract(const Duration(days: 6));
        _to = today.add(const Duration(days: 1));
        break;
      case 'last_month':
        _from = DateTime(today.year, today.month - 1, 1);
        _to = DateTime(today.year, today.month, 1);
        break;
      default:
        _from = thisMon.subtract(const Duration(days: 7));
        _to = thisMon;
    }
  }

  Future<void> _custom() async {
    final r = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2024),
      lastDate: DateTime.now().add(const Duration(days: 1)),
      initialDateRange: DateTimeRange(start: _from, end: _to.subtract(const Duration(days: 1))),
    );
    if (r == null) return;
    setState(() {
      _preset = 'custom';
      _from = _day(r.start);
      _to = _day(r.end).add(const Duration(days: 1));
    });
  }

  Future<void> _pickPayOn() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _payOn,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 120)),
    );
    if (d != null) setState(() => _payOn = d);
  }

  bool _inRange(dynamic ts) {
    final t = parseTime(ts)?.toLocal();
    return t != null && !t.isBefore(_from) && t.isBefore(_to);
  }

  String get _label => '${_d(_from)} - ${_d(_to.subtract(const Duration(days: 1)))}';

  List<Rec> _rowsOf(String payee) =>
      _s.payments.where((p) => _s.payeeOf(p['technician_id']) == payee && _inRange(p['created_at'])).toList();

  Rec _kyc(String id) => _s.institutionOfOwner(id) ?? _s.KYC[id] ?? <String, dynamic>{};

  bool _hasPayInfo(String id) {
    final k = _kyc(id);
    final hasBank = '${k['bank_account_no'] ?? ''}'.trim().isNotEmpty && '${k['bank_ifsc'] ?? ''}'.trim().isNotEmpty;
    final hasUpi = '${k['upi_id'] ?? ''}'.trim().isNotEmpty;
    return hasBank || hasUpi;
  }

  Future<void> _scheduleAll() async {
    final ok = await confirmBox(
        context,
        'Set ${_d(_payOn)} as the payout date for every technician\'s unpaid jobs from $_label? '
        'Each technician is told the date and amount.',
        yes: 'Set date');
    if (!ok || !mounted) return;
    final err = await _s.salarySchedule(null, _from, _to, _payOn);
    if (mounted) report(context, err, 'Payout date set. Technicians can see it now.');
  }

  Future<void> _scheduleOne(String id) async {
    final err = await _s.salarySchedule(id, _from, _to, _payOn);
    if (mounted) report(context, err, 'Payout date set for ${_s.payeeName(id)}');
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final q = _q.text.trim().toLowerCase();

    // one entry per technician with payments in the period
    final ids = <String>{for (final p in s.payments) if (_inRange(p['created_at'])) s.payeeOf(p['technician_id'])};
    final entries = <Map<String, dynamic>>[];
    for (final id in ids) {
      final rows = _rowsOf(id);
      final unpaid = rows.where(_unpaid).toList();
      final paid = rows.where((p) => p['status'] == 'paid').toList();
      num sum(List<Rec> l, String k) => l.fold<num>(0, (a, p) => a + numOf(p[k]));
      final dates = {for (final p in unpaid) if (p['pay_on'] != null) '${p['pay_on']}'};
      entries.add({
        'id': id,
        'jobs': rows.length,
        'unpaidJobs': unpaid.length,
        'net': sum(unpaid, 'amount'),
        'gross': sum(unpaid, 'gross'),
        'commission': sum(unpaid, 'commission'),
        'deducted': sum(unpaid, 'deducted'),
        'paid': sum(paid, 'amount'),
        'payOn': dates.isEmpty ? '' : (dates.length == 1 ? dates.first : 'Mixed'),
      });
    }
    var list = entries.where((e) {
      if (_onlyUnpaid && (e['unpaidJobs'] as int) == 0) return false;
      if (q.isEmpty) return true;
      final id = '${e['id']}';
      return '${s.payeeName(id)} ${s.P[id]?['phone'] ?? ''}'.toLowerCase().contains(q);
    }).toList()
      ..sort((a, b) => (b['net'] as num).compareTo(a['net'] as num));

    final totalNet = entries.fold<num>(0, (a, e) => a + (e['net'] as num));
    final totalPaid = entries.fold<num>(0, (a, e) => a + (e['paid'] as num));
    final toPay = entries.where((e) => (e['net'] as num) > 0).toList();
    final scheduled = entries.where((e) => '${e['payOn']}'.isNotEmpty).fold<num>(0, (a, e) => a + (e['net'] as num));
    final noInfo = toPay.where((e) => !_hasPayInfo('${e['id']}')).length;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (s.errors['technician_payouts'] != null)
          NoticeBanner('Salary tools are not ready. Run sql/v2_part20_salary.sql in Supabase. (${s.errors['technician_payouts']})',
              color: kBad),
        Wrap(spacing: 8, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
          for (final e in const {'last_week': 'Last week', 'this_week': 'This week', 'last_7': 'Last 7 days', 'last_month': 'Last month'}.entries)
            ChoiceChip(
              label: Text(e.value),
              selected: _preset == e.key,
              onSelected: (_) => setState(() => _applyPreset(e.key)),
            ),
          ActionChip(
            avatar: const Icon(Icons.date_range, size: 18),
            label: Text(_preset == 'custom' ? _label : 'Pick dates'),
            onPressed: _custom,
          ),
        ]),
        const SizedBox(height: 6),
        Muted('Jobs finished: $_label. Amount = what the technician earns after Fixeaze commission '
            '(and any cash commission already deducted).'),
        const SizedBox(height: 12),
        TileGrid([
          StatTile('To pay', money(totalNet), sub: '${toPay.length} technician${toPay.length == 1 ? '' : 's'}'),
          StatTile('Payout date set for', money(scheduled), sub: 'technicians can see the date'),
          StatTile('Already paid', money(totalPaid), sub: _label),
          StatTile('No bank / UPI on file', '$noInfo', sub: 'add their details to pay', alert: noInfo > 0),
        ]),
        const SizedBox(height: 14),
        SectionCard(
          title: 'Payout date',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Muted('Choose the day you will pay. Technicians see "Rs X will be paid on <date>" in their Payments tab.'),
            const SizedBox(height: 10),
            Wrap(spacing: 10, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size(0, 42)),
                onPressed: _pickPayOn,
                icon: const Icon(Icons.event),
                label: Text(_d(_payOn)),
              ),
              FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size(0, 42)),
                onPressed: toPay.isEmpty ? null : _scheduleAll,
                child: const Text('Set this date for everyone'),
              ),
            ]),
          ]),
        ),
        const SizedBox(height: 14),
        Wrap(spacing: 12, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
          SizedBox(
            width: 240,
            child: TextField(
              controller: _q,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(isDense: true, prefixIcon: Icon(Icons.search), hintText: 'Technician name or phone'),
            ),
          ),
          FilterChip(
            label: const Text('Only unpaid'),
            selected: _onlyUnpaid,
            onSelected: (v) => setState(() => _onlyUnpaid = v),
          ),
          CsvButton(
            label: 'Bank transfer sheet (CSV)',
            name: 'salary_${_from.toIso8601String().substring(0, 10)}',
            headers: () => ['Technician', 'Phone', 'Jobs', 'Gross', 'Commission', 'Amount to pay', 'Pay on', 'Account holder', 'Bank', 'Account no', 'IFSC', 'UPI'],
            rows: () => [
              for (final e in list)
                () {
                  final id = '${e['id']}';
                  final k = _kyc(id);
                  return <dynamic>[
                    s.payeeName(id), s.P[id]?['phone'] ?? '', e['unpaidJobs'], e['gross'], e['commission'], e['net'],
                    e['payOn'], k['bank_holder_name'] ?? '', k['bank_name'] ?? '', k['bank_account_no'] ?? '',
                    k['bank_ifsc'] ?? '', k['upi_id'] ?? '',
                  ];
                }(),
            ],
          ),
        ]),
        const SizedBox(height: 10),
        AdminTable(
          columns: const ['Technician', 'Jobs', 'Gross', 'Commission', 'To pay', 'Pay on', 'Bank / UPI', ''],
          numeric: const {1, 2, 3, 4},
          empty: _onlyUnpaid ? 'Nothing waiting to be paid for these dates.' : 'No jobs finished in these dates.',
          rows: [
            for (final e in list)
              () {
                final id = '${e['id']}';
                final k = _kyc(id);
                final net = e['net'] as num;
                final info = _hasPayInfo(id);
                final payOn = '${e['payOn']}';
                return <Widget>[
                  TwoLine(s.payeeName(id),
                      s.institutionOfOwner(id) != null ? 'Institution · ${s.P[id]?['phone'] ?? ''}' : '${s.P[id]?['phone'] ?? ''}'),
                  Text('${e['unpaidJobs']}'),
                  Text(money(e['gross'])),
                  Text(money(e['commission'])),
                  net > 0
                      ? Text(money(net), style: const TextStyle(fontWeight: FontWeight.bold))
                      : const Pill('Paid', kOk),
                  payOn.isEmpty
                      ? const Muted('Not set')
                      : (payOn == 'Mixed' ? const Pill('Mixed dates', kWarn) : Text(_d(DateTime.parse(payOn)))),
                  info
                      ? TwoLine(
                          '${k['upi_id'] ?? ''}'.isNotEmpty ? '${k['upi_id']}' : '${k['bank_holder_name'] ?? ''}',
                          '${k['bank_name'] ?? ''} ${_mask('${k['bank_account_no'] ?? ''}')}'.trim())
                      : const Pill('Not added', kBad),
                  Wrap(spacing: 6, runSpacing: 6, children: [
                    FilledButton(
                      style: FilledButton.styleFrom(minimumSize: const Size(0, 38)),
                      onPressed: net > 0
                          ? () => showDialog<void>(
                              context: context,
                              builder: (_) => _PayDialog(techId: id, from: _from, to: _to, net: net, jobs: e['unpaidJobs'] as int))
                          : null,
                      child: const Text('Pay'),
                    ),
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
                      onPressed: net > 0 ? () => _scheduleOne(id) : null,
                      child: Text('Date: ${_d(_payOn).substring(0, 6)}'),
                    ),
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
                      onPressed: () => showDialog<void>(
                          context: context, builder: (_) => _JobsDialog(techId: id, rows: _rowsOf(id), label: _label)),
                      child: const Text('Jobs'),
                    ),
                  ]),
                ];
              }(),
          ],
        ),
        const SectionTitle('Payout history'),
        AdminTable(
          columns: const ['Paid on', 'Technician', 'Period', 'Jobs', 'Amount', 'Reference'],
          numeric: const {3, 4},
          empty: 'No payouts yet.',
          rows: [
            for (final p in s.payouts.take(60))
              <Widget>[
                Text(fdt(p['created_at'])),
                Text(s.payeeName(p['technician_id'])),
                Text('${fday(p['period_from'])} - ${fday(DateTime.tryParse('${p['period_to']}')?.subtract(const Duration(days: 1)).toIso8601String())}'),
                Text('${p['jobs']}'),
                Text(money(p['amount']), style: const TextStyle(fontWeight: FontWeight.bold)),
                Text('${p['reference'] ?? ''}'),
              ],
          ],
        ),
      ],
    );
  }
}

String _mask(String a) => a.length <= 4 ? a : 'A/c ****${a.substring(a.length - 4)}';

// ============================================================== PAY DIALOG

class _PayDialog extends StatefulWidget {
  final String techId;
  final DateTime from;
  final DateTime to;
  final num net;
  final int jobs;
  const _PayDialog({required this.techId, required this.from, required this.to, required this.net, required this.jobs});
  @override
  State<_PayDialog> createState() => _PayDialogState();
}

class _PayDialogState extends State<_PayDialog> {
  final _ref = TextEditingController();
  final _note = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _ref.dispose();
    _note.dispose();
    super.dispose();
  }

  Widget _copyRow(String label, String value) {
    if (value.trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(children: [
        SizedBox(width: 110, child: Text(label, style: const TextStyle(color: Colors.black54))),
        Expanded(child: SelectableText(value, style: const TextStyle(fontWeight: FontWeight.w600))),
        IconButton(
          visualDensity: VisualDensity.compact,
          tooltip: 'Copy',
          icon: const Icon(Icons.copy, size: 18),
          onPressed: () {
            Clipboard.setData(ClipboardData(text: value));
            toast(context, '$label copied');
          },
        ),
      ]),
    );
  }

  Future<void> _upi(String upi) async {
    final name = _s.payeeName(widget.techId);
    final uri = 'upi://pay?pa=${Uri.encodeComponent(upi)}&pn=${Uri.encodeComponent(name)}'
        '&am=${widget.net.toStringAsFixed(2)}&cu=INR&tn=${Uri.encodeComponent('Fixeaze payout')}';
    try {
      await launchUrl(Uri.parse(uri), mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) toast(context, 'Could not open a UPI app. Copy the UPI ID and pay manually.', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final id = widget.techId;
    final k = _s.institutionOfOwner(id) ?? _s.KYC[id] ?? <String, dynamic>{};
    final upi = '${k['upi_id'] ?? ''}'.trim();
    final hasBank = '${k['bank_account_no'] ?? ''}'.trim().isNotEmpty;
    return AlertDialog(
      title: Text('Pay ${_s.payeeName(id)}'),
      content: SizedBox(
        width: 460,
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text(money(widget.net), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
            Muted('${widget.jobs} job${widget.jobs == 1 ? '' : 's'} · ${_d(widget.from)} - ${_d(widget.to.subtract(const Duration(days: 1)))}'),
            const Divider(height: 22),
            if (!hasBank && upi.isEmpty)
              const Text('No bank account or UPI on file for this technician. Add it below, or ask them to add it.',
                  style: TextStyle(color: kBad)),
            _copyRow('Account holder', '${k['bank_holder_name'] ?? ''}'),
            _copyRow('Bank', '${k['bank_name'] ?? ''}'),
            _copyRow('Account no', '${k['bank_account_no'] ?? ''}'),
            _copyRow('IFSC', '${k['bank_ifsc'] ?? ''}'),
            _copyRow('UPI ID', upi),
            const SizedBox(height: 6),
            Wrap(spacing: 8, runSpacing: 8, children: [
              if (upi.isNotEmpty)
                FilledButton.icon(
                  onPressed: () => _upi(upi),
                  icon: const Icon(Icons.payments_outlined),
                  label: Text('Pay ${money(widget.net)} with UPI app'),
                ),
              OutlinedButton.icon(
                onPressed: () => showDialog<void>(context: context, builder: (_) => _BankDialog(techId: id))
                    .then((_) => setState(() {})),
                icon: const Icon(Icons.edit_outlined),
                label: const Text('Edit bank / UPI'),
              ),
            ]),
            const Divider(height: 26),
            const Text('After you have paid:', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            TextField(
              controller: _ref,
              decoration: const InputDecoration(labelText: 'UTR / reference number (optional)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _note,
              decoration: const InputDecoration(labelText: 'Note for the technician (optional)', border: OutlineInputBorder()),
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: kOk),
          onPressed: _busy
              ? null
              : () async {
                  final ok = await confirmBox(
                      context, 'Mark ${money(widget.net)} as PAID to ${_s.payeeName(id)}? They will see it as paid.',
                      yes: 'Mark paid');
                  if (!ok || !mounted) return;
                  setState(() => _busy = true);
                  final err = await _s.salaryPay(id, widget.from, widget.to, _ref.text.trim(), _note.text.trim());
                  if (!mounted) return;
                  setState(() => _busy = false);
                  report(context, err, 'Marked as paid. The technician has been told.');
                  if (err == null) Navigator.pop(context);
                },
          child: const Text('Mark as paid'),
        ),
      ],
    );
  }
}

// ============================================================== BANK DETAILS

class _BankDialog extends StatefulWidget {
  final String techId;
  const _BankDialog({required this.techId});
  @override
  State<_BankDialog> createState() => _BankDialogState();
}

class _BankDialogState extends State<_BankDialog> {
  late final TextEditingController _holder;
  late final TextEditingController _bank;
  late final TextEditingController _acc;
  late final TextEditingController _ifsc;
  late final TextEditingController _upi;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final k = _s.institutionOfOwner(widget.techId) ?? _s.KYC[widget.techId] ?? <String, dynamic>{};
    String t(String x) => '${k[x] ?? ''}';
    _holder = TextEditingController(text: t('bank_holder_name'));
    _bank = TextEditingController(text: t('bank_name'));
    _acc = TextEditingController(text: t('bank_account_no'));
    _ifsc = TextEditingController(text: t('bank_ifsc'));
    _upi = TextEditingController(text: t('upi_id'));
  }

  @override
  void dispose() {
    for (final c in [_holder, _bank, _acc, _ifsc, _upi]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Bank / UPI of ${_s.payeeName(widget.techId)}'),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: _holder, decoration: const InputDecoration(labelText: 'Account holder name')),
            const SizedBox(height: 8),
            TextField(controller: _bank, decoration: const InputDecoration(labelText: 'Bank name')),
            const SizedBox(height: 8),
            TextField(controller: _acc, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Account number')),
            const SizedBox(height: 8),
            TextField(controller: _ifsc, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'IFSC code')),
            const SizedBox(height: 8),
            TextField(controller: _upi, decoration: const InputDecoration(labelText: 'UPI ID', hintText: 'name@bank')),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: _busy
              ? null
              : () async {
                  setState(() => _busy = true);
                  final err = await _s.bankSave(widget.techId, {
                    'bank_holder_name': _holder.text.trim(),
                    'bank_name': _bank.text.trim(),
                    'bank_account_no': _acc.text.trim(),
                    'bank_ifsc': _ifsc.text.trim().toUpperCase(),
                    'upi_id': _upi.text.trim(),
                  });
                  if (!mounted) return;
                  setState(() => _busy = false);
                  report(context, err, 'Saved');
                  if (err == null) Navigator.pop(context);
                },
          child: const Text('Save'),
        ),
      ],
    );
  }
}

// ============================================================== JOBS BREAKDOWN

class _JobsDialog extends StatelessWidget {
  final String techId;
  final List<Rec> rows;
  final String label;
  const _JobsDialog({required this.techId, required this.rows, required this.label});

  @override
  Widget build(BuildContext context) {
    final s = _s;
    Rec booking(dynamic id) => s.bookings.firstWhere((b) => b['id'] == id, orElse: () => <String, dynamic>{});
    return AlertDialog(
      title: Text('${s.payeeName(techId)} · jobs'),
      content: SizedBox(
        width: 560,
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Muted(label),
            const SizedBox(height: 8),
            AdminTable(
              columns: const ['Job', 'Technician', 'Method', 'Gross', 'Commission', 'Cash comm. deducted', 'Net', 'Status'],
              numeric: const {3, 4, 5, 6},
              empty: 'No jobs.',
              rows: [
                for (final p in rows)
                  () {
                    final b = booking(p['booking_id']);
                    return <Widget>[
                      TwoLine(b.isEmpty ? '-' : s.svcName(b['service_id']), fday(p['created_at'])),
                      Text(s.nameOf(p['technician_id'])),
                      Text('${p['method'] ?? ''}'),
                      Text(money(p['gross'])),
                      Text(money(p['commission'])),
                      Text(money(p['deducted'])),
                      Text(money(p['amount']), style: const TextStyle(fontWeight: FontWeight.bold)),
                      PayPill('${p['status'] ?? ''}'),
                    ];
                  }(),
              ],
            ),
          ]),
        ),
      ),
      actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
    );
  }
}
