import 'dart:convert';
import 'dart:js_interop';
import 'dart:js_interop_unsafe';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import 'admin_widgets.dart';

@JS('fixeazePush')
external JSObject? get _fx;

/// Makes sure the small push.js helper is on the page (adds it if the page was built without it).
Future<bool> _ensureBridge() async {
  if (_fx != null) return true;
  try {
    final doc = globalContext['document'] as JSObject;
    final el = doc.callMethod('createElement'.toJS, 'script'.toJS) as JSObject;
    el['src'] = 'push.js?v=2'.toJS;
    (doc['head'] as JSObject).callMethod('appendChild'.toJS, el);
  } catch (_) {}
  for (var i = 0; i < 20; i++) {
    await Future<void>.delayed(const Duration(milliseconds: 150));
    if (_fx != null) return true;
  }
  return false;
}

/// Phone notifications for admins (Web Push). The sending side is the Edge Function "push".
class PushService {
  /// Public half of the notification key. The private half lives only in Supabase.
  static const vapidPublicKey =
      'BEW1X9dQ9to-7tUbirikRmuVdkc8fxNaJcEiYCEEQTOyK0AXKTBcCXV4bqpgUha03fT7M4-NZwIYWcmGj1sI_ns';

  static bool get supported {
    try {
      final fx = _fx;
      if (fx == null) return false;
      return (fx.callMethod('supported'.toJS) as JSBoolean).toDart;
    } catch (_) {
      return false;
    }
  }

  /// granted / denied / default / unsupported
  static String get permission {
    try {
      final fx = _fx;
      if (fx == null) return 'unsupported';
      return (fx.callMethod('permission'.toJS) as JSString).toDart;
    } catch (_) {
      return 'unsupported';
    }
  }

  /// Plays the alert or chat sound. Returns an error text, or null when it started playing.
  static Future<String?> playSound(String kind) async {
    try {
      final url = kind == 'chat' ? 'sounds/chat.wav' : 'sounds/alert.wav';
      final ctor = globalContext['Audio'] as JSFunction;
      final audio = ctor.callAsConstructor<JSObject>(url.toJS);
      audio['volume'] = 1.0.toJS;
      await (audio.callMethod('play'.toJS) as JSPromise).toDart;
      return null;
    } catch (e) {
      return 'The sound could not play ($e). Turn the phone volume up, make sure it is not on silent, '
          'and check that the latest build with the sounds folder is deployed.';
    }
  }

  /// Turns notifications on for this phone and saves it. Returns an error text, or null when done.
  static Future<String?> enable({bool ask = true}) async {
    try {
      if (!await _ensureBridge()) {
        return 'The notification helper (push.js) is missing from this site. Upload the latest admin build and open the app again.';
      }
      final promise = _fx!.callMethod('enable'.toJS, vapidPublicKey.toJS, ask.toJS) as JSPromise<JSString>;
      final text = (await promise.toDart).toDart;
      if (text.isEmpty) return null;
      final json = (jsonDecode(text) as Map).cast<String, dynamic>();
      final keys = ((json['keys'] ?? const <String, dynamic>{}) as Map).cast<String, dynamic>();
      final me = supabase.auth.currentUser;
      if (me == null) return 'You are not logged in. Log in again.';
      await supabase.from('admin_push_subscriptions').upsert({
        'admin_id': me.id,
        'endpoint': json['endpoint'],
        'p256dh': keys['p256dh'],
        'auth': keys['auth'],
        'user_agent': 'web',
      }, onConflict: 'endpoint');
      return null;
    } on PostgrestException catch (e) {
      return e.message;
    } catch (e) {
      final m = '$e';
      return m.contains('Error:') ? m.split('Error:').last.trim() : m;
    }
  }

  /// Quietly re-registers when permission was already given.
  static Future<void> refreshIfGranted() async {
    if (permission == 'granted') await enable(ask: false);
  }
}

// ============================================================== PAGE

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});
  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  bool _busy = false;
  String? _msg;
  bool _ok = false;

  @override
  void initState() {
    super.initState();
    _ensureBridge().then((_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _turnOn() async {
    setState(() {
      _busy = true;
      _msg = null;
    });
    final err = await PushService.enable();
    if (!mounted) return;
    setState(() {
      _busy = false;
      _ok = err == null;
      _msg = err ?? 'Notifications are on for this phone.';
    });
  }

  Future<void> _sound(String kind) async {
    final err = await PushService.playSound(kind);
    if (!mounted) return;
    setState(() {
      _ok = err == null;
      _msg = err ?? (kind == 'chat' ? 'Playing the chat sound...' : 'Playing the alert sound...');
    });
  }

  Future<void> _test() async {
    setState(() => _busy = true);
    try {
      await supabase.rpc('admin_push_test');
      if (!mounted) return;
      setState(() => _msg = 'Test sent. It should arrive in a few seconds.');
      _ok = true;
    } catch (e) {
      if (!mounted) return;
      _ok = false;
      _msg = e is PostgrestException ? e.message : 'Could not send the test: $e';
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final perm = PushService.permission;
    final on = perm == 'granted';
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SectionCard(
          title: 'Phone notifications',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(spacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
              on
                  ? const Pill('Allowed on this device', kOk)
                  : perm == 'denied'
                      ? const Pill('Blocked in settings', kBad)
                      : perm == 'unsupported'
                          ? const Pill('Not supported here', kWarn)
                          : const Pill('Not turned on', kWarn),
            ]),
            const SizedBox(height: 10),
            const Muted('Install the admin app on your home screen first (browser menu > Install app / Add to Home screen), '
                'open it, then tap the button below on every phone you want alerts on.'),
            const SizedBox(height: 12),
            Wrap(spacing: 10, runSpacing: 10, children: [
              FilledButton.icon(
                style: FilledButton.styleFrom(minimumSize: const Size(0, 44)),
                onPressed: _busy ? null : _turnOn,
                icon: const Icon(Icons.notifications_active_outlined),
                label: Text(on ? 'Refresh notifications' : 'Turn on notifications'),
              ),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size(0, 44)),
                onPressed: _busy ? null : _test,
                icon: const Icon(Icons.send_outlined),
                label: const Text('Send a test'),
              ),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size(0, 44)),
                onPressed: () => _sound('alert'),
                icon: const Icon(Icons.volume_up_outlined),
                label: const Text('Hear alert sound'),
              ),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size(0, 44)),
                onPressed: () => _sound('chat'),
                icon: const Icon(Icons.chat_bubble_outline),
                label: const Text('Hear chat sound'),
              ),
            ]),
            if (_msg != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(_msg!, style: TextStyle(color: _ok ? kOk : kBad, fontWeight: FontWeight.w600)),
              ),
          ]),
        ),
        const SizedBox(height: 14),
        const SectionCard(
          title: 'You will be told about',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('SOS alerts'),
            Text('New bookings'),
            Text('Bookings nobody accepted in 30 minutes (OTC)'),
            Text('New support tickets and customer replies'),
            Text('Technicians waiting for approval'),
            Text('Technician payments pending'),
            Text('Messages in Admin chat (group and personal)'),
          ]),
        ),
        const SizedBox(height: 14),
        const SectionCard(
          title: 'About the sounds',
          child: Muted('While the app is open you hear the alert chime for everything, and a different soft pop for chat. '
              'When the app is closed the phone itself plays its normal notification sound (a website cannot choose it), '
              'so chat is told apart by a short buzz and everything else by a long buzz.'),
        ),
      ],
    );
  }
}
