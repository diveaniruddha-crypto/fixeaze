import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import 'fx_map_lazy.dart';

/// Technician's own position (profile lat/lng), cached.
class TechPos {
  static (double, double)? _cache;
  static Future<(double, double)?> get() async {
    if (_cache != null) return _cache;
    try {
      final id = supabase.auth.currentUser?.id;
      if (id == null) return null;
      final r = await supabase.from('profiles').select('lat,lng').eq('id', id).maybeSingle();
      final la = (r?['lat'] as num?)?.toDouble();
      final ln = (r?['lng'] as num?)?.toDouble();
      if (la != null && ln != null) _cache = (la, ln);
    } on PostgrestException catch (_) {}
    return _cache;
  }
}

/// Shows "X km from you", an expandable map and a Navigate button.
class JobLocation extends StatefulWidget {
  final Map<String, dynamic> booking;
  const JobLocation({super.key, required this.booking});
  @override
  State<JobLocation> createState() => _JobLocationState();
}

class _JobLocationState extends State<JobLocation> {
  (double, double)? _me;
  bool _open = false;

  @override
  void initState() {
    super.initState();
    TechPos.get().then((v) {
      if (mounted) setState(() => _me = v);
    });
  }

  @override
  Widget build(BuildContext context) {
    final la = (widget.booking['lat'] as num?)?.toDouble();
    final ln = (widget.booking['lng'] as num?)?.toDouble();
    if (la == null || ln == null) return const SizedBox.shrink();
    final km = _me == null ? null : kmExact(_me!.$1, _me!.$2, la, ln);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 6),
      Row(children: [
        const Icon(Icons.directions, size: 16, color: Colors.teal),
        const SizedBox(width: 6),
        Expanded(
          child: Text(km == null ? 'Distance unavailable' : '${km.toStringAsFixed(1)} km from your location',
              style: const TextStyle(fontWeight: FontWeight.w600)),
        ),
        TextButton(onPressed: () => setState(() => _open = !_open), child: Text(_open ? 'Hide map' : 'Map')),
        TextButton(
          onPressed: () => launchUrl(
              Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$la,$ln'),
              mode: LaunchMode.externalApplication),
          child: const Text('Navigate'),
        ),
      ]),
      if (_open)
        FxMap(height: 200, pins: [
          FxPin(la, ln, 'Customer', color: Colors.red, icon: Icons.home, id: 'line'),
          if (_me != null) FxPin(_me!.$1, _me!.$2, 'You', icon: Icons.person_pin_circle, id: 'line'),
        ]),
    ]);
  }
}
