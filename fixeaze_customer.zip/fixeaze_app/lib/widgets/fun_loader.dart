import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

const funnyQuotes = [
  'Our internet is on a coffee break. Back in a sec ☕',
  'Loading... even snails are overtaking us 🐌',
  'Hold on, the data is stuck in traffic 🚦',
  'Your Wi-Fi is thinking really hard 🤔',
  'Patience, young padawan. The bytes are coming 🛸',
  'Slow internet? Time to stretch your thumbs 💪',
  'Fixing the internet with a spanner 🔧',
  'Bytes are walking. No flights today ✈️',
  'A watched loader never loads 👀',
  'Be like our technicians: calm, steady, reliable 🛠️',
];

String randomQuote() => funnyQuotes[math.Random().nextInt(funnyQuotes.length)];

/// Spinner that turns into a funny line when loading takes more than a few seconds.
class FunLoader extends StatefulWidget {
  const FunLoader({super.key});
  @override
  State<FunLoader> createState() => _FunLoaderState();
}

class _FunLoaderState extends State<FunLoader> {
  Timer? _t;
  int _i = math.Random().nextInt(funnyQuotes.length);
  bool _slow = false;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 3), (t) {
      if (!mounted) return;
      setState(() {
        if (!_slow) {
          _slow = true;
        } else {
          _i = (_i + 1) % funnyQuotes.length;
        }
      });
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const CircularProgressIndicator(),
          const SizedBox(height: 16),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child: _slow
                ? Text(funnyQuotes[_i],
                    key: ValueKey(_i), textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54))
                : const SizedBox(key: ValueKey('none'), height: 18),
          ),
        ]),
      ),
    );
  }
}

/// Rotating funny line, e.g. on the login screen.
class FunQuoteBanner extends StatefulWidget {
  const FunQuoteBanner({super.key});
  @override
  State<FunQuoteBanner> createState() => _FunQuoteBannerState();
}

class _FunQuoteBannerState extends State<FunQuoteBanner> {
  Timer? _t;
  int _i = math.Random().nextInt(funnyQuotes.length);

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) setState(() => _i = (_i + 1) % funnyQuotes.length);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: Container(
        key: ValueKey(_i),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(color: Colors.amber.withOpacity(0.18), borderRadius: BorderRadius.circular(14)),
        child: Text(funnyQuotes[_i], textAlign: TextAlign.center, style: const TextStyle(fontStyle: FontStyle.italic)),
      ),
    );
  }
}
