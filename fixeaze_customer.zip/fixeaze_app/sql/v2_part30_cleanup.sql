-- PIECE 1: backup log
create table if not exists public.backup_log (
  id uuid primary key default gen_random_uuid(),
  kind text,
  admin_id uuid default auth.uid(),
  created_at timestamptz not null default now());
alter table public.backup_log enable row level security;
drop policy if exists "backup_log admin" on public.backup_log;
create policy "backup_log admin" on public.backup_log for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert on public.backup_log to authenticated;

-- PIECE 2: safe clean-up of old, low-value rows (needs a backup in the last 2 days)
create or replace function public.admin_cleanup_old_data(p_months int, p_apply boolean default false)
returns table (item text, n bigint)
language plpgsql security definer set search_path = public as $$
declare cutoff timestamptz; rec record; cnt bigint;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  if coalesce(p_months, 0) < 3 then raise exception 'Keep at least 3 months of data'; end if;
  cutoff := now() - make_interval(months => p_months);
  if p_apply and not exists (select 1 from public.backup_log where created_at > now() - interval '2 days') then
    raise exception 'Download or email a backup first (within the last 2 days)';
  end if;
  for rec in
    select * from (values
      ('messages', 'created_at', 'Booking chat messages'),
      ('admin_chat', 'created_at', 'Admin chat messages'),
      ('tech_chat', 'created_at', 'Technician support chat messages'),
      ('technician_notifications', 'created_at', 'Technician notifications'),
      ('admin_activity', 'day', 'Admin activity logs')
    ) as v(t, c, label)
  loop
    if to_regclass('public.' || rec.t) is null then continue; end if;
    execute format('select count(*) from public.%I where %I < $1', rec.t, rec.c) into cnt using cutoff;
    if p_apply and cnt > 0 then
      execute format('delete from public.%I where %I < $1', rec.t, rec.c) using cutoff;
    end if;
    item := rec.label; n := cnt; return next;
  end loop;
end $$;
grant execute on function public.admin_cleanup_old_data(int, boolean) to authenticated;
