-- Part 15: Help & support tickets + admin group chat. Safe to run more than once.

create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  ticket_no bigint generated always as identity,
  created_by uuid not null references public.profiles(id) on delete cascade,
  role text not null,
  booking_id uuid references public.bookings(id) on delete set null,
  subject text not null,
  status text not null default 'open' check (status in ('open','answered','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.support_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.support_tickets(id) on delete cascade,
  sender_id uuid not null,
  sender_role text not null check (sender_role in ('user','admin')),
  body text not null,
  created_at timestamptz not null default now()
);
create index if not exists support_messages_ticket on public.support_messages(ticket_id, created_at);
create table if not exists public.admin_chat (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

alter table public.support_tickets enable row level security;
alter table public.support_messages enable row level security;
alter table public.admin_chat enable row level security;

drop policy if exists "tickets read" on public.support_tickets;
create policy "tickets read" on public.support_tickets for select to authenticated
  using (created_by = auth.uid() or public.is_admin());
drop policy if exists "tickets admin update" on public.support_tickets;
create policy "tickets admin update" on public.support_tickets for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "smsg read" on public.support_messages;
create policy "smsg read" on public.support_messages for select to authenticated
  using (public.is_admin() or exists (select 1 from public.support_tickets t
         where t.id = ticket_id and t.created_by = auth.uid()));
drop policy if exists "smsg user insert" on public.support_messages;
create policy "smsg user insert" on public.support_messages for insert to authenticated
  with check (
    (sender_role = 'user' and sender_id = auth.uid() and exists (
       select 1 from public.support_tickets t where t.id = ticket_id and t.created_by = auth.uid()))
    or (sender_role = 'admin' and sender_id = auth.uid() and public.is_admin()));

drop policy if exists "achat read" on public.admin_chat;
create policy "achat read" on public.admin_chat for select to authenticated using (public.is_admin());
drop policy if exists "achat insert" on public.admin_chat;
create policy "achat insert" on public.admin_chat for insert to authenticated
  with check (public.is_admin() and sender_id = auth.uid());

grant select on public.support_tickets to authenticated;
grant update on public.support_tickets to authenticated;
grant select, insert on public.support_messages to authenticated;
grant select, insert on public.admin_chat to authenticated;

-- New message updates the ticket status
create or replace function public.on_support_message()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update public.support_tickets
     set updated_at = now(),
         status = case when new.sender_role = 'admin' then 'answered' else 'open' end
   where id = new.ticket_id;
  return new;
end $$;
drop trigger if exists trg_support_message on public.support_messages;
create trigger trg_support_message after insert on public.support_messages
  for each row execute function public.on_support_message();

-- Raise a ticket (optionally about one of your bookings)
create or replace function public.support_create(p_booking uuid, p_subject text, p_body text)
returns uuid language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); r text; tid uuid;
begin
  if uid is null then raise exception 'Please log in first'; end if;
  if coalesce(trim(p_subject), '') = '' or coalesce(trim(p_body), '') = '' then
    raise exception 'Write a subject and describe your problem';
  end if;
  select role into r from public.profiles where id = uid;
  if p_booking is not null and not exists (
      select 1 from public.bookings b where b.id = p_booking
        and (b.customer_id = uid or b.technician_id = uid)) then
    raise exception 'That booking is not yours';
  end if;
  insert into public.support_tickets (created_by, role, booking_id, subject)
  values (uid, coalesce(r, 'customer'), p_booking, trim(p_subject)) returning id into tid;
  insert into public.support_messages (ticket_id, sender_id, sender_role, body)
  values (tid, uid, 'user', trim(p_body));
  return tid;
end $$;
grant execute on function public.support_create(uuid, text, text) to authenticated;
