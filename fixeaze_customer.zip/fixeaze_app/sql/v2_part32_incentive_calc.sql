-- Part 32: work out, hold and credit monthly incentives (admin only)
create or replace function public.admin_incentive_calc(p_month date, p_credit_on date default null)
returns int language plpgsql security definer set search_path = public as $$
declare
  s public.incentive_settings; m0 date; m1 date; t0 timestamptz; t1 timestamptz;
  r record; n int := 0; ld int; jb int; ba numeric; cn int; st text; rs text; amt numeric; cr date;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  select * into s from public.incentive_settings where id = 1;
  if not s.enabled then raise exception 'Switch incentives on first'; end if;
  m0 := date_trunc('month', p_month)::date;
  m1 := (m0 + interval '1 month')::date;
  t0 := m0::timestamp at time zone 'Asia/Kolkata';
  t1 := m1::timestamp at time zone 'Asia/Kolkata';
  cr := coalesce(p_credit_on, m1 + (s.credit_day - 1));
  for r in select id from public.profiles where role = 'technician' loop
    if exists (select 1 from public.incentive_awards where month = m0 and technician_id = r.id and status = 'credited') then
      continue;
    end if;
    select count(*) into ld from public.technician_login_days
     where technician_id = r.id and day >= m0 and day < m1;
    select count(*), coalesce(sum(case when s.base = 'earnings' then coalesce(tech_amount, 0)
                                       else coalesce(gross_total, 0) end), 0)
      into jb, ba from public.bookings
     where technician_id = r.id and status = 'completed' and finished_at >= t0 and finished_at < t1;
    select count(*) into cn from public.cancellations
     where by_role = 'technician' and by_user = r.id and created_at >= t0 and created_at < t1;
    if ld = 0 and jb = 0 and cn = 0 then continue; end if;
    if cn > 0 then
      st := 'not_eligible'; rs := 'Cancelled ' || cn || ' booking(s) this month';
    elsif ld < s.min_login_days then
      st := 'not_eligible'; rs := 'Logged in ' || ld || ' of ' || s.min_login_days || ' days';
    elsif jb = 0 then
      st := 'not_eligible'; rs := 'No completed bookings';
    else
      st := 'eligible'; rs := null;
    end if;
    amt := case when st = 'eligible' then round(ba * s.pct / 100, 2) else 0 end;
    insert into public.incentive_awards
      (month, technician_id, login_days, jobs, base_amount, pct, amount, cancels, status, reason, credit_on)
    values (m0, r.id, ld, jb, ba, s.pct, amt, cn, st, rs, cr)
    on conflict (month, technician_id) do update set
      login_days = excluded.login_days, jobs = excluded.jobs, base_amount = excluded.base_amount,
      pct = excluded.pct, amount = excluded.amount, cancels = excluded.cancels,
      status = case when public.incentive_awards.status = 'held' and excluded.status = 'eligible'
                    then 'held' else excluded.status end,
      reason = excluded.reason, credit_on = excluded.credit_on;
    n := n + 1;
  end loop;
  return n;
end $$;
grant execute on function public.admin_incentive_calc(date, date) to authenticated;

create or replace function public.admin_incentive_hold(p_id uuid, p_hold boolean, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare a public.incentive_awards;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  select * into a from public.incentive_awards where id = p_id;
  if not found then raise exception 'Not found'; end if;
  if a.status = 'credited' then raise exception 'Already credited'; end if;
  if a.status = 'not_eligible' and not p_hold then raise exception 'Not eligible, calculate again'; end if;
  update public.incentive_awards
     set status = case when p_hold then 'held' else 'eligible' end,
         reason = case when p_hold then coalesce(nullif(trim(coalesce(p_note, '')), ''), 'Held by admin') else null end
   where id = p_id;
end $$;
grant execute on function public.admin_incentive_hold(uuid, boolean, text) to authenticated;

create or replace function public.admin_incentive_credit(p_month date, p_tech uuid default null)
returns int language plpgsql security definer set search_path = public as $$
declare a record; n int := 0; m0 date := date_trunc('month', p_month)::date; mname text;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  mname := to_char(m0, 'FMMonth YYYY');
  for a in select * from public.incentive_awards
            where month = m0 and status = 'eligible' and amount > 0
              and (p_tech is null or technician_id = p_tech) for update loop
    insert into public.technician_payments (technician_id, amount, status, method, note, pay_on)
    values (a.technician_id, a.amount, 'pending', 'incentive', 'Incentive for ' || mname, a.credit_on);
    update public.incentive_awards set status = 'credited', credited_at = now() where id = a.id;
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (a.technician_id, 'payment', 'Incentive credited',
            'Your incentive of Rs ' || a.amount || ' for ' || mname || ' is added to your payments'
            || coalesce(' and will be paid on ' || to_char(a.credit_on, 'DD Mon YYYY'), '') || '.');
    n := n + 1;
  end loop;
  return n;
end $$;
grant execute on function public.admin_incentive_credit(date, uuid) to authenticated;
