-- Part 22: institution employees go through the same KYC as individual technicians
-- (Aadhaar, selfie, shift, consent) but have no bank account: payments go to the institution.
-- Safe to run more than once. Needs part 21.

alter table public.technician_kyc add column if not exists selfie_image_path text;

create or replace function public.institution_employee_kyc(
  p_employee uuid, p_last4 text, p_aadhaar_name text, p_aadhaar_path text, p_selfie_path text,
  p_shift_start time, p_shift_end time, p_consent boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.inst_owner_of(p_employee) then raise exception 'Not your employee'; end if;
  if coalesce(p_last4, '') !~ '^[0-9]{4}$' then raise exception 'Invalid Aadhaar number'; end if;
  if coalesce(trim(p_aadhaar_name), '') = '' then raise exception 'Enter the name on the Aadhaar'; end if;
  if coalesce(p_aadhaar_path, '') = '' or coalesce(p_selfie_path, '') = '' then
    raise exception 'Aadhaar photo and selfie are required';
  end if;
  if p_shift_end <= p_shift_start then raise exception 'Shift end must be after shift start'; end if;

  insert into public.technician_kyc (id, aadhaar_last4, aadhaar_name, aadhaar_image_path, selfie_image_path,
                                     shift_confirmed, consent)
  values (p_employee, p_last4, trim(p_aadhaar_name), p_aadhaar_path, p_selfie_path, true, coalesce(p_consent, false))
  on conflict (id) do update
     set aadhaar_last4 = excluded.aadhaar_last4, aadhaar_name = excluded.aadhaar_name,
         aadhaar_image_path = excluded.aadhaar_image_path, selfie_image_path = excluded.selfie_image_path,
         shift_confirmed = true, consent = excluded.consent;

  update public.technician_profiles set shift_start = p_shift_start, shift_end = p_shift_end
   where id = p_employee;
end $$;
grant execute on function public.institution_employee_kyc(uuid, text, text, text, text, time, time, boolean) to authenticated;
