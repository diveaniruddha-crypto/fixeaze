-- Part 34: offer discounts are paid by Fixeaze, not the technician (replaces job_finish from part 11)
-- Run part 33 and 33b first.
create or replace function public.job_finish(p_booking uuid, p_code text)
returns boolean language plpgsql security definer set search_path = public as $$
declare
  b public.bookings; o public.job_otps; pct numeric(5,2);
  gross numeric(10,2); base numeric(10,2); disc numeric(10,2); comm numeric(10,2); net numeric(10,2); ded numeric(10,2) := 0;
  d record; take numeric(10,2); note_txt text;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.customer_id is distinct from auth.uid() or b.job_stage is distinct from 'end_otp' then
    raise exception 'Not allowed';
  end if;
  select * into o from public.job_otps where booking_id = p_booking and kind = 'end';
  if not found then raise exception 'No OTP'; end if;
  if o.attempts >= 5 then raise exception 'Too many wrong tries. Ask the technician to confirm payment again.'; end if;
  if trim(coalesce(p_code, '')) <> o.code then
    update public.job_otps set attempts = attempts + 1 where booking_id = p_booking and kind = 'end';
    return false;
  end if;

  select commission_pct into pct from public.platform_settings where id = 1;
  pct := coalesce(pct, 20);
  gross := coalesce(b.gross_total, coalesce(b.price, 0) + b.parts_total);
  disc := coalesce(b.discount_amount, 0);   -- offer discount: Fixeaze pays it, not the technician
  base := gross + disc;                      -- job total before the offer
  comm := round(base * pct / 100, 2);
  net := base - comm;

  if b.payment_method = 'qr' then
    -- Fixeaze received the money: pay the technician their share, minus any cash commission still owed
    for d in select * from public.cash_dues
             where technician_id = b.technician_id and status = 'open'
             order by created_at for update loop
      exit when net <= 0;
      take := least(d.amount - d.settled, net);
      update public.cash_dues
         set settled = settled + take,
             status = case when settled + take >= amount then 'settled' else 'open' end,
             settled_at = case when settled + take >= amount then now() else null end
       where id = d.id;
      net := net - take;
      ded := ded + take;
    end loop;
    note_txt := 'Job total Rs ' || base || case when disc > 0 then ', offer discount Rs ' || disc || ' (paid by Fixeaze)' else '' end || ', Fixeaze commission Rs ' || comm
                || case when ded > 0 then ', earlier cash commission deducted Rs ' || ded else '' end || '.';
    insert into public.technician_payments
      (booking_id, technician_id, amount, status, gross, commission, deducted, method, note, paid_at)
    values (b.id, b.technician_id, net, case when net <= 0 then 'paid' else 'pending' end,
            base, comm, ded, 'qr', note_txt, case when net <= 0 then now() else null end)
    on conflict (booking_id) do nothing;
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (b.technician_id, 'payment', 'Job completed (paid by QR)',
            'Rs ' || net || ' will be paid to you by Fixeaze. ' || note_txt);
  else
    -- Technician holds the cash: they owe Fixeaze the commission minus the offer discount Fixeaze covers
    if comm - disc > 0 then
      insert into public.cash_dues (technician_id, booking_id, amount, note)
      values (b.technician_id, b.id, comm - disc, 'Cash job, total Rs ' || base)
      on conflict (booking_id) do nothing;
    end if;
    note_txt := 'Customer paid Rs ' || gross || ' in cash' || case when disc > 0 then ' after an offer of Rs ' || disc else '' end
                || '. Fixeaze commission Rs ' || comm
                || case when comm - disc > 0 then ' (Rs ' || (comm - disc) || ' will be deducted from your next payment).'
                        when disc - comm > 0 then '. Fixeaze will pay you Rs ' || (disc - comm) || ' for the offer.'
                        else '.' end;
    insert into public.technician_payments
      (booking_id, technician_id, amount, status, gross, commission, deducted, method, note, paid_at)
    values (b.id, b.technician_id, greatest(disc - comm, 0),
            case when disc - comm > 0 then 'pending' else 'paid' end,
            base, comm, 0, 'cash', note_txt, case when disc - comm > 0 then null else now() end)
    on conflict (booking_id) do nothing;
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (b.technician_id, 'payment', 'Job completed (cash)', note_txt);
  end if;

  perform set_config('fixeaze.rpc', '1', true);
  update public.bookings
     set status = 'completed', job_stage = 'done', finished_at = now(),
         gross_total = gross, commission_pct = pct, commission_amount = comm,
         tech_amount = base - comm, completion_photos = after_photos
   where id = p_booking;
  perform set_config('fixeaze.rpc', '', true);
  delete from public.job_otps where booking_id = p_booking;
  return true;
end $$;
revoke execute on function public.job_finish(uuid, text) from public, anon;
grant execute on function public.job_finish(uuid, text) to authenticated;
