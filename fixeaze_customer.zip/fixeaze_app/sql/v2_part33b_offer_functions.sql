-- Part 33b: check, apply and remove an offer (customer, at checkout)
create or replace function public.offer_problem(o public.offers, p_customer uuid, p_amount numeric)
returns text language plpgsql stable security definer set search_path = public as $$
declare today date := (now() at time zone 'Asia/Kolkata')::date; used int;
begin
  if not o.active then return 'This offer is not active'; end if;
  if today < o.date_from then return 'This offer has not started yet'; end if;
  if today > o.date_to then return 'This offer has expired'; end if;
  if p_amount < o.min_order then return 'Minimum order Rs ' || o.min_order; end if;
  if o.total_limit is not null then
    select count(*) into used from public.offer_redemptions where offer_id = o.id;
    if used >= o.total_limit then return 'This offer is fully used'; end if;
  end if;
  select count(*) into used from public.offer_redemptions where offer_id = o.id and customer_id = p_customer;
  if used >= o.per_customer then return 'You have already used this offer'; end if;
  if o.first_booking_only and exists (
       select 1 from public.bookings where customer_id = p_customer and status = 'completed') then
    return 'Only for your first booking';
  end if;
  return null;
end $$;
revoke execute on function public.offer_problem(public.offers, uuid, numeric) from public, anon, authenticated;

create or replace function public.offer_amount(o public.offers, p_amount numeric)
returns numeric language sql immutable as $$
  select least(p_amount, round(case
    when o.discount_type = 'percent' then least(p_amount * o.value / 100, coalesce(o.max_discount, 1e9))
    else o.value end, 2));
$$;
revoke execute on function public.offer_amount(public.offers, numeric) from public, anon, authenticated;

create or replace function public.my_offers(p_booking uuid)
returns table (code text, title text, discount_type text, value numeric, max_discount numeric,
               min_order numeric, date_to date, ok boolean, why text, discount numeric)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare b public.bookings; o public.offers; amt numeric; prob text;
begin
  select * into b from public.bookings where id = p_booking;
  if not found or b.customer_id is distinct from auth.uid() then raise exception 'Not allowed'; end if;
  amt := coalesce(b.gross_total, 0) + coalesce(b.discount_amount, 0);
  for o in select * from public.offers where active
            and (now() at time zone 'Asia/Kolkata')::date between date_from and date_to
            order by created_at desc limit 20 loop
    prob := public.offer_problem(o, b.customer_id, amt);
    code := o.code; title := o.title; discount_type := o.discount_type; value := o.value;
    max_discount := o.max_discount; min_order := o.min_order; date_to := o.date_to;
    ok := prob is null; why := prob; discount := case when prob is null then public.offer_amount(o, amt) else 0 end;
    return next;
  end loop;
end $$;
grant execute on function public.my_offers(uuid) to authenticated;

create or replace function public.apply_offer(p_booking uuid, p_code text)
returns numeric language plpgsql security definer set search_path = public as $$
declare b public.bookings; o public.offers; prob text; d numeric;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.customer_id is distinct from auth.uid() or b.job_stage is distinct from 'payment_due' then
    raise exception 'You can add an offer when it is time to pay';
  end if;
  if coalesce(b.discount_amount, 0) > 0 then raise exception 'An offer is already applied'; end if;
  select * into o from public.offers where upper(code) = upper(trim(coalesce(p_code, '')));
  if not found then raise exception 'This code is not valid'; end if;
  prob := public.offer_problem(o, b.customer_id, coalesce(b.gross_total, 0));
  if prob is not null then raise exception '%', prob; end if;
  d := public.offer_amount(o, coalesce(b.gross_total, 0));
  if d <= 0 then raise exception 'This offer gives no discount on this booking'; end if;
  perform set_config('fixeaze.rpc', '1', true);
  update public.bookings set gross_total = gross_total - d, discount_amount = d, offer_code = o.code
   where id = p_booking;
  perform set_config('fixeaze.rpc', '', true);
  insert into public.offer_redemptions (offer_id, customer_id, booking_id, discount)
  values (o.id, b.customer_id, b.id, d);
  return d;
end $$;
grant execute on function public.apply_offer(uuid, text) to authenticated;

create or replace function public.remove_offer(p_booking uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.customer_id is distinct from auth.uid() or b.job_stage is distinct from 'payment_due' then
    raise exception 'Not allowed';
  end if;
  if coalesce(b.discount_amount, 0) <= 0 then return; end if;
  perform set_config('fixeaze.rpc', '1', true);
  update public.bookings set gross_total = gross_total + discount_amount, discount_amount = 0, offer_code = null
   where id = p_booking;
  perform set_config('fixeaze.rpc', '', true);
  delete from public.offer_redemptions where booking_id = p_booking;
end $$;
grant execute on function public.remove_offer(uuid) to authenticated;
