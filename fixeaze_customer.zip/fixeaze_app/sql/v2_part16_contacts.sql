-- Part 16: Contacts & leads (technicians / customers to call), call history, outcome tags.
-- Safe to run more than once. Admin only.

create table if not exists public.contacts (
  id uuid primary key default gen_random_uuid(),
  kind text not null default 'technician' check (kind in ('technician','customer')),
  name text not null,
  phone text not null,
  address text,
  city text,
  pincode text,
  added_by uuid references public.profiles(id) on delete set null,
  status text not null default 'new'
    check (status in ('new','interested','not_interested','follow_up','meeting')),
  last_called_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists contacts_phone on public.contacts(phone);
create index if not exists contacts_pincode on public.contacts(pincode);

create table if not exists public.contact_calls (
  id uuid primary key default gen_random_uuid(),
  contact_id uuid not null references public.contacts(id) on delete cascade,
  called_by uuid references public.profiles(id) on delete set null,
  outcome text not null check (outcome in ('interested','not_interested','follow_up','meeting','no_answer','note')),
  note text,
  created_at timestamptz not null default now()
);
create index if not exists contact_calls_contact on public.contact_calls(contact_id, created_at desc);

alter table public.contacts enable row level security;
alter table public.contact_calls enable row level security;

drop policy if exists "contacts admin" on public.contacts;
create policy "contacts admin" on public.contacts for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
drop policy if exists "contact calls admin" on public.contact_calls;
create policy "contact calls admin" on public.contact_calls for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.contacts to authenticated;
grant select, insert, update, delete on public.contact_calls to authenticated;

-- Log a call (or just a note) and update the contact's tag in one step
create or replace function public.contact_log_call(p_contact uuid, p_outcome text, p_note text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  if p_outcome not in ('interested','not_interested','follow_up','meeting','no_answer','note') then
    raise exception 'Choose an outcome';
  end if;
  if not exists (select 1 from public.contacts where id = p_contact) then
    raise exception 'Contact not found';
  end if;
  insert into public.contact_calls (contact_id, called_by, outcome, note)
  values (p_contact, auth.uid(), p_outcome, nullif(trim(coalesce(p_note, '')), ''));
  update public.contacts
     set status = case when p_outcome in ('interested','not_interested','follow_up','meeting')
                       then p_outcome else status end,
         last_called_at = case when p_outcome = 'note' then last_called_at else now() end,
         updated_at = now()
   where id = p_contact;
end $$;
grant execute on function public.contact_log_call(uuid, text, text) to authenticated;
