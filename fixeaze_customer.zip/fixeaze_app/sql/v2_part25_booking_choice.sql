-- PIECE A: unique booking ids + preferred technician
create sequence if not exists public.booking_no_seq start 1001;
alter table public.bookings add column if not exists booking_no text;
alter table public.bookings add column if not exists preferred_technician_id uuid;
alter table public.bookings alter column booking_no
  set default ('FX' || lpad(nextval('public.booking_no_seq')::text, 6, '0'));
alter table public.bookings disable trigger user;
update public.bookings b set booking_no = x.n
from (select id, 'FX' || lpad(nextval('public.booking_no_seq')::text, 6, '0') as n
      from (select id from public.bookings where booking_no is null order by created_at) o) x
where b.id = x.id;
alter table public.bookings enable trigger user;
create unique index if not exists bookings_booking_no_key on public.bookings (booking_no);

-- PIECE B: technician list for the customer
create or replace function public.technicians_list(p_lat double precision, p_lng double precision, p_service uuid default null, p_km double precision default 15)
returns table (id uuid, name text, rate numeric, rating numeric, jobs_done int, experience int, avatar_url text, lat double precision, lng double precision, km double precision)
language sql stable security definer set search_path = public as $$
  select p.id, coalesce(nullif(tp.name,''), p.name)::text, tp.hourly_rate, tp.rating::numeric, tp.jobs_done::int,
         coalesce(tp.experience_years,0)::int, p.avatar_url, p.lat, p.lng,
         public.km_between(p.lat, p.lng, p_lat, p_lng)
  from public.profiles p
  join public.technician_profiles tp on tp.id = p.id
  where p.role = 'technician' and p.approved = true and tp.paused = false
    and p.lat is not null and p.lng is not null
    and public.km_between(p.lat, p.lng, p_lat, p_lng) <= p_km
    and not exists (select 1 from public.technician_schedule s
                    where s.technician_id = p.id and s.kind = 'leave'
                      and s.day = (now() at time zone 'Asia/Kolkata')::date)
    and (p_service is null or exists (
      select 1 from public.technician_services ts
      where ts.technician_id = p.id and ts.service_id = p_service))
  order by public.km_between(p.lat, p.lng, p_lat, p_lng)
  limit 30;
$$;
grant execute on function public.technicians_list(double precision, double precision, uuid, double precision) to anon, authenticated;
