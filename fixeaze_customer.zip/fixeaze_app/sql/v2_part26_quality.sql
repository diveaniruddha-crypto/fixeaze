-- PIECE A: cancellations
create table if not exists public.cancellations (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings(id) on delete cascade,
  by_user uuid, by_role text, tech_id uuid, customer_id uuid,
  reason text not null, note text,
  created_at timestamptz not null default now());
alter table public.cancellations enable row level security;
drop policy if exists "cancel admin" on public.cancellations;
create policy "cancel admin" on public.cancellations for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
drop policy if exists "cancel own" on public.cancellations;
create policy "cancel own" on public.cancellations for select to authenticated
  using (by_user = auth.uid());
grant select on public.cancellations to authenticated;

create or replace function public.cancel_booking(p_booking uuid, p_reason text, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare b record; r text; n int; nm text;
begin
  if coalesce(trim(p_reason), '') = '' then raise exception 'Please choose a reason'; end if;
  select * into b from public.bookings where id = p_booking for update;
  if not found then raise exception 'Booking not found'; end if;
  perform set_config('fixeaze.rpc', '1', true);
  if auth.uid() = b.customer_id then
    if b.status not in ('pending', 'accepted') or b.job_stage is not null then
      raise exception 'You can only cancel before the technician arrives';
    end if;
    update public.bookings set status = 'cancelled' where id = b.id;
    r := 'customer';
  elsif auth.uid() = b.technician_id then
    if b.status <> 'accepted' or coalesce(b.job_stage, 'assigned') not in ('assigned', 'arrived') then
      raise exception 'This job can no longer be cancelled';
    end if;
    update public.bookings set status = 'pending', technician_id = null, job_stage = null where id = b.id;
    r := 'technician';
  else
    raise exception 'Not allowed';
  end if;
  insert into public.cancellations (booking_id, by_user, by_role, tech_id, customer_id, reason, note)
  values (b.id, auth.uid(), r, b.technician_id, b.customer_id, trim(p_reason), nullif(trim(coalesce(p_note, '')), ''));
  select name into nm from public.profiles where id = auth.uid();
  perform public.push_admins('cancel', 'Booking cancelled by ' || r,
    coalesce(nm, r) || ': ' || trim(p_reason));
  if r = 'technician' then
    select count(*) into n from public.cancellations
     where by_user = auth.uid() and created_at > now() - interval '30 days';
    if n >= 3 then
      perform public.push_admins('cancel', 'Technician cancelling a lot',
        coalesce(nm, 'A technician') || ' cancelled ' || n || ' jobs in 30 days.');
    end if;
  end if;
end $$;
grant execute on function public.cancel_booking(uuid, text, text) to authenticated;
-- PIECE B: ratings both ways, reversible
alter table public.reviews add column if not exists reversed boolean not null default false;
alter table public.reviews add column if not exists reversed_note text;
alter table public.profiles add column if not exists cust_rating numeric default 0;
alter table public.profiles add column if not exists cust_rating_count int default 0;

create table if not exists public.customer_reviews (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings(id) on delete cascade,
  technician_id uuid not null, customer_id uuid not null,
  rating int not null check (rating between 1 and 5),
  comment text, reversed boolean not null default false, reversed_note text,
  created_at timestamptz not null default now());
alter table public.customer_reviews enable row level security;
drop policy if exists "cr admin" on public.customer_reviews;
create policy "cr admin" on public.customer_reviews for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
drop policy if exists "cr read" on public.customer_reviews;
create policy "cr read" on public.customer_reviews for select to authenticated
  using (technician_id = auth.uid() or customer_id = auth.uid());
drop policy if exists "cr insert" on public.customer_reviews;
create policy "cr insert" on public.customer_reviews for insert to authenticated
  with check (technician_id = auth.uid() and exists (
    select 1 from public.bookings b where b.id = booking_id
      and b.technician_id = auth.uid() and b.customer_id = customer_reviews.customer_id
      and b.status = 'completed'));
grant select, insert on public.customer_reviews to authenticated;
-- PIECE C: rating averages + low rating alert
create or replace function public.recalc_ratings()
returns trigger language plpgsql security definer set search_path = public as $$
declare tid uuid; cid uuid; avg_r numeric; cnt int; old_r numeric; nm text;
begin
  perform set_config('fixeaze.rpc', '1', true);
  if tg_table_name = 'reviews' then
    tid := coalesce(new.technician_id, old.technician_id);
    select coalesce(round(avg(rating)::numeric, 2), 0), count(*) into avg_r, cnt
      from public.reviews where technician_id = tid and reversed = false;
    select rating into old_r from public.technician_profiles where id = tid;
    update public.technician_profiles set rating = avg_r where id = tid;
    if cnt > 0 and avg_r < 3 and coalesce(old_r, 5) >= 3 then
      select name into nm from public.profiles where id = tid;
      perform public.push_admins('rating', 'Low technician rating',
        coalesce(nm, 'A technician') || ' is now rated ' || avg_r || ' (' || cnt || ' reviews).');
    end if;
  else
    cid := coalesce(new.customer_id, old.customer_id);
    select coalesce(round(avg(rating)::numeric, 2), 0), count(*) into avg_r, cnt
      from public.customer_reviews where customer_id = cid and reversed = false;
    update public.profiles set cust_rating = avg_r, cust_rating_count = cnt where id = cid;
  end if;
  return null;
end $$;
drop trigger if exists zz_recalc_reviews on public.reviews;
create trigger zz_recalc_reviews after insert or update or delete on public.reviews
  for each row execute function public.recalc_ratings();
drop trigger if exists zz_recalc_cust on public.customer_reviews;
create trigger zz_recalc_cust after insert or update or delete on public.customer_reviews
  for each row execute function public.recalc_ratings();
-- PIECE D: admin reverse rating + temporary block
create or replace function public.admin_reverse_review(p_kind text, p_id uuid, p_reverse boolean, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  if p_kind = 'technician' then
    update public.reviews set reversed = p_reverse, reversed_note = nullif(trim(coalesce(p_note, '')), '') where id = p_id;
  else
    update public.customer_reviews set reversed = p_reverse, reversed_note = nullif(trim(coalesce(p_note, '')), '') where id = p_id;
  end if;
end $$;
grant execute on function public.admin_reverse_review(text, uuid, boolean, text) to authenticated;

alter table public.profiles add column if not exists blocked_until timestamptz;
alter table public.profiles add column if not exists blocked_reason text;

create or replace function public.admin_block_user(p_user uuid, p_days int, p_reason text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  perform set_config('fixeaze.rpc', '1', true);
  if coalesce(p_days, 0) <= 0 then
    update public.profiles set blocked_until = null, blocked_reason = null where id = p_user;
  else
    update public.profiles set blocked_until = now() + make_interval(days => p_days),
           blocked_reason = nullif(trim(coalesce(p_reason, '')), '') where id = p_user;
  end if;
end $$;
grant execute on function public.admin_block_user(uuid, int, text) to authenticated;
-- PIECE E: blocked users cannot book / accept, and are hidden from the list
create or replace function public.block_check()
returns trigger language plpgsql security definer set search_path = public as $$
declare u uuid; bu timestamptz;
begin
  if tg_op = 'INSERT' then u := new.customer_id;
  elsif new.technician_id is not null and new.technician_id is distinct from old.technician_id then u := new.technician_id;
  else return new; end if;
  select blocked_until into bu from public.profiles where id = u;
  if bu is not null and bu > now() then
    raise exception 'Your account is blocked until %. Please contact Fixeaze support.', to_char(bu at time zone 'Asia/Kolkata', 'DD Mon YYYY');
  end if;
  return new;
end $$;
drop trigger if exists zz_block_check on public.bookings;
create trigger zz_block_check before insert or update on public.bookings
  for each row execute function public.block_check();

create or replace function public.technicians_list(p_lat double precision, p_lng double precision, p_service uuid default null, p_km double precision default 15)
returns table (id uuid, name text, rate numeric, rating numeric, jobs_done int, experience int, avatar_url text, lat double precision, lng double precision, km double precision)
language sql stable security definer set search_path = public as $$
  select p.id, coalesce(nullif(tp.name,''), p.name)::text, tp.hourly_rate, tp.rating::numeric, tp.jobs_done::int,
         coalesce(tp.experience_years,0)::int, p.avatar_url, p.lat, p.lng,
         public.km_between(p.lat, p.lng, p_lat, p_lng)
  from public.profiles p
  join public.technician_profiles tp on tp.id = p.id
  where p.role = 'technician' and p.approved = true and tp.paused = false
    and (p.blocked_until is null or p.blocked_until < now())
    and p.lat is not null and p.lng is not null
    and public.km_between(p.lat, p.lng, p_lat, p_lng) <= p_km
    and not exists (select 1 from public.technician_schedule s
                    where s.technician_id = p.id and s.kind = 'leave'
                      and s.day = (now() at time zone 'Asia/Kolkata')::date)
    and (p_service is null or exists (
      select 1 from public.technician_services ts
      where ts.technician_id = p.id and ts.service_id = p_service))
  order by public.km_between(p.lat, p.lng, p_lat, p_lng)
  limit 30;
$$;
