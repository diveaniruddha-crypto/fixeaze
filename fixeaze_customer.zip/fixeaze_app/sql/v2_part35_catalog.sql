-- Part 35: catalog (service > product > service type) and technician charges
alter table public.services add column if not exists description text;
alter table public.services add column if not exists image_url text;

create table if not exists public.catalog_products (
  id uuid primary key default gen_random_uuid(),
  service_id uuid not null references public.services(id) on delete cascade,
  name text not null,
  description text,
  image_url text,
  sort int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now());
create index if not exists catalog_products_service_idx on public.catalog_products (service_id);

create table if not exists public.product_services (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.catalog_products(id) on delete cascade,
  name text not null,
  description text,
  image_url text,
  sort int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now());
create index if not exists product_services_product_idx on public.product_services (product_id);

create table if not exists public.technician_prices (
  technician_id uuid not null references public.profiles(id) on delete cascade,
  item_id uuid not null references public.product_services(id) on delete cascade,
  price numeric(10,2),
  enabled boolean not null default true,
  off_reason text,
  off_note text,
  updated_at timestamptz not null default now(),
  primary key (technician_id, item_id),
  check ((enabled and price is not null and price > 0) or (not enabled and off_reason is not null)));
create index if not exists technician_prices_item_idx on public.technician_prices (item_id) where enabled;

alter table public.catalog_products enable row level security;
alter table public.product_services enable row level security;
alter table public.technician_prices enable row level security;

drop policy if exists "products read" on public.catalog_products;
create policy "products read" on public.catalog_products for select to anon, authenticated
  using (active or public.is_admin());
drop policy if exists "products admin" on public.catalog_products;
create policy "products admin" on public.catalog_products for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "pservices read" on public.product_services;
create policy "pservices read" on public.product_services for select to anon, authenticated
  using (active or public.is_admin());
drop policy if exists "pservices admin" on public.product_services;
create policy "pservices admin" on public.product_services for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "prices read" on public.technician_prices;
create policy "prices read" on public.technician_prices for select to authenticated
  using (technician_id = auth.uid() or public.is_admin());
drop policy if exists "prices write" on public.technician_prices;
create policy "prices write" on public.technician_prices for all to authenticated
  using ((technician_id = auth.uid() and public.is_technician_role()) or public.is_admin())
  with check ((technician_id = auth.uid() and public.is_technician_role()) or public.is_admin());

grant select on public.catalog_products, public.product_services to anon, authenticated;
grant insert, update, delete on public.catalog_products, public.product_services to authenticated;
grant select, insert, update, delete on public.technician_prices to authenticated;
