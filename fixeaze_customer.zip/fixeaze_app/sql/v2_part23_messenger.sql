-- Part 23: messenger-style admin chat, profile pictures, technician -> Fixeaze Support chat.
-- Safe to run more than once. Needs parts 15, 17 and 18.

alter table public.profiles add column if not exists avatar_url text;

create or replace function public.set_my_avatar(p_url text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform set_config('fixeaze.rpc', '1', true);
  update public.profiles set avatar_url = nullif(trim(coalesce(p_url, '')), '') where id = auth.uid();
end $$;
grant execute on function public.set_my_avatar(text) to authenticated;

create table if not exists public.tech_chat (
  id uuid primary key default gen_random_uuid(),
  technician_id uuid not null references public.profiles(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  sender_role text not null check (sender_role in ('technician', 'admin')),
  body text not null,
  created_at timestamptz not null default now()
);
create index if not exists tech_chat_thread on public.tech_chat(technician_id, created_at desc);
alter table public.tech_chat enable row level security;

drop policy if exists "tchat read" on public.tech_chat;
create policy "tchat read" on public.tech_chat for select to authenticated
  using (technician_id = auth.uid() or public.is_admin());

drop policy if exists "tchat insert user" on public.tech_chat;
create policy "tchat insert user" on public.tech_chat for insert to authenticated
  with check (sender_role = 'technician' and sender_id = auth.uid() and technician_id = auth.uid()
              and not public.is_admin());

drop policy if exists "tchat insert admin" on public.tech_chat;
create policy "tchat insert admin" on public.tech_chat for insert to authenticated
  with check (sender_role = 'admin' and sender_id = auth.uid() and public.is_admin());

grant select, insert on public.tech_chat to authenticated;

create table if not exists public.chat_reads (
  user_id uuid not null references public.profiles(id) on delete cascade,
  thread text not null,
  read_at timestamptz not null default now(),
  primary key (user_id, thread)
);
alter table public.chat_reads enable row level security;
drop policy if exists "reads own" on public.chat_reads;
create policy "reads own" on public.chat_reads for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
grant select, insert, update on public.chat_reads to authenticated;

create or replace function public.trg_tech_chat() returns trigger
language plpgsql security definer set search_path = public as $$
declare n text;
begin
  if new.sender_role = 'technician' then
    select name into n from public.profiles where id = new.sender_id;
    perform public.push_admins('chat', coalesce(n, 'Technician') || ' (support)', new.body);
  else
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (new.technician_id, 'support', 'Fixeaze Support', left(new.body, 200));
  end if;
  return new;
exception when others then
  return new;
end $$;
drop trigger if exists trg_tech_chat on public.tech_chat;
create trigger trg_tech_chat after insert on public.tech_chat
  for each row execute function public.trg_tech_chat();
