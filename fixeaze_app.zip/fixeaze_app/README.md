# Fixeaze – Customer & Technician app (Flutter Web)

One app, two roles. After login, customers see **Services / My bookings / Profile**,
approved technicians see **Open jobs / My jobs / Profile**.
Backend: Supabase (login + database). Images: Cloudinary.

## 1. Run it on your computer
1. Install Flutter: https://docs.flutter.dev/get-started/install
2. Create a fresh web project, then copy this app's files into it:
   ```
   flutter create fixeaze_app --platforms=web
   ```
   Copy these from this folder into the new `fixeaze_app` folder (replace when asked):
   - `lib/` (whole folder)
   - `assets/` (whole folder)
   - `pubspec.yaml`
   Then delete `test/widget_test.dart` (it belongs to the sample app).
3. Run:
   ```
   cd fixeaze_app
   flutter pub get
   flutter run -d chrome
   ```

## 2. Supabase settings (one time)
- **Authentication > Sign In / Providers > Email**: while testing, turn **Confirm email OFF**
  so new accounts can log in immediately. Turn it back ON before launch if you want email verification.
- **Make yourself admin**: sign up once in the app, then in **SQL Editor** run
  (replace the email):
  ```sql
  update public.profiles set role = 'admin', approved = true
  where email = 'your-admin-email@example.com';
  ```
- **Approve a technician**: **Table Editor > profiles**, find the technician, set `approved` to `true`
  (the Admin site will do this with a button later).

## 3. Test checklist
1. Sign up as **Customer** > pick a service > book (add a photo to test Cloudinary).
2. Sign up as **Technician** (use a second browser/incognito) > shows "Waiting for approval".
3. Approve that technician in Supabase (step above) > tap "Check status".
4. Technician: **Open jobs > Accept job > My jobs > Start job > Mark completed**.
5. Customer: **My bookings** shows the progress, then **Rate technician** once completed.

## 4. Put it online (free options)
```
flutter build web --release
```
Upload the `build/web` folder to Firebase Hosting, Netlify, Cloudflare Pages or Vercel.
After you have your live address, add it in Supabase: **Authentication > URL Configuration > Site URL**.

## 5. Branding
Replace `web/favicon.png` and the files in `web/icons/` with your Fixeaze logo
(`assets/logo.png` is already used inside the app).

## 6. Troubleshooting
- **"Invalid JWT" / "Invalid API key"**: run `flutter pub upgrade`. If it still happens, use the
  *legacy anon key* (starts with `eyJ`) from Supabase > Project Settings > API Keys and put it in
  `lib/config.dart`.
- **Image upload fails**: in Cloudinary > Settings > Upload, make sure the preset `ml_default`
  is set to **Unsigned**.
- **"permission denied" / "row-level security"**: the SQL from `fixeaze_schema.sql` was not fully run.

## Known limits (good next steps)
- The booking price shown is the service's starting price; the final price is set by the admin.
- Technicians can see the address of open jobs before accepting.
- Customers see the technician's name and rating, not phone number.
- Payments, push notifications and the Admin site are not included yet.
