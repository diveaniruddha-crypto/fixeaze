import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../widgets/common.dart';

class OpenJobsTab extends StatefulWidget {
  final VoidCallback onAccepted;
  const OpenJobsTab({super.key, required this.onAccepted});

  @override
  State<OpenJobsTab> createState() => _OpenJobsTabState();
}

class _OpenJobsTabState extends State<OpenJobsTab> {
  late Future<List<Map<String, dynamic>>> _future;
  String? _accepting; // booking id currently being accepted

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  void _refresh() => setState(() => _future = _load());

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await supabase
        .from('bookings')
        .select('*, services(name, base_price)')
        .eq('status', 'pending')
        .isFilter('technician_id', null)
        .order('scheduled_at', ascending: true);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> _accept(Map<String, dynamic> b) async {
    setState(() => _accepting = b['id'] as String);
    try {
      final res = await supabase
          .from('bookings')
          .update({
            'status': 'accepted',
            'technician_id': supabase.auth.currentUser!.id,
          })
          .eq('id', b['id'])
          .eq('status', 'pending')
          .isFilter('technician_id', null)
          .select();

      if (!mounted) return;
      if (res.isEmpty) {
        snack(context, 'Sorry, another technician already took this job.', error: true);
        _refresh();
      } else {
        snack(context, 'Job accepted! Find it under My jobs.');
        widget.onAccepted();
      }
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _accepting = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return ErrorState(error: snap.error!, onRetry: _refresh);
        }
        final jobs = snap.data!;
        if (jobs.isEmpty) {
          return RefreshIndicator(
            onRefresh: () async {
              _refresh();
              await _future;
            },
            child: ListView(
              children: const [
                SizedBox(height: 120),
                EmptyState(
                  icon: Icons.work_off,
                  text: 'No open jobs right now.\nPull down to refresh.',
                ),
              ],
            ),
          );
        }
        return RefreshIndicator(
          onRefresh: () async {
            _refresh();
            await _future;
          },
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: jobs.length,
            itemBuilder: (context, i) {
              final b = jobs[i];
              final service = b['services'] as Map<String, dynamic>?;
              final photos = List<String>.from(b['photos'] ?? const []);
              final busy = _accepting == b['id'];
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                elevation: 1,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(serviceIcon((service?['name'] ?? '').toString()),
                              color: Colors.teal),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text((service?['name'] ?? 'Service').toString(),
                                style: const TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.bold)),
                          ),
                          if (service?['base_price'] != null)
                            Text(money(service!['base_price']),
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600, color: Colors.teal)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(children: [
                        const Icon(Icons.event, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text(fmtDate(b['scheduled_at']))),
                      ]),
                      const SizedBox(height: 4),
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Icon(Icons.location_on, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text((b['address'] ?? '').toString())),
                      ]),
                      if ((b['notes'] ?? '').toString().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text('"${b['notes']}"',
                            style: const TextStyle(
                                fontStyle: FontStyle.italic, color: Colors.black54)),
                      ],
                      if (photos.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        PhotoStrip(urls: photos),
                      ],
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: busy ? null : () => _accept(b),
                          icon: busy
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2, color: Colors.white))
                              : const Icon(Icons.check),
                          label: const Text('Accept job'),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
