import 'package:flutter/material.dart';

import '../../config.dart';
import '../../widgets/common.dart';

class _PayData {
  final List<Map<String, dynamic>> payments;
  final List<Map<String, dynamic>> notes;
  final Set<String> unreadIds;
  _PayData(this.payments, this.notes, this.unreadIds);
}

/// Shows what Fixeaze owes / has paid the technician for each booking,
/// plus payment updates sent by Fixeaze.
class PaymentsTab extends StatefulWidget {
  const PaymentsTab({super.key});

  @override
  State<PaymentsTab> createState() => _PaymentsTabState();
}

class _PaymentsTabState extends State<PaymentsTab> {
  late Future<_PayData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  void _refresh() => setState(() => _future = _load());

  Future<_PayData> _load() async {
    final uid = supabase.auth.currentUser!.id;
    final pay = await supabase
        .from('technician_payments')
        .select('*, bookings(scheduled_at, services(name))')
        .eq('technician_id', uid)
        .order('created_at', ascending: false);
    final notes = await supabase
        .from('technician_notifications')
        .select()
        .eq('technician_id', uid)
        .order('created_at', ascending: false)
        .limit(30);

    final noteList = List<Map<String, dynamic>>.from(notes);
    final unread = noteList
        .where((n) => n['read'] != true)
        .map((n) => n['id'].toString())
        .toSet();
    if (unread.isNotEmpty) {
      // Mark as read in the background; they stay highlighted on this screen.
      supabase
          .from('technician_notifications')
          .update({'read': true})
          .eq('technician_id', uid)
          .eq('read', false)
          .then((_) {}, onError: (_) {});
    }
    return _PayData(List<Map<String, dynamic>>.from(pay), noteList, unread);
  }

  Map<String, dynamic>? _asMap(dynamic v) {
    if (v is Map) return Map<String, dynamic>.from(v);
    if (v is List && v.isNotEmpty && v.first is Map) {
      return Map<String, dynamic>.from(v.first as Map);
    }
    return null;
  }

  static const _colors = {
    'pending': Colors.orange,
    'processing': Colors.blue,
    'paid': Colors.green,
    'failed': Colors.red,
  };
  static const _labels = {
    'pending': 'Pending',
    'processing': 'Processing',
    'paid': 'Paid',
    'failed': 'Failed',
  };

  num _sum(List<Map<String, dynamic>> list, bool Function(String) test) {
    num total = 0;
    for (final p in list) {
      if (test((p['status'] ?? '').toString())) {
        total += num.tryParse(p['amount'].toString()) ?? 0;
      }
    }
    return total;
  }

  Widget _summary(String label, num amount, Color color, IconData icon) {
    return Expanded(
      child: Card(
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: color),
              const SizedBox(height: 6),
              Text(money(amount),
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              Text(label, style: const TextStyle(color: Colors.black54)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_PayData>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) return ErrorState(error: snap.error!, onRetry: _refresh);
        final data = snap.data!;
        final received = _sum(data.payments, (s) => s == 'paid');
        final waiting = _sum(data.payments, (s) => s == 'pending' || s == 'processing');

        return RefreshIndicator(
          onRefresh: () async {
            _refresh();
            await _future;
          },
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                children: [
                  _summary('Received', received, Colors.green, Icons.check_circle),
                  const SizedBox(width: 12),
                  _summary('On the way', waiting, Colors.orange, Icons.hourglass_bottom),
                ],
              ),
              if (data.notes.isNotEmpty) ...[
                const SizedBox(height: 20),
                const Text('Updates from Fixeaze',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...data.notes.take(8).map((n) {
                  final fresh = data.unreadIds.contains(n['id'].toString());
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    color: fresh ? Colors.teal.shade50 : Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(
                          color: fresh ? Colors.teal.shade200 : Colors.black12),
                    ),
                    child: ListTile(
                      leading: Icon(
                        n['kind'] == 'payment' ? Icons.currency_rupee : Icons.campaign,
                        color: Colors.teal,
                      ),
                      title: Text((n['title'] ?? '').toString(),
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(
                          '${(n['body'] ?? '').toString()}\n${fmtDate(n['created_at'])}'),
                      isThreeLine: true,
                    ),
                  );
                }),
              ],
              const SizedBox(height: 20),
              const Text('Payments for your bookings',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (data.payments.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 32),
                  child: EmptyState(
                    icon: Icons.account_balance_wallet_outlined,
                    text: 'No payments yet.\nOnce you complete a job, it shows up here.',
                  ),
                )
              else
                ...data.payments.map((p) {
                  final status = (p['status'] ?? 'pending').toString();
                  final color = _colors[status] ?? Colors.grey;
                  final booking = _asMap(p['bookings']);
                  final service = _asMap(booking?['services']);
                  final paidAt = p['paid_at'];
                  final ref = (p['reference'] ?? '').toString();
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  (service?['name'] ?? 'Booking').toString(),
                                  style: const TextStyle(
                                      fontSize: 16, fontWeight: FontWeight.w600),
                                ),
                              ),
                              Text(money(p['amount']),
                                  style: const TextStyle(
                                      fontSize: 18, fontWeight: FontWeight.bold)),
                            ],
                          ),
                          const SizedBox(height: 4),
                          if (booking?['scheduled_at'] != null)
                            Text('Job: ${fmtDate(booking!['scheduled_at'])}',
                                style: const TextStyle(color: Colors.black54)),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: color.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(_labels[status] ?? status,
                                    style: TextStyle(
                                        color: color,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12)),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  paidAt != null
                                      ? 'Paid on ${fmtDate(paidAt)}'
                                      : (status == 'pending'
                                          ? 'Waiting for Fixeaze'
                                          : ''),
                                  style: const TextStyle(
                                      fontSize: 12, color: Colors.black54),
                                ),
                              ),
                            ],
                          ),
                          if (ref.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Text('Reference: $ref',
                                style: const TextStyle(
                                    fontSize: 12, color: Colors.black54)),
                          ],
                        ],
                      ),
                    ),
                  );
                }),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }
}
