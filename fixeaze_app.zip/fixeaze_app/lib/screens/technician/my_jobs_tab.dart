import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../config.dart';
import '../../services/cloudinary_service.dart';
import '../../widgets/common.dart';
import '../chat_screen.dart';

class _JobsData {
  final List<Map<String, dynamic>> jobs;
  final Map<String, Map<String, dynamic>> customers; // by customer id
  _JobsData(this.jobs, this.customers);
}

class MyJobsTab extends StatefulWidget {
  const MyJobsTab({super.key});

  @override
  State<MyJobsTab> createState() => _MyJobsTabState();
}

class _MyJobsTabState extends State<MyJobsTab> {
  late Future<_JobsData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  void _refresh() => setState(() => _future = _load());

  Future<_JobsData> _load() async {
    final uid = supabase.auth.currentUser!.id;
    final rows = await supabase
        .from('bookings')
        .select('*, services(name, base_price)')
        .eq('technician_id', uid)
        .order('scheduled_at', ascending: false);
    final jobs = List<Map<String, dynamic>>.from(rows);

    final ids = jobs.map((j) => j['customer_id']).whereType<String>().toSet().toList();
    final customers = <String, Map<String, dynamic>>{};
    if (ids.isNotEmpty) {
      final crows =
          await supabase.from('profiles').select('id, name, phone').inFilter('id', ids);
      for (final r in crows) {
        customers[r['id'] as String] = Map<String, dynamic>.from(r);
      }
    }
    return _JobsData(jobs, customers);
  }

  Future<void> _start(Map<String, dynamic> job) async {
    try {
      await supabase.from('bookings').update({'status': 'in_progress'}).eq('id', job['id']);
      if (mounted) snack(context, 'Job started');
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    }
    if (mounted) _refresh();
  }

  Future<void> _complete(Map<String, dynamic> job) async {
    final photos = <String>[];
    bool uploading = false;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Mark job as completed'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Add photos of the finished work (optional).'),
                const SizedBox(height: 12),
                PhotoStrip(
                  urls: photos,
                  onRemove: (i) => setLocal(() => photos.removeAt(i)),
                ),
                if (photos.isNotEmpty) const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: (uploading || photos.length >= 4)
                      ? null
                      : () async {
                          setLocal(() => uploading = true);
                          try {
                            final url = await CloudinaryService.pickAndUpload();
                            if (url != null) setLocal(() => photos.add(url));
                          } catch (e) {
                            if (ctx.mounted) {
                              snack(ctx, 'Could not upload photo: $e', error: true);
                            }
                          }
                          setLocal(() => uploading = false);
                        },
                  icon: uploading
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.add_a_photo),
                  label: Text(uploading ? 'Uploading...' : 'Add photo'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false), child: const Text('Back')),
            FilledButton(
              onPressed: uploading ? null : () => Navigator.pop(ctx, true),
              child: const Text('Complete'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;

    try {
      await supabase.from('bookings').update({
        'status': 'completed',
        'completion_photos': photos,
      }).eq('id', job['id']);
      if (mounted) snack(context, 'Job completed. Great work!');
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    }
    if (mounted) _refresh();
  }

  Future<void> _open(Uri uri) async {
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted) {
      snack(context, 'Could not open that link', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_JobsData>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return ErrorState(error: snap.error!, onRetry: _refresh);
        }
        final data = snap.data!;
        if (data.jobs.isEmpty) {
          return const EmptyState(
            icon: Icons.assignment,
            text: 'You have no jobs yet.\nAccept one from the Open jobs tab.',
          );
        }
        return RefreshIndicator(
          onRefresh: () async {
            _refresh();
            await _future;
          },
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: data.jobs.length,
            itemBuilder: (context, i) {
              final job = data.jobs[i];
              final status = (job['status'] ?? '').toString();
              final service = job['services'] as Map<String, dynamic>?;
              final customer = data.customers[job['customer_id']];
              final phone = (customer?['phone'] ?? '').toString();
              final address = (job['address'] ?? '').toString();
              final photos = List<String>.from(job['photos'] ?? const []);

              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                elevation: 1,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text((service?['name'] ?? 'Service').toString(),
                                style: const TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.bold)),
                          ),
                          StatusChip(status),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(bookingTypeLabel(job),
                          style: TextStyle(
                              color: Colors.teal.shade700,
                              fontSize: 12,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.event, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text(fmtDate(job['scheduled_at']))),
                      ]),
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.person, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text((customer?['name'] ?? 'Customer').toString())),
                      ]),
                      const SizedBox(height: 4),
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Icon(Icons.location_on, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text(address)),
                      ]),
                      if ((job['notes'] ?? '').toString().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text('"${job['notes']}"',
                            style: const TextStyle(
                                fontStyle: FontStyle.italic, color: Colors.black54)),
                      ],
                      if (photos.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        PhotoStrip(urls: photos),
                      ],
                      if (status == 'accepted' || status == 'in_progress') ...[
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            if (phone.isNotEmpty)
                              OutlinedButton.icon(
                                onPressed: () => _open(Uri.parse('tel:$phone')),
                                icon: const Icon(Icons.call, size: 18),
                                label: const Text('Call'),
                              ),
                            OutlinedButton.icon(
                              onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ChatScreen(
                                    bookingId: job['id'] as String,
                                    title:
                                        'Chat with ${(customer?['name'] ?? 'customer').toString()}',
                                  ),
                                ),
                              ),
                              icon: const Icon(Icons.chat_bubble_outline, size: 18),
                              label: const Text('Chat'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _open(Uri.parse(
                                  'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(address)}')),
                              icon: const Icon(Icons.map, size: 18),
                              label: const Text('Map'),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          child: status == 'accepted'
                              ? FilledButton.icon(
                                  onPressed: () => _start(job),
                                  icon: const Icon(Icons.play_arrow),
                                  label: const Text('Start job'),
                                )
                              : FilledButton.icon(
                                  onPressed: () => _complete(job),
                                  icon: const Icon(Icons.done_all),
                                  label: const Text('Mark completed'),
                                ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
