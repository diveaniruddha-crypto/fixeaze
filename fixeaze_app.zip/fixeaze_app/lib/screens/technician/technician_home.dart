import 'package:flutter/material.dart';

import '../../config.dart';
import '../../widgets/common.dart';
import '../profile_tab.dart';
import 'my_jobs_tab.dart';
import 'open_jobs_tab.dart';

class TechnicianHome extends StatefulWidget {
  final Map<String, dynamic> profile;
  const TechnicianHome({super.key, required this.profile});

  @override
  State<TechnicianHome> createState() => _TechnicianHomeState();
}

class _TechnicianHomeState extends State<TechnicianHome> {
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    _ensurePublicProfile();
  }

  /// Creates the public technician row (shown to customers) the first time an
  /// approved technician opens the app. Does nothing if it already exists.
  Future<void> _ensurePublicProfile() async {
    try {
      await supabase.from('technician_profiles').upsert(
        {
          'id': supabase.auth.currentUser!.id,
          'name': widget.profile['name'],
          'photo_url': widget.profile['photo_url'],
        },
        onConflict: 'id',
        ignoreDuplicates: true,
      );
    } catch (_) {
      // not critical
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      OpenJobsTab(onAccepted: () => setState(() => _tab = 1)),
      const MyJobsTab(),
      const ProfileTab(isTechnician: true),
    ];

    return Scaffold(
      appBar: AppBar(title: const AppBarTitle(subtitle: 'Technician')),
      body: Constrained(child: pages[_tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.work_outline), label: 'Open jobs'),
          NavigationDestination(icon: Icon(Icons.assignment_turned_in), label: 'My jobs'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
