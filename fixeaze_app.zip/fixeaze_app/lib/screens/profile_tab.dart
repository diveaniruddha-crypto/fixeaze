import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../services/cloudinary_service.dart';
import '../widgets/common.dart';

/// Used by both customers and technicians.
class ProfileTab extends StatefulWidget {
  final bool isTechnician;
  const ProfileTab({super.key, required this.isTechnician});

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _bio = TextEditingController();
  final _skills = TextEditingController();
  final _experience = TextEditingController();

  String _email = '';
  String? _photo;
  bool _loading = true;
  bool _saving = false;
  bool _uploading = false;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [_name, _phone, _address, _bio, _skills, _experience]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final uid = supabase.auth.currentUser!.id;
      final p = await supabase.from('profiles').select().eq('id', uid).single();
      _name.text = (p['name'] ?? '').toString();
      _phone.text = (p['phone'] ?? '').toString();
      _address.text = (p['address'] ?? '').toString();
      _email = (p['email'] ?? supabase.auth.currentUser!.email ?? '').toString();
      _photo = p['photo_url'] as String?;

      if (widget.isTechnician) {
        final t = await supabase
            .from('technician_profiles')
            .select()
            .eq('id', uid)
            .maybeSingle();
        if (t != null) {
          _bio.text = (t['bio'] ?? '').toString();
          _skills.text = ((t['skills'] as List?) ?? const []).join(', ');
          _experience.text = '${t['experience_years'] ?? 0}';
        }
      }
    } catch (e) {
      _error = e;
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _changePhoto() async {
    setState(() => _uploading = true);
    try {
      final url = await CloudinaryService.pickAndUpload();
      if (url != null) setState(() => _photo = url);
    } catch (e) {
      if (mounted) snack(context, 'Could not upload photo: $e', error: true);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<void> _save() async {
    if (_name.text.trim().length < 2) {
      snack(context, 'Please enter your name', error: true);
      return;
    }
    setState(() => _saving = true);
    try {
      final uid = supabase.auth.currentUser!.id;
      await supabase.from('profiles').update({
        'name': _name.text.trim(),
        'phone': _phone.text.trim(),
        'address': _address.text.trim(),
        'photo_url': _photo,
      }).eq('id', uid);

      if (widget.isTechnician) {
        final skills = _skills.text
            .split(',')
            .map((s) => s.trim())
            .where((s) => s.isNotEmpty)
            .toList();
        await supabase.from('technician_profiles').update({
          'name': _name.text.trim(),
          'photo_url': _photo,
          'bio': _bio.text.trim(),
          'skills': skills,
          'experience_years': int.tryParse(_experience.text.trim()) ?? 0,
        }).eq('id', uid);
      }
      if (mounted) snack(context, 'Profile saved');
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Could not save: $e', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return ErrorState(error: _error!, onRetry: _load);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Center(
          child: Stack(
            children: [
              CircleAvatar(
                radius: 48,
                backgroundColor: Colors.teal.withOpacity(0.15),
                backgroundImage: _photo != null ? NetworkImage(_photo!) : null,
                child: _photo == null
                    ? const Icon(Icons.person, size: 48, color: Colors.teal)
                    : null,
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: InkWell(
                  onTap: _uploading ? null : _changePhoto,
                  child: CircleAvatar(
                    radius: 16,
                    backgroundColor: Theme.of(context).colorScheme.secondary,
                    child: _uploading
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.camera_alt, size: 16, color: Colors.black87),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Center(child: Text(_email, style: const TextStyle(color: Colors.black54))),
        const SizedBox(height: 20),
        TextField(
          controller: _name,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
              labelText: 'Full name', prefixIcon: Icon(Icons.badge)),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
              labelText: 'Phone number', prefixIcon: Icon(Icons.phone)),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _address,
          maxLines: 2,
          decoration: InputDecoration(
            labelText: widget.isTechnician ? 'Home / base address' : 'Default service address',
            prefixIcon: const Icon(Icons.location_on),
          ),
        ),
        if (widget.isTechnician) ...[
          const SizedBox(height: 12),
          TextField(
            controller: _skills,
            decoration: const InputDecoration(
              labelText: 'Skills (comma separated)',
              hintText: 'AC repair, Plumbing',
              prefixIcon: Icon(Icons.build),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _experience,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
                labelText: 'Years of experience', prefixIcon: Icon(Icons.timeline)),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _bio,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'About you (shown to customers)',
              alignLabelWithHint: true,
            ),
          ),
        ],
        const SizedBox(height: 20),
        FilledButton(
          onPressed: (_saving || _uploading) ? null : _save,
          child: _saving
              ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Text('Save changes'),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: () => supabase.auth.signOut(),
          icon: const Icon(Icons.logout),
          label: const Text('Sign out'),
        ),
        const SizedBox(height: 24),
      ],
    );
  }
}
