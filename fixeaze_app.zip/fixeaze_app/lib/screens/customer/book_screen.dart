import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../services/cloudinary_service.dart';
import '../../widgets/common.dart';

class BookScreen extends StatefulWidget {
  final Map<String, dynamic> service;
  const BookScreen({super.key, required this.service});

  @override
  State<BookScreen> createState() => _BookScreenState();
}

class _BookScreenState extends State<BookScreen> {
  final _form = GlobalKey<FormState>();
  final _address = TextEditingController();
  final _notes = TextEditingController();

  DateTime? _date;
  TimeOfDay? _time;
  final List<String> _photos = [];
  bool _uploading = false;
  bool _saving = false;

  static const _maxPhotos = 4;

  @override
  void initState() {
    super.initState();
    _prefillAddress();
  }

  @override
  void dispose() {
    _address.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _prefillAddress() async {
    try {
      final uid = supabase.auth.currentUser!.id;
      final p = await supabase.from('profiles').select('address').eq('id', uid).maybeSingle();
      final a = p?['address'] as String?;
      if (mounted && a != null && a.isNotEmpty && _address.text.isEmpty) {
        _address.text = a;
      }
    } catch (_) {
      // not important
    }
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: _date ?? now,
      firstDate: now,
      lastDate: now.add(const Duration(days: 90)),
    );
    if (d != null) setState(() => _date = d);
  }

  Future<void> _pickTime() async {
    final t = await showTimePicker(
      context: context,
      initialTime: _time ?? const TimeOfDay(hour: 10, minute: 0),
    );
    if (t != null) setState(() => _time = t);
  }

  Future<void> _addPhoto() async {
    if (_photos.length >= _maxPhotos) return;
    setState(() => _uploading = true);
    try {
      final url = await CloudinaryService.pickAndUpload();
      if (url != null) setState(() => _photos.add(url));
    } catch (e) {
      if (mounted) snack(context, 'Could not upload photo: $e', error: true);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    if (_date == null || _time == null) {
      snack(context, 'Please choose a date and time', error: true);
      return;
    }
    final when = DateTime(_date!.year, _date!.month, _date!.day, _time!.hour, _time!.minute);
    if (when.isBefore(DateTime.now())) {
      snack(context, 'Please choose a time in the future', error: true);
      return;
    }

    setState(() => _saving = true);
    try {
      await supabase.from('bookings').insert({
        'customer_id': supabase.auth.currentUser!.id,
        'service_id': widget.service['id'],
        'address': _address.text.trim(),
        'scheduled_at': when.toUtc().toIso8601String(),
        'notes': _notes.text.trim().isEmpty ? null : _notes.text.trim(),
        'photos': _photos,
        'status': 'pending',
      });
      if (!mounted) return;
      snack(context, 'Booking sent! A technician will accept it soon.');
      Navigator.pop(context, true);
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Could not create booking: $e', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final name = (widget.service['name'] ?? '').toString();
    return Scaffold(
      appBar: AppBar(title: Text('Book $name')),
      body: Constrained(
        maxWidth: 600,
        child: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (widget.service['base_price'] != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.amber.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Starting price: ${money(widget.service['base_price'])}. '
                    'The final amount is confirmed after the technician inspects the work.',
                    style: const TextStyle(fontSize: 13),
                  ),
                ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _address,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Service address',
                  prefixIcon: Icon(Icons.location_on),
                ),
                validator: (v) => (v == null || v.trim().length < 8)
                    ? 'Enter the full address'
                    : null,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickDate,
                      icon: const Icon(Icons.calendar_today, size: 18),
                      label: Text(_date == null
                          ? 'Pick date'
                          : DateFormat('d MMM y').format(_date!)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickTime,
                      icon: const Icon(Icons.access_time, size: 18),
                      label: Text(_time == null ? 'Pick time' : _time!.format(context)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _notes,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Describe the problem (optional)',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 16),
              Text('Photos (${_photos.length}/$_maxPhotos)',
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              PhotoStrip(
                urls: _photos,
                onRemove: (i) => setState(() => _photos.removeAt(i)),
              ),
              if (_photos.isNotEmpty) const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerLeft,
                child: OutlinedButton.icon(
                  onPressed: (_uploading || _photos.length >= _maxPhotos) ? null : _addPhoto,
                  icon: _uploading
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.add_a_photo),
                  label: Text(_uploading ? 'Uploading...' : 'Add photo'),
                ),
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: (_saving || _uploading) ? null : _submit,
                child: _saving
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Text('Confirm booking'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
