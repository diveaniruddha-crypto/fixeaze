import 'package:flutter/material.dart';

import '../../widgets/common.dart';
import '../login_screen.dart';
import '../profile_tab.dart';
import 'bookings_tab.dart';
import 'services_tab.dart';
import 'tips_tab.dart';

/// Customer app. [profile] is null while someone is browsing with "Skip for now".
class CustomerHome extends StatefulWidget {
  final Map<String, dynamic>? profile;
  const CustomerHome({super.key, required this.profile});

  @override
  State<CustomerHome> createState() => _CustomerHomeState();
}

class _CustomerHomeState extends State<CustomerHome> {
  int _tab = 0;

  void _openLogin() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final guest = widget.profile == null;
    final firstName =
        (widget.profile?['name'] ?? '').toString().trim().split(' ').first;

    final pages = <Widget>[
      ServicesTab(
        greetingName: firstName,
        onBooked: () => setState(() => _tab = 2),
      ),
      const TipsTab(),
      guest
          ? _LoginPrompt(
              icon: Icons.receipt_long,
              text: 'Log in to see your bookings.',
              onLogin: _openLogin)
          : const CustomerBookingsTab(),
      guest
          ? _LoginPrompt(
              icon: Icons.person,
              text: 'Log in or create an account to manage your profile.',
              onLogin: _openLogin)
          : const ProfileTab(isTechnician: false),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const AppBarTitle(),
        actions: [
          if (guest)
            TextButton(
              onPressed: _openLogin,
              child: const Text('Log in', style: TextStyle(color: Colors.white)),
            ),
        ],
      ),
      body: Constrained(child: pages[_tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_repair_service), label: 'Services'),
          NavigationDestination(icon: Icon(Icons.lightbulb_outline), label: 'Tips'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Bookings'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class _LoginPrompt extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onLogin;
  const _LoginPrompt({required this.icon, required this.text, required this.onLogin});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: Colors.black26),
            const SizedBox(height: 12),
            Text(text,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black54, fontSize: 16)),
            const SizedBox(height: 16),
            FilledButton(onPressed: onLogin, child: const Text('Log in / Sign up')),
          ],
        ),
      ),
    );
  }
}
