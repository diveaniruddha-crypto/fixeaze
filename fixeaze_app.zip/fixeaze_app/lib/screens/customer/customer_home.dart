import 'package:flutter/material.dart';

import '../../widgets/common.dart';
import '../profile_tab.dart';
import 'bookings_tab.dart';
import 'services_tab.dart';

class CustomerHome extends StatefulWidget {
  final Map<String, dynamic> profile;
  const CustomerHome({super.key, required this.profile});

  @override
  State<CustomerHome> createState() => _CustomerHomeState();
}

class _CustomerHomeState extends State<CustomerHome> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final firstName =
        (widget.profile['name'] ?? '').toString().trim().split(' ').first;

    final pages = <Widget>[
      ServicesTab(
        greetingName: firstName,
        onBooked: () => setState(() => _tab = 1),
      ),
      const CustomerBookingsTab(),
      const ProfileTab(isTechnician: false),
    ];

    return Scaffold(
      appBar: AppBar(title: const AppBarTitle()),
      body: Constrained(child: pages[_tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_repair_service), label: 'Services'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'My bookings'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
