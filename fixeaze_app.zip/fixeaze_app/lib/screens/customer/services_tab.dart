import 'package:flutter/material.dart';

import '../../config.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import 'book_screen.dart';

class ServicesTab extends StatefulWidget {
  final String greetingName;
  final VoidCallback onBooked;
  const ServicesTab({super.key, required this.greetingName, required this.onBooked});

  @override
  State<ServicesTab> createState() => _ServicesTabState();
}

class _ServicesTabState extends State<ServicesTab> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows =
        await supabase.from('services').select().eq('active', true).order('name');
    return List<Map<String, dynamic>>.from(rows);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return ErrorState(
            error: snap.error!,
            onRetry: () => setState(() => _future = _load()),
          );
        }
        final services = snap.data!;
        return RefreshIndicator(
          onRefresh: () async {
            setState(() => _future = _load());
            await _future;
          },
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
                  child: Text(
                    widget.greetingName.isEmpty
                        ? 'What do you need fixed?'
                        : 'Hi ${widget.greetingName}, what do you need fixed?',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 12),
                  child: Text('Choose a service to book a technician.',
                      style: TextStyle(color: Colors.black54)),
                ),
              ),
              if (services.isEmpty)
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: EmptyState(
                      icon: Icons.handyman, text: 'No services available yet.'),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  sliver: SliverGrid(
                    gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 240,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 1.05,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, i) => _ServiceCard(
                        service: services[i],
                        onTap: () async {
                          final booked = await Navigator.push<bool>(
                            context,
                            MaterialPageRoute(
                              builder: (_) => BookScreen(service: services[i]),
                            ),
                          );
                          if (booked == true) widget.onBooked();
                        },
                      ),
                      childCount: services.length,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _ServiceCard extends StatelessWidget {
  final Map<String, dynamic> service;
  final VoidCallback onTap;
  const _ServiceCard({required this.service, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final name = (service['name'] ?? '').toString();
    final iconUrl = service['icon_url'] as String?;
    return Card(
      elevation: 1,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 26,
                backgroundColor: kTeal.withOpacity(0.1),
                backgroundImage: iconUrl != null ? NetworkImage(iconUrl) : null,
                child: iconUrl == null
                    ? Icon(serviceIcon(name), color: kTeal, size: 28)
                    : null,
              ),
              const Spacer(),
              Text(name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 2),
              Text(
                (service['description'] ?? '').toString(),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
              const SizedBox(height: 6),
              if (service['base_price'] != null)
                Text('From ${money(service['base_price'])}',
                    style: const TextStyle(
                        color: kTeal, fontWeight: FontWeight.w600, fontSize: 13)),
            ],
          ),
        ),
      ),
    );
  }
}
