import 'dart:convert';

import 'package:http/http.dart' as http;

class PinInfo {
  final String pincode;
  final double lat;
  final double lng;
  final String label;
  const PinInfo(this.pincode, this.lat, this.lng, this.label);
}

/// Turns an Indian pincode into map coordinates (free OpenStreetMap lookup).
/// We use the coordinates to find technicians within 10 km.
class PincodeService {
  static final Map<String, PinInfo> _cache = {};

  static bool isValid(String pin) => RegExp(r'^[1-9][0-9]{5}$').hasMatch(pin.trim());

  static Future<PinInfo?> lookup(String raw) async {
    final pin = raw.trim();
    if (!isValid(pin)) return null;
    final cached = _cache[pin];
    if (cached != null) return cached;

    final attempts = <Map<String, String>>[
      {'postalcode': pin, 'countrycodes': 'in'},
      {'q': '$pin, India'},
    ];

    for (final attempt in attempts) {
      try {
        final params = <String, String>{
          ...attempt,
          'format': 'jsonv2',
          'limit': '1',
          'addressdetails': '1',
        };
        final uri = Uri.https('nominatim.openstreetmap.org', '/search', params);
        final res = await http
            .get(uri, headers: {'Accept': 'application/json'})
            .timeout(const Duration(seconds: 10));
        if (res.statusCode != 200) continue;

        final list = jsonDecode(res.body) as List;
        if (list.isEmpty) continue;
        final m = list.first as Map<String, dynamic>;
        final lat = double.tryParse('${m['lat']}');
        final lng = double.tryParse('${m['lon']}');
        if (lat == null || lng == null) continue;

        final addr = (m['address'] as Map?)?.cast<String, dynamic>() ?? const {};
        final place = (addr['suburb'] ??
                addr['city_district'] ??
                addr['city'] ??
                addr['town'] ??
                addr['county'] ??
                addr['state_district'] ??
                '')
            .toString();
        final state = (addr['state'] ?? '').toString();
        final label = [place, state].where((s) => s.isNotEmpty).join(', ');

        final info = PinInfo(pin, lat, lng, label);
        _cache[pin] = info;
        return info;
      } catch (_) {
        // try the next way of asking
      }
    }
    return null;
  }
}
